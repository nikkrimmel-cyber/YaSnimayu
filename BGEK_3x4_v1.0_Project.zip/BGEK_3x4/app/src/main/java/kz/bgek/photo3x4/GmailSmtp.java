package kz.bgek.photo3x4;

import android.util.Base64;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.net.ssl.*;

public final class GmailSmtp {
    // Fixed sender requested for this internal application.
    private static final String USER = "fotoserverbgek@gmail.com";
    private static final String APP_PASSWORD = "vbveuhwykievzpis";
    private static final String HOST = "smtp.gmail.com";
    private static final int PORT = 465;

    private GmailSmtp() {}

    public static void send(String recipients, String subject, String comment, File attachment) throws Exception {
        List<String> tos = parseRecipients(recipients);
        if (tos.isEmpty()) throw new IllegalArgumentException("Не указан получатель");
        if (!attachment.isFile()) throw new FileNotFoundException("Файл фото не найден");

        SSLSocketFactory sf = (SSLSocketFactory) SSLSocketFactory.getDefault();
        try (SSLSocket sock = (SSLSocket) sf.createSocket()) {
            sock.connect(new InetSocketAddress(HOST, PORT), 15000);
            sock.setSoTimeout(20000);
            sock.startHandshake();
            BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream(), StandardCharsets.US_ASCII));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream(), StandardCharsets.US_ASCII));

            expect(in, 220);
            cmd(out, "EHLO android-bgek"); expectMultiline(in, 250);
            cmd(out, "AUTH LOGIN"); expect(in, 334);
            cmd(out, b64(USER)); expect(in, 334);
            cmd(out, b64(APP_PASSWORD)); expect(in, 235);
            cmd(out, "MAIL FROM:<" + USER + ">"); expect(in, 250);
            for (String to : tos) { cmd(out, "RCPT TO:<" + to + ">"); int code=readCode(in); if(code!=250 && code!=251) throw new IOException("SMTP RCPT: "+code); }
            cmd(out, "DATA"); expect(in, 354);

            String boundary = "----BGEK3x4_" + System.currentTimeMillis();
            writeAscii(out, "From: \"BGEK Photo 3x4\" <"+USER+">\r\n");
            writeAscii(out, "To: "+String.join(", ", tos)+"\r\n");
            writeAscii(out, "Subject: =?UTF-8?B?"+Base64.encodeToString(subject.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP)+"?=\r\n");
            writeAscii(out, "Date: "+rfc2822Now()+"\r\n");
            writeAscii(out, "MIME-Version: 1.0\r\n");
            writeAscii(out, "Content-Type: multipart/mixed; boundary=\""+boundary+"\"\r\n\r\n");
            writeAscii(out, "--"+boundary+"\r\n");
            writeAscii(out, "Content-Type: text/plain; charset=UTF-8\r\n");
            writeAscii(out, "Content-Transfer-Encoding: base64\r\n\r\n");
            String body = (comment==null || comment.trim().isEmpty()) ? "Фото на документы БГЭК 3×4" : comment.trim();
            writeAscii(out, Base64.encodeToString(body.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP)+"\r\n\r\n");
            writeAscii(out, "--"+boundary+"\r\n");
            writeAscii(out, "Content-Type: image/jpeg; name=\"BGEK_3x4.jpg\"\r\n");
            writeAscii(out, "Content-Disposition: attachment; filename=\"BGEK_3x4.jpg\"\r\n");
            writeAscii(out, "Content-Transfer-Encoding: base64\r\n\r\n");
            byte[] raw = Files.readAllBytes(attachment.toPath());
            String encoded = Base64.encodeToString(raw, Base64.NO_WRAP);
            for (int i=0;i<encoded.length();i+=76) {
                writeAscii(out, encoded.substring(i, Math.min(i+76, encoded.length()))+"\r\n");
            }
            writeAscii(out, "\r\n--"+boundary+"--\r\n.\r\n");
            out.flush();
            expect(in, 250);
            cmd(out, "QUIT");
        }
    }

    private static List<String> parseRecipients(String s) {
        List<String> r=new ArrayList<>();
        for(String x:s.split("[,;\\n\\r]+")){x=x.trim();if(!x.isEmpty() && x.contains("@"))r.add(x);}
        return r;
    }
    private static String b64(String s){return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);}
    private static void cmd(BufferedWriter out,String s)throws IOException{writeAscii(out,s+"\r\n");out.flush();}
    private static void writeAscii(BufferedWriter out,String s)throws IOException{out.write(s);}
    private static void expect(BufferedReader in,int expected)throws IOException{int c=readCode(in);if(c!=expected)throw new IOException("SMTP: ожидался "+expected+", получен "+c);}
    private static void expectMultiline(BufferedReader in,int expected)throws IOException{
        String line; int code=-1;
        do{line=in.readLine();if(line==null)throw new EOFException("SMTP соединение закрыто");if(line.length()>=3)try{code=Integer.parseInt(line.substring(0,3));}catch(Exception ignored){}}while(line.length()>3 && line.charAt(3)=='-');
        if(code!=expected)throw new IOException("SMTP: ожидался "+expected+", получен "+code);
    }
    private static int readCode(BufferedReader in)throws IOException{String line=in.readLine();if(line==null)throw new EOFException("SMTP соединение закрыто");if(line.length()<3)throw new IOException("Некорректный ответ SMTP");try{return Integer.parseInt(line.substring(0,3));}catch(Exception e){throw new IOException("Некорректный ответ SMTP: "+line);}}
    private static String rfc2822Now(){SimpleDateFormat f=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z",Locale.US);f.setTimeZone(TimeZone.getDefault());return f.format(new Date());}
}
