package kz.bgek.photo3x4;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import java.io.*;

public final class ImageProcessor {
    private ImageProcessor() {}

    public static Bitmap process(Context c, Uri uri) throws Exception {
        Bitmap src;
        try (InputStream in=c.getContentResolver().openInputStream(uri)) { src=BitmapFactory.decodeStream(in); }
        if (src==null) throw new IOException("Не удалось прочитать изображение");

        int sw=src.getWidth(), sh=src.getHeight();
        float target=3f/4f, ratio=(float)sw/sh;
        int x=0,y=0,cw=sw,ch=sh;
        if (ratio>target) { cw=Math.round(sh*target); x=(sw-cw)/2; }
        else { ch=Math.round(sw/target); y=(sh-ch)/2; }
        Bitmap crop=Bitmap.createBitmap(src,x,y,cw,ch);
        Bitmap scaled=Bitmap.createScaledBitmap(crop,600,800,true);
        if (crop!=src) crop.recycle();
        if (src!=scaled && !src.isRecycled()) src.recycle();
        return autoTone(scaled);
    }

    private static Bitmap autoTone(Bitmap b) {
        int w=b.getWidth(), h=b.getHeight();
        int[] px=new int[w*h]; b.getPixels(px,0,w,0,0,w,h);
        double sum=0,sum2=0; int step=Math.max(1,px.length/50000),n=0;
        for(int i=0;i<px.length;i+=step){ int c=px[i]; double l=.2126*Color.red(c)+.7152*Color.green(c)+.0722*Color.blue(c); sum+=l; sum2+=l*l; n++; }
        double mean=sum/n, var=Math.max(1,sum2/n-mean*mean), sd=Math.sqrt(var);
        double alpha=Math.max(.88,Math.min(1.28,48.0/sd));
        double beta=132-alpha*mean;
        for(int i=0;i<px.length;i++){
            int c=px[i];
            int r=clip((int)(Color.red(c)*alpha+beta));
            int g=clip((int)(Color.green(c)*alpha+beta));
            int bl=clip((int)(Color.blue(c)*alpha+beta));
            px[i]=Color.rgb(r,g,bl);
        }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); out.setPixels(px,0,w,0,0,w,h); b.recycle(); return out;
    }
    private static int clip(int x){ return x<0?0:(x>255?255:x); }
}
