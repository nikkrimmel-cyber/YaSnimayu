package kz.bgek.photo3x4;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.concurrent.*;

public class PreviewActivity extends Activity {
    private Bitmap processed;
    private File outputFile;
    private final ExecutorService pool=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); process(); }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(24),dp(20),dp(20)); root.setBackgroundColor(Color.rgb(5,39,56));
        TextView title=txt("Фото готово — 3×4",28,true); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=txt("Автоматическая обрезка 3:4 и коррекция яркости/контраста",15,false); sub.setTextColor(Color.rgb(180,210,225)); root.addView(sub,new LinearLayout.LayoutParams(-1,-2));
        ImageView img=new ImageView(this); img.setId(12345); img.setAdjustViewBounds(true); img.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,0,1); ip.setMargins(0,dp(16),0,dp(16)); root.addView(img,ip);
        Button send=btn("Отправить на почту"); send.setOnClickListener(v->send()); root.addView(send,new LinearLayout.LayoutParams(-1,dp(58)));
        Button again=btn("Сделать заново"); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(54)); ap.setMargins(0,dp(10),0,0); again.setOnClickListener(v->finish()); root.addView(again,ap);
        setContentView(root);
    }

    private void process(){
        Uri uri=getIntent().getData();
        pool.execute(()->{
            try{
                processed=ImageProcessor.process(this,uri);
                outputFile=new File(getCacheDir(),"BGEK_3x4_"+System.currentTimeMillis()+".jpg");
                try(FileOutputStream f=new FileOutputStream(outputFile)){processed.compress(Bitmap.CompressFormat.JPEG,94,f);}
                runOnUiThread(()->((ImageView)findViewById(12345)).setImageBitmap(processed));
            }catch(Exception e){runOnUiThread(()->{Toast.makeText(this,"Ошибка обработки: "+e.getMessage(),Toast.LENGTH_LONG).show(); finish();});}
        });
    }

    private void send(){
        if(outputFile==null){ Toast.makeText(this,"Обработка ещё не завершена",Toast.LENGTH_SHORT).show(); return; }
        android.content.SharedPreferences sp=getSharedPreferences("mail",MODE_PRIVATE);
        String to=sp.getString("to","").trim(); String comment=sp.getString("comment","").trim();
        if(to.isEmpty()){ Toast.makeText(this,"Укажите получателя в Настройках",Toast.LENGTH_LONG).show(); startActivity(new Intent(this,SettingsActivity.class)); return; }
        Toast.makeText(this,"Отправка…",Toast.LENGTH_SHORT).show();
        pool.execute(()->{
            try{ GmailSmtp.send(to,"Фото на документы БГЭК 3×4",comment,outputFile); runOnUiThread(()->Toast.makeText(this,"Фото отправлено",Toast.LENGTH_LONG).show()); }
            catch(Exception e){ runOnUiThread(()->Toast.makeText(this,"Ошибка отправки: "+e.getMessage(),Toast.LENGTH_LONG).show()); }
        });
    }

    private TextView txt(String s,int sp,boolean bold){ TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.WHITE); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setTextColor(Color.WHITE); GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(8,121,188),Color.rgb(0,86,125)});g.setCornerRadius(dp(18));b.setBackground(g);return b; }
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
