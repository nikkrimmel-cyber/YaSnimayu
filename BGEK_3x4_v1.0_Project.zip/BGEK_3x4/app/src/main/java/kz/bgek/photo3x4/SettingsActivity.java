package kz.bgek.photo3x4;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import android.widget.*;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);build();}
    private void build(){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(22),dp(28),dp(22),dp(22));r.setBackgroundColor(Color.rgb(5,39,56));
        TextView h=t("Настройки отправки",28,true);r.addView(h);
        TextView info=t("Gmail отправитель настроен автоматически. Здесь изменяются только получатель и комментарий к письму.",15,false);info.setTextColor(Color.rgb(181,211,226)); LinearLayout.LayoutParams infp=new LinearLayout.LayoutParams(-1,-2);infp.setMargins(0,dp(8),0,dp(22));r.addView(info,infp);
        TextView l1=t("Получатель",16,true);r.addView(l1);
        EditText to=new EditText(this);to.setHint("example@company.kz, second@company.kz");to.setTextColor(Color.WHITE);to.setHintTextColor(Color.rgb(140,175,190));to.setSingleLine(false);to.setMinLines(2);r.addView(to,new LinearLayout.LayoutParams(-1,-2));
        TextView hint=t("Можно указать несколько адресов через запятую.",13,false);hint.setTextColor(Color.rgb(140,175,190));r.addView(hint);
        TextView l2=t("Комментарий",16,true);LinearLayout.LayoutParams l2p=new LinearLayout.LayoutParams(-1,-2);l2p.setMargins(0,dp(20),0,0);r.addView(l2,l2p);
        EditText comment=new EditText(this);comment.setHint("Комментарий, который будет добавлен в письмо");comment.setTextColor(Color.WHITE);comment.setHintTextColor(Color.rgb(140,175,190));comment.setMinLines(4);comment.setGravity(Gravity.TOP);r.addView(comment,new LinearLayout.LayoutParams(-1,-2));
        android.content.SharedPreferences sp=getSharedPreferences("mail",MODE_PRIVATE);to.setText(sp.getString("to",""));comment.setText(sp.getString("comment",""));
        Button save=new Button(this);save.setText("Сохранить");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56));bp.setMargins(0,dp(24),0,0);r.addView(save,bp);
        save.setOnClickListener(v->{sp.edit().putString("to",to.getText().toString().trim()).putString("comment",comment.getText().toString().trim()).apply();Toast.makeText(this,"Сохранено",Toast.LENGTH_SHORT).show();finish();});
        setContentView(r);
    }
    private TextView t(String s,int z,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.WHITE);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
}
