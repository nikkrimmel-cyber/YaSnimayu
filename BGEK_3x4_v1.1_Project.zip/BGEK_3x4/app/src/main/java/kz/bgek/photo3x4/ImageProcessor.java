package kz.bgek.photo3x4;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import java.io.*;

public final class ImageProcessor {
    private ImageProcessor() {}

    public static Bitmap process(Context c, Uri uri) throws Exception {
        Bitmap src;
        try (InputStream in=c.getContentResolver().openInputStream(uri)) { src=BitmapFactory.decodeStream(in); }
        if (src==null) throw new IOException("Не удалось прочитать изображение");

        int sw=src.getWidth(), sh=src.getHeight();
        float target=3f/4f, ratio=(float)sw/sh;
        int x=0,y=0,cw=sw,ch=sh;
        if (ratio>target) { cw=Math.round(sh*target); x=(sw-cw)/2; }
        else { ch=Math.round(sw/target); y=(sh-ch)/2; }
        Bitmap crop=Bitmap.createBitmap(src,x,y,cw,ch);
        Bitmap scaled=Bitmap.createScaledBitmap(crop,600,800,true);
        if (crop!=src) crop.recycle();
        if (src!=scaled && !src.isRecycled()) src.recycle();
        return autoTone(scaled);
    }

    public static Bitmap applyEdits(Bitmap base, float zoom, float rotation,
                                    int brightness, float contrast, float saturation) {
        int w=600,h=800;
        Bitmap geom=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(geom);
        canvas.drawColor(Color.WHITE);

        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        Matrix m=new Matrix();
        m.postTranslate(-base.getWidth()/2f,-base.getHeight()/2f);
        m.postScale(zoom,zoom);
        m.postRotate(rotation);
        m.postTranslate(w/2f,h/2f);
        canvas.drawBitmap(base,m,p);

        ColorMatrix sat=new ColorMatrix();
        sat.setSaturation(saturation);
        ColorMatrix con=new ColorMatrix(new float[]{
                contrast,0,0,0,brightness,
                0,contrast,0,0,brightness,
                0,0,contrast,0,brightness,
                0,0,0,1,0
        });
        sat.postConcat(con);
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(out);
        Paint cp=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        cp.setColorFilter(new ColorMatrixColorFilter(sat));
        c.drawBitmap(geom,0,0,cp);
        geom.recycle();
        return out;
    }

    /** A4 at 300 dpi (2480x3508 px), six 30x40 mm photos centered in 3x2 layout. */
    public static Bitmap makeA4Six(Bitmap photo3x4) {
        final int A4W=2480, A4H=3508;
        final int PW=354, PH=472; // 30x40 mm @ 300 dpi
        final int GAPX=90, GAPY=110;
        Bitmap page=Bitmap.createBitmap(A4W,A4H,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(page);
        canvas.drawColor(Color.WHITE);
        Bitmap small=Bitmap.createScaledBitmap(photo3x4,PW,PH,true);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        int totalW=PW*3+GAPX*2;
        int totalH=PH*2+GAPY;
        int sx=(A4W-totalW)/2;
        int sy=(A4H-totalH)/2;
        for(int row=0;row<2;row++){
            for(int col=0;col<3;col++){
                int x=sx+col*(PW+GAPX);
                int y=sy+row*(PH+GAPY);
                canvas.drawBitmap(small,x,y,p);
                Paint line=new Paint(); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2); line.setColor(Color.LTGRAY);
                canvas.drawRect(x,y,x+PW,y+PH,line);
            }
        }
        if(small!=photo3x4) small.recycle();
        return page;
    }

    private static Bitmap autoTone(Bitmap b) {
        int w=b.getWidth(), h=b.getHeight();
        int[] px=new int[w*h]; b.getPixels(px,0,w,0,0,w,h);
        double sum=0,sum2=0; int step=Math.max(1,px.length/50000),n=0;
        for(int i=0;i<px.length;i+=step){ int c=px[i]; double l=.2126*Color.red(c)+.7152*Color.green(c)+.0722*Color.blue(c); sum+=l; sum2+=l*l; n++; }
        double mean=sum/n, var=Math.max(1,sum2/n-mean*mean), sd=Math.sqrt(var);
        double alpha=Math.max(.88,Math.min(1.28,48.0/sd));
        double beta=132-alpha*mean;
        for(int i=0;i<px.length;i++){
            int c=px[i];
            int r=clip((int)(Color.red(c)*alpha+beta));
            int g=clip((int)(Color.green(c)*alpha+beta));
            int bl=clip((int)(Color.blue(c)*alpha+beta));
            px[i]=Color.rgb(r,g,bl);
        }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); out.setPixels(px,0,w,0,0,w,h); b.recycle(); return out;
    }
    private static int clip(int x){ return x<0?0:(x>255?255:x); }
}
