package kz.bgek.photo3x4;

import android.util.Base64;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.net.ssl.*;

public final class GmailSmtp {
    private static final String HOST = "smtp.gmail.com";
    private GmailSmtp() {}

    public static void send(String user, String appPassword, String recipients, String subject, String comment, File attachment) throws Exception {
        user=user==null?"":user.trim();
        appPassword=appPassword==null?"":appPassword.replace(" ","").trim();
        if(user.isEmpty()) throw new IllegalArgumentException("Не указан Gmail логин");
        if(appPassword.isEmpty()) throw new IllegalArgumentException("Не указан пароль приложения Gmail");
        List<String> tos=parseRecipients(recipients);
        if(tos.isEmpty()) throw new IllegalArgumentException("Не указан корректный получатель");
        if(!attachment.isFile()) throw new FileNotFoundException("Файл вложения не найден");
        Exception first;
        try { sendSsl465(user,appPassword,tos,subject,comment,attachment); return; }
        catch(Exception e){ first=e; }
        try { sendStartTls587(user,appPassword,tos,subject,comment,attachment); }
        catch(Exception second){
            throw new IOException("Gmail SMTP не отправил письмо. 465: "+safe(first)+"; 587: "+safe(second));
        }
    }

    private static void sendSsl465(String user,String appPassword,List<String> tos,String subject,String comment,File attachment)throws Exception{
        SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
        try(SSLSocket sock=(SSLSocket)sf.createSocket()){
            sock.connect(new InetSocketAddress(HOST,465),15000);sock.setSoTimeout(25000);sock.startHandshake();
            smtpSession(user,appPassword,sock.getInputStream(),sock.getOutputStream(),tos,subject,comment,attachment);
        }
    }

    private static void sendStartTls587(String user,String appPassword,List<String> tos,String subject,String comment,File attachment)throws Exception{
        try(Socket raw=new Socket()){
            raw.connect(new InetSocketAddress(HOST,587),15000); raw.setSoTimeout(25000);
            BufferedReader in=new BufferedReader(new InputStreamReader(raw.getInputStream(),StandardCharsets.US_ASCII));
            BufferedWriter out=new BufferedWriter(new OutputStreamWriter(raw.getOutputStream(),StandardCharsets.US_ASCII));
            expect(in,220); cmd(out,"EHLO android-bgek"); expectMultiline(in,250);
            cmd(out,"STARTTLS"); expect(in,220);
            SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
            try(SSLSocket tls=(SSLSocket)sf.createSocket(raw,HOST,587,true)){
                tls.setUseClientMode(true); tls.setSoTimeout(25000); tls.startHandshake();
                smtpSessionAfterGreeting(user,appPassword,tls.getInputStream(),tls.getOutputStream(),tos,subject,comment,attachment);
            }
        }
    }

    private static void smtpSession(String user,String appPassword,InputStream ins,OutputStream outs,List<String>tos,String subject,String comment,File attachment)throws Exception{
        BufferedReader in=new BufferedReader(new InputStreamReader(ins,StandardCharsets.US_ASCII));
        BufferedWriter out=new BufferedWriter(new OutputStreamWriter(outs,StandardCharsets.US_ASCII));
        expect(in,220); cmd(out,"EHLO android-bgek"); expectMultiline(in,250);
        authAndSend(user,appPassword,in,out,tos,subject,comment,attachment);
    }
    private static void smtpSessionAfterGreeting(String user,String appPassword,InputStream ins,OutputStream outs,List<String>tos,String subject,String comment,File attachment)throws Exception{
        BufferedReader in=new BufferedReader(new InputStreamReader(ins,StandardCharsets.US_ASCII));
        BufferedWriter out=new BufferedWriter(new OutputStreamWriter(outs,StandardCharsets.US_ASCII));
        cmd(out,"EHLO android-bgek"); expectMultiline(in,250);
        authAndSend(user,appPassword,in,out,tos,subject,comment,attachment);
    }

    private static void authAndSend(String user,String appPassword,BufferedReader in,BufferedWriter out,List<String> tos,String subject,String comment,File attachment)throws Exception{
        cmd(out,"AUTH LOGIN"); expect(in,334);
        cmd(out,b64(user)); expect(in,334);
        cmd(out,b64(appPassword)); int auth=readCode(in);
        if(auth!=235) throw new IOException(auth==535||auth==534?"Gmail отклонил логин/пароль приложения (SMTP "+auth+")":"Ошибка авторизации SMTP "+auth);
        cmd(out,"MAIL FROM:<"+user+">"); expect(in,250);
        for(String to:tos){cmd(out,"RCPT TO:<"+to+">");int code=readCode(in);if(code!=250&&code!=251)throw new IOException("Получатель отклонён SMTP: "+code);}
        cmd(out,"DATA"); expect(in,354);
        writeMessage(user,out,tos,subject,comment,attachment);
        expect(in,250); cmd(out,"QUIT");
    }

    private static void writeMessage(String user,BufferedWriter out,List<String>tos,String subject,String comment,File attachment)throws Exception{
        String boundary="----BGEK3x4_"+System.currentTimeMillis();
        writeAscii(out,"From: \"BGEK Photo 3x4\" <"+user+">\r\n");
        writeAscii(out,"To: "+String.join(", ",tos)+"\r\n");
        writeAscii(out,"Subject: =?UTF-8?B?"+Base64.encodeToString(subject.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP)+"?=\r\n");
        writeAscii(out,"Date: "+rfc2822Now()+"\r\nMIME-Version: 1.0\r\n");
        writeAscii(out,"Content-Type: multipart/mixed; boundary=\""+boundary+"\"\r\n\r\n");
        writeAscii(out,"--"+boundary+"\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        String body=(comment==null||comment.trim().isEmpty())?"Фото на документы БГЭК 3×4":comment.trim();
        writeAscii(out,Base64.encodeToString(body.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP)+"\r\n\r\n");
        String fn=attachment.getName();
        writeAscii(out,"--"+boundary+"\r\nContent-Type: image/jpeg; name=\""+fn+"\"\r\nContent-Disposition: attachment; filename=\""+fn+"\"\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        String encoded=Base64.encodeToString(Files.readAllBytes(attachment.toPath()),Base64.NO_WRAP);
        for(int i=0;i<encoded.length();i+=76)writeAscii(out,encoded.substring(i,Math.min(i+76,encoded.length()))+"\r\n");
        writeAscii(out,"\r\n--"+boundary+"--\r\n.\r\n");out.flush();
    }

    private static List<String> parseRecipients(String s){List<String>r=new ArrayList<>();for(String x:s.split("[,;\\n\\r]+")){x=x.trim();if(x.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"))r.add(x);}return r;}
    private static String b64(String s){return Base64.encodeToString(s.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);}
    private static void cmd(BufferedWriter out,String s)throws IOException{writeAscii(out,s+"\r\n");out.flush();}
    private static void writeAscii(BufferedWriter out,String s)throws IOException{out.write(s);}
    private static void expect(BufferedReader in,int expected)throws IOException{int c=readCode(in);if(c!=expected)throw new IOException("SMTP: ожидался "+expected+", получен "+c);}
    private static void expectMultiline(BufferedReader in,int expected)throws IOException{String line;int code=-1;do{line=in.readLine();if(line==null)throw new EOFException("SMTP соединение закрыто");if(line.length()>=3)try{code=Integer.parseInt(line.substring(0,3));}catch(Exception ignored){}}while(line.length()>3&&line.charAt(3)=='-');if(code!=expected)throw new IOException("SMTP: ожидался "+expected+", получен "+code);}
    private static int readCode(BufferedReader in)throws IOException{String line=in.readLine();if(line==null)throw new EOFException("SMTP соединение закрыто");if(line.length()<3)throw new IOException("Некорректный ответ SMTP");try{return Integer.parseInt(line.substring(0,3));}catch(Exception e){throw new IOException("Некорректный ответ SMTP: "+line);}}
    private static String rfc2822Now(){SimpleDateFormat f=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z",Locale.US);return f.format(new Date());}
    private static String safe(Exception e){String m=e.getMessage();return m==null?e.getClass().getSimpleName():m;}
}
