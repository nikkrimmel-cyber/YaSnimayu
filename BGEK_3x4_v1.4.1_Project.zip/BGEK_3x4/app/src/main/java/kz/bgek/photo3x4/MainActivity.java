package kz.bgek.photo3x4;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.ContentValues;
import android.graphics.Color;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.*;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA = 1001;
    private static final int REQ_GALLERY = 1002;
    private Uri cameraUri;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(makeUi());
    }

    private View makeUi() {
        FrameLayout root = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setImageResource(kz.bgek.photo3x4.R.drawable.main_screen);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(bg, new FrameLayout.LayoutParams(-1,-1));

        // Transparent hit areas preserve the approved visual design exactly.
        addHit(root, .075f, .557f, .85f, .116f, v -> takePhoto());
        addHit(root, .075f, .687f, .85f, .098f, v -> chooseGallery());
        addHit(root, .075f, .801f, .26f, .083f, v -> Toast.makeText(this,"История появится в следующей версии",Toast.LENGTH_SHORT).show());
        addHit(root, .355f, .801f, .275f, .083f, v -> startActivity(new Intent(this, SettingsActivity.class)));
        addHit(root, .65f, .801f, .27f, .083f, v -> startActivity(new Intent(this, SettingsActivity.class)));
        return root;
    }

    private void addHit(FrameLayout root, float x,float y,float w,float h, View.OnClickListener l) {
        View v = new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setOnClickListener(l);
        root.addView(v, new FrameLayout.LayoutParams(1,1));
        v.post(() -> {
            int rw=root.getWidth(), rh=root.getHeight();
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams((int)(rw*w),(int)(rh*h));
            lp.leftMargin=(int)(rw*x); lp.topMargin=(int)(rh*y); v.setLayoutParams(lp);
        });
    }

    private void takePhoto() {
        try {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "BGEK_3x4_"+System.currentTimeMillis()+".jpg");
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            cameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (cameraUri == null) throw new IOException("Не удалось создать файл для фотографии");
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, cameraUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (i.resolveActivity(getPackageManager()) == null)
                throw new IOException("Приложение камеры не найдено");
            startActivityForResult(i, REQ_CAMERA);
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть камеру: "+e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void chooseGallery() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQ_GALLERY);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (resultCode != RESULT_OK) return;
        Uri uri = null;
        if (requestCode == REQ_CAMERA) uri = cameraUri;
        else if (requestCode == REQ_GALLERY && data != null) uri = data.getData();
        if (uri != null) {
            try {
                if (requestCode == REQ_GALLERY && data != null) {
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Exception ignored) {}
                }
                Intent p = new Intent(this, PreviewActivity.class);
                p.setData(uri);
                p.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(p);
            } catch (Throwable e) {
                Toast.makeText(this, "Не удалось открыть фото: "+e.getClass().getSimpleName()+": "+e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
