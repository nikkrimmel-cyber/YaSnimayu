package kz.bgek.photo3x4;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.concurrent.*;

public class PreviewActivity extends Activity {
    private Bitmap base, edited;
    private ImageView image;
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private SeekBar zoom, rotate, bright, contrast, saturation;
    private TextView values, aiStatus;
    private Spinner skinSpinner;
    private CheckBox aiWhite;

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); process(); }

    private void buildUi(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(22),dp(18),dp(24)); root.setBackgroundColor(Color.rgb(5,39,56)); sc.addView(root);
        root.addView(txt("Обработка фото 3×4 — AI v1.4",26,true));
        TextView sub=txt("Белый фон AI, ручная коррекция и 10 шаблонов одежды",14,false); sub.setTextColor(Color.rgb(180,210,225)); root.addView(sub);

        image=new ImageView(this); image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER); image.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(430)); ip.setMargins(0,dp(14),0,dp(8)); root.addView(image,ip);

        aiWhite=new CheckBox(this); aiWhite.setText("AI: автоматически заменить фон на белый"); aiWhite.setTextColor(Color.WHITE); aiWhite.setChecked(true); root.addView(aiWhite);
        aiStatus=txt("AI ждёт фото…",13,false); aiStatus.setTextColor(Color.rgb(150,205,225)); root.addView(aiStatus);

        TextView skinTitle=txt("Скин / одежда",15,true); LinearLayout.LayoutParams stp=new LinearLayout.LayoutParams(-1,-2); stp.setMargins(0,dp(12),0,dp(4)); root.addView(skinTitle,stp);
        skinSpinner=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,SkinRenderer.LABELS);
        skinSpinner.setAdapter(adapter); root.addView(skinSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        skinSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){ refresh(); }
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });

        values=txt("",13,false); values.setTextColor(Color.rgb(160,205,224)); root.addView(values);
        zoom=slider(root,"Приближение",0,80,0);
        rotate=slider(root,"Поворот",0,40,20);
        bright=slider(root,"Яркость",0,100,50);
        contrast=slider(root,"Контраст",0,100,50);
        saturation=slider(root,"Насыщенность",0,100,50);

        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar s,int p,boolean from){ if(from) refresh(); }
            public void onStartTrackingTouch(SeekBar s){}
            public void onStopTrackingTouch(SeekBar s){ refresh(); }
        };
        zoom.setOnSeekBarChangeListener(listener); rotate.setOnSeekBarChangeListener(listener); bright.setOnSeekBarChangeListener(listener); contrast.setOnSeekBarChangeListener(listener); saturation.setOnSeekBarChangeListener(listener);

        Button rerun=btnSecondary("Повторить AI-обработку фона"); rerun.setOnClickListener(v->process()); root.addView(rerun,new LinearLayout.LayoutParams(-1,dp(48)));
        Button reset=btnSecondary("Сбросить настройки"); reset.setOnClickListener(v->{zoom.setProgress(0);rotate.setProgress(20);bright.setProgress(50);contrast.setProgress(50);saturation.setProgress(50);skinSpinner.setSelection(0);refresh();}); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(48));rp.setMargins(0,dp(8),0,0);root.addView(reset,rp);

        TextView variants=txt("Готовые варианты",20,true); LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,-2);vp.setMargins(0,dp(18),0,dp(8));root.addView(variants,vp);
        Button one=btn("1 фото 3×4 — отправить"); one.setOnClickListener(v->prepareAndSend(false)); root.addView(one,new LinearLayout.LayoutParams(-1,dp(58)));
        Button a4=btn("A4 — фото 3×4 в один ряд — отправить"); LinearLayout.LayoutParams a4p=new LinearLayout.LayoutParams(-1,dp(58));a4p.setMargins(0,dp(10),0,0);a4.setOnClickListener(v->prepareAndSend(true));root.addView(a4,a4p);
        Button again=btnSecondary("Сделать заново"); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(50)); ap.setMargins(0,dp(10),0,0); again.setOnClickListener(v->finish()); root.addView(again,ap);
        setContentView(sc);
    }

    private SeekBar slider(LinearLayout root,String label,int min,int max,int progress){
        TextView t=txt(label,14,true); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.setMargins(0,dp(6),0,0);root.addView(t,tp);
        SeekBar s=new SeekBar(this); if(Build.VERSION.SDK_INT>=26)s.setMin(min); s.setMax(max); s.setProgress(progress); root.addView(s,new LinearLayout.LayoutParams(-1,dp(38))); return s;
    }

    private void process(){
        Uri uri=getIntent().getData();
        aiStatus.setText("Обработка фото…");
        pool.execute(()->{
            try{
                Bitmap x=ImageProcessor.process(this,uri);
                if(aiWhite!=null && aiWhite.isChecked()){
                    runOnUiThread(()->aiStatus.setText("AI удаляет фон…"));
                    Bitmap white=AiBackgroundProcessor.whiteBackground(x);
                    if(white!=x && !x.isRecycled())x.recycle();
                    x=white;
                }
                if(base!=null && base!=x && !base.isRecycled())base.recycle();
                base=x;
                runOnUiThread(()->{aiStatus.setText(aiWhite.isChecked()?"AI: белый фон готов":"AI-фон отключён");refresh();});
            } catch(Throwable e){
                String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getClass().getSimpleName()+": "+e.getMessage();
                runOnUiThread(()->new AlertDialog.Builder(this)
                        .setTitle("Ошибка обработки фото")
                        .setMessage(msg)
                        .setPositiveButton("Закрыть",(d,w)->finish())
                        .setCancelable(false)
                        .show());
            }
        });
    }

    private void refresh(){
        if(base==null)return;
        final float z=1f+zoom.getProgress()/100f;
        final float r=rotate.getProgress()-20f;
        final int b=bright.getProgress()-50;
        final float c=.5f+contrast.getProgress()/100f;
        final float s=.5f+saturation.getProgress()/100f;
        final int skin=skinSpinner==null?0:skinSpinner.getSelectedItemPosition();
        values.setText(String.format(java.util.Locale.getDefault(),"Масштаб %d%%  •  Поворот %.0f°  •  Яркость %+d  •  Контраст %.0f%%  •  Цвет %.0f%%",Math.round(z*100),r,b,c*100,s*100));
        pool.execute(()->{
            Bitmap x=ImageProcessor.applyEdits(base,z,r,b,c,s);
            if(skin>0){ Bitmap y=SkinRenderer.apply(x,skin); x.recycle(); x=y; }
            Bitmap finalX=x;
            runOnUiThread(()->{ if(edited!=null && edited!=base && edited!=finalX && !edited.isRecycled()) edited.recycle(); edited=finalX; image.setImageBitmap(edited); });
        });
    }

    private void prepareAndSend(boolean a4){
        if(edited==null){Toast.makeText(this,"Фото ещё обрабатывается",Toast.LENGTH_SHORT).show();return;}
        android.content.SharedPreferences sp=getSharedPreferences("mail",MODE_PRIVATE);
        String user=sp.getString("user","").trim();
        String pass=sp.getString("pass","").replace(" ","").trim();
        String to=sp.getString("to","").trim(); String comment=sp.getString("comment","").trim();
        if(user.isEmpty()||pass.isEmpty()||to.isEmpty()){Toast.makeText(this,"Заполните Gmail, пароль приложения и получателя в Настройках",Toast.LENGTH_LONG).show();startActivity(new Intent(this,SettingsActivity.class));return;}
        Toast.makeText(this,a4?"Готовим лист A4…":"Готовим фото 3×4…",Toast.LENGTH_SHORT).show();
        Bitmap snapshot=edited.copy(Bitmap.Config.ARGB_8888,false);
        pool.execute(()->{
            Bitmap result=snapshot;
            try{
                if(a4){ result=ImageProcessor.makeA4Six(snapshot); snapshot.recycle(); }
                File f=new File(getCacheDir(),a4?"BGEK_A4_3x4.jpg":"BGEK_3x4.jpg");
                try(FileOutputStream os=new FileOutputStream(f)){result.compress(Bitmap.CompressFormat.JPEG,a4?96:95,os);}
                if(result!=edited && !result.isRecycled())result.recycle();
                GmailSmtp.send(user,pass,to,a4?"БГЭК — фото 3×4 на A4 в один ряд":"БГЭК — фото 3×4",comment,f);
                runOnUiThread(()->Toast.makeText(this,"Отправлено на почту",Toast.LENGTH_LONG).show());
            }catch(Exception e){
                String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
                runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Ошибка отправки").setMessage(msg).setPositiveButton("OK",null).show());
            }
        });
    }

    private TextView txt(String s,int sp,boolean bold){ TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.WHITE); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); b.setTextColor(Color.WHITE); GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(8,121,188),Color.rgb(0,86,125)});g.setCornerRadius(dp(18));b.setBackground(g);return b; }
    private Button btnSecondary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(15);GradientDrawable g=new GradientDrawable();g.setColor(Color.rgb(18,69,87));g.setCornerRadius(dp(16));g.setStroke(dp(1),Color.rgb(80,150,175));b.setBackground(g);return b;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onDestroy(){pool.shutdownNow(); if(base!=null&&!base.isRecycled())base.recycle(); if(edited!=null&&edited!=base&&!edited.isRecycled())edited.recycle(); super.onDestroy();}
}
