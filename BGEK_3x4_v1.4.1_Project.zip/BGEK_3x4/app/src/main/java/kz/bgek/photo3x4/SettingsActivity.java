package kz.bgek.photo3x4;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);build();}
    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(22),dp(28),dp(22),dp(22));r.setBackgroundColor(Color.rgb(5,39,56));sc.addView(r);
        TextView h=t("Настройки отправки",28,true);r.addView(h);
        TextView info=t("Введите Gmail, пароль приложения, получателя и комментарий. Данные сохраняются только в настройках этого телефона.",15,false);info.setTextColor(Color.rgb(181,211,226)); LinearLayout.LayoutParams infp=new LinearLayout.LayoutParams(-1,-2);infp.setMargins(0,dp(8),0,dp(22));r.addView(info,infp);

        android.content.SharedPreferences sp=getSharedPreferences("mail",MODE_PRIVATE);

        TextView lu=t("Gmail логин",16,true);r.addView(lu);
        EditText user=new EditText(this);user.setHint("example@gmail.com");user.setTextColor(Color.WHITE);user.setHintTextColor(Color.rgb(140,175,190));user.setSingleLine(true);user.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);user.setText(sp.getString("user",""));r.addView(user,new LinearLayout.LayoutParams(-1,-2));

        TextView lp=t("Пароль приложения Gmail",16,true);LinearLayout.LayoutParams lpp=new LinearLayout.LayoutParams(-1,-2);lpp.setMargins(0,dp(16),0,0);r.addView(lp,lpp);
        EditText pass=new EditText(this);pass.setHint("16-значный пароль приложения");pass.setTextColor(Color.WHITE);pass.setHintTextColor(Color.rgb(140,175,190));pass.setSingleLine(true);pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);pass.setText(sp.getString("pass",""));r.addView(pass,new LinearLayout.LayoutParams(-1,-2));
        TextView ph=t("Обычный пароль Gmail обычно не работает. Нужен пароль приложения Google.",13,false);ph.setTextColor(Color.rgb(140,175,190));r.addView(ph);

        TextView l1=t("Получатель",16,true);LinearLayout.LayoutParams l1p=new LinearLayout.LayoutParams(-1,-2);l1p.setMargins(0,dp(20),0,0);r.addView(l1,l1p);
        EditText to=new EditText(this);to.setHint("example@company.kz, second@company.kz");to.setTextColor(Color.WHITE);to.setHintTextColor(Color.rgb(140,175,190));to.setSingleLine(false);to.setMinLines(2);to.setText(sp.getString("to",""));r.addView(to,new LinearLayout.LayoutParams(-1,-2));
        TextView hint=t("Можно указать несколько адресов через запятую.",13,false);hint.setTextColor(Color.rgb(140,175,190));r.addView(hint);

        TextView l2=t("Комментарий",16,true);LinearLayout.LayoutParams l2p=new LinearLayout.LayoutParams(-1,-2);l2p.setMargins(0,dp(20),0,0);r.addView(l2,l2p);
        EditText comment=new EditText(this);comment.setHint("Комментарий, который будет добавлен в письмо");comment.setTextColor(Color.WHITE);comment.setHintTextColor(Color.rgb(140,175,190));comment.setMinLines(4);comment.setGravity(Gravity.TOP);comment.setText(sp.getString("comment",""));r.addView(comment,new LinearLayout.LayoutParams(-1,-2));

        Button save=new Button(this);save.setText("Сохранить");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56));bp.setMargins(0,dp(24),0,0);r.addView(save,bp);
        save.setOnClickListener(v->{
            String u=user.getText().toString().trim();
            String p=pass.getText().toString().replace(" ","").trim();
            String recipient=to.getText().toString().trim();
            if(u.isEmpty()||p.isEmpty()){Toast.makeText(this,"Укажите Gmail логин и пароль приложения",Toast.LENGTH_LONG).show();return;}
            sp.edit().putString("user",u).putString("pass",p).putString("to",recipient).putString("comment",comment.getText().toString().trim()).apply();
            Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show();finish();
        });
        setContentView(sc);
    }
    private TextView t(String s,int z,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.WHITE);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
}
