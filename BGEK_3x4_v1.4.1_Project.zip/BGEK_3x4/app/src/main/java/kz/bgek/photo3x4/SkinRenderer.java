package kz.bgek.photo3x4;

import android.graphics.*;

/** Lightweight offline clothing templates. Face/head pixels are never modified. */
public final class SkinRenderer {
    private SkinRenderer() {}

    public static final String[] LABELS = {
            "Без скина — документы",
            "1. Деловой мужской",
            "2. Деловой женский",
            "3. Smart Casual мужской",
            "4. Smart Casual женский",
            "5. Корпоративный BGEK мужской",
            "6. Корпоративный BGEK женский",
            "7. Классический нейтральный",
            "8. Студийный официальный",
            "9. Светлая форменная одежда",
            "10. Универсальный официальный"
    };

    public static Bitmap apply(Bitmap src, int style) {
        if (style <= 0) return src.copy(Bitmap.Config.ARGB_8888, false);
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        Canvas c = new Canvas(out);
        int w = out.getWidth(), h = out.getHeight();
        float top = h * 0.59f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        int jacket;
        switch (style) {
            case 2: case 4: jacket = Color.rgb(49,55,72); break;
            case 5: case 6: jacket = Color.rgb(20,74,112); break;
            case 9: jacket = Color.rgb(225,229,232); break;
            case 3: jacket = Color.rgb(72,78,82); break;
            case 8: jacket = Color.rgb(45,45,48); break;
            default: jacket = Color.rgb(30,38,52);
        }
        // shoulders/jacket only below chest line; conservative overlay to avoid touching face.
        Path body = new Path();
        body.moveTo(w * .16f, h);
        body.lineTo(w * .22f, top + h * .08f);
        body.quadTo(w * .30f, top, w * .41f, top - h * .01f);
        body.lineTo(w * .50f, top + h * .10f);
        body.lineTo(w * .59f, top - h * .01f);
        body.quadTo(w * .70f, top, w * .78f, top + h * .08f);
        body.lineTo(w * .84f, h);
        body.close();
        p.setColor(jacket); c.drawPath(body,p);

        // shirt/blouse triangle
        p.setColor(Color.rgb(245,245,242));
        Path shirt = new Path();
        shirt.moveTo(w*.41f, top);
        shirt.lineTo(w*.50f, top+h*.20f);
        shirt.lineTo(w*.59f, top);
        shirt.close(); c.drawPath(shirt,p);

        // tie for formal male / corporate / universal
        if(style==1 || style==5 || style==10){
            p.setColor(style==5?Color.rgb(0,105,160):Color.rgb(90,20,26));
            Path tie = new Path();
            tie.moveTo(w*.48f, top+h*.035f); tie.lineTo(w*.52f, top+h*.035f);
            tie.lineTo(w*.525f, top+h*.17f); tie.lineTo(w*.50f, top+h*.205f);
            tie.lineTo(w*.475f, top+h*.17f); tie.close(); c.drawPath(tie,p);
        }
        return out;
    }
}
