package kz.bgek.photo3x4;

import android.graphics.*;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;
import java.nio.FloatBuffer;
import java.util.concurrent.TimeUnit;

/** On-device ML Kit person segmentation. No photo is uploaded to a server. */
public final class AiBackgroundProcessor {
    private AiBackgroundProcessor() {}

    public static Bitmap whiteBackground(Bitmap input) throws Exception {
        SelfieSegmenterOptions options = new SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .enableRawSizeMask()
                .build();
        Segmenter segmenter = Segmentation.getClient(options);
        try {
            SegmentationMask mask = Tasks.await(
                    segmenter.process(InputImage.fromBitmap(input, 0)),
                    30, TimeUnit.SECONDS);
            int mw = mask.getWidth(), mh = mask.getHeight();
            FloatBuffer buf = mask.getBuffer();
            float[] conf = new float[mw * mh];
            buf.rewind();
            buf.get(conf);

            Bitmap out = Bitmap.createBitmap(input.getWidth(), input.getHeight(), Bitmap.Config.ARGB_8888);
            int[] src = new int[input.getWidth() * input.getHeight()];
            int[] dst = new int[src.length];
            input.getPixels(src, 0, input.getWidth(), 0, 0, input.getWidth(), input.getHeight());

            for (int y = 0; y < input.getHeight(); y++) {
                int my = Math.min(mh - 1, Math.max(0, (int)((long)y * mh / input.getHeight())));
                for (int x = 0; x < input.getWidth(); x++) {
                    int mx = Math.min(mw - 1, Math.max(0, (int)((long)x * mw / input.getWidth())));
                    float p = conf[my * mw + mx];
                    // soft matte prevents a hard, jagged edge around hair
                    float a = Math.max(0f, Math.min(1f, (p - 0.18f) / 0.62f));
                    a = a * a * (3f - 2f * a);
                    int c = src[y * input.getWidth() + x];
                    int r = Math.round(Color.red(c) * a + 255f * (1f - a));
                    int g = Math.round(Color.green(c) * a + 255f * (1f - a));
                    int b = Math.round(Color.blue(c) * a + 255f * (1f - a));
                    dst[y * input.getWidth() + x] = Color.rgb(r, g, b);
                }
            }
            out.setPixels(dst, 0, input.getWidth(), 0, 0, input.getWidth(), input.getHeight());
            return out;
        } finally {
            segmenter.close();
        }
    }
}
