package kz.bgek.photo3x4;

import android.graphics.*;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;
import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

/** On-device ML Kit person segmentation. No photo is uploaded to a server. */
public final class AiBackgroundProcessor {
    private AiBackgroundProcessor() {}

    public static Bitmap whiteBackground(Bitmap input) throws Exception {
        SelfieSegmenterOptions options = new SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .enableRawSizeMask()
                .build();
        Segmenter segmenter = Segmentation.getClient(options);
        try {
            SegmentationMask mask = Tasks.await(
                    segmenter.process(InputImage.fromBitmap(input, 0)),
                    30, TimeUnit.SECONDS);
            int mw = mask.getWidth(), mh = mask.getHeight();
            ByteBuffer buf = mask.getBuffer();
            float[] conf = new float[mw * mh];
            buf.rewind();
            for (int i = 0; i < conf.length; i++) conf[i] = buf.getFloat();

            // Blur confidence slightly to make hair/ear/shoulder edges smooth instead of jagged.
            float[] smooth = new float[conf.length];
            for (int y=0; y<mh; y++) {
                for (int x=0; x<mw; x++) {
                    float sum=0f, weight=0f;
                    for (int dy=-1; dy<=1; dy++) {
                        int yy=Math.max(0,Math.min(mh-1,y+dy));
                        for (int dx=-1; dx<=1; dx++) {
                            int xx=Math.max(0,Math.min(mw-1,x+dx));
                            float w=(dx==0&&dy==0)?4f:((dx==0||dy==0)?2f:1f);
                            sum += conf[yy*mw+xx]*w; weight += w;
                        }
                    }
                    smooth[y*mw+x]=sum/weight;
                }
            }

            int iw=input.getWidth(), ih=input.getHeight();
            Bitmap out = Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888);
            int[] src = new int[iw * ih];
            int[] dst = new int[src.length];
            input.getPixels(src, 0, iw, 0, 0, iw, ih);

            for (int y = 0; y < ih; y++) {
                float fy=((y + .5f) * mh / (float)ih) - .5f;
                int y0=Math.max(0,Math.min(mh-1,(int)Math.floor(fy)));
                int y1=Math.max(0,Math.min(mh-1,y0+1));
                float ty=Math.max(0f,Math.min(1f,fy-y0));
                for (int x = 0; x < iw; x++) {
                    float fx=((x + .5f) * mw / (float)iw) - .5f;
                    int x0=Math.max(0,Math.min(mw-1,(int)Math.floor(fx)));
                    int x1=Math.max(0,Math.min(mw-1,x0+1));
                    float tx=Math.max(0f,Math.min(1f,fx-x0));
                    float p00=smooth[y0*mw+x0], p10=smooth[y0*mw+x1];
                    float p01=smooth[y1*mw+x0], p11=smooth[y1*mw+x1];
                    float p0=p00+(p10-p00)*tx, p1=p01+(p11-p01)*tx;
                    float p=p0+(p1-p0)*ty;
                    float a = Math.max(0f, Math.min(1f, (p - 0.10f) / 0.72f));
                    a = a*a*(3f-2f*a);
                    int c = src[y * iw + x];
                    int r = Math.round(Color.red(c) * a + 255f * (1f - a));
                    int g = Math.round(Color.green(c) * a + 255f * (1f - a));
                    int b = Math.round(Color.blue(c) * a + 255f * (1f - a));
                    dst[y * iw + x] = Color.rgb(r, g, b);
                }
            }
            out.setPixels(dst, 0, iw, 0, 0, iw, ih);
            return out;
        } finally {
            segmenter.close();
        }
    }
}
