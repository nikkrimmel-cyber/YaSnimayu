package kz.bgek.photo3x4;

import android.content.Context;
import android.graphics.*;
import android.view.View;

/** Visual-only positioning guide for a correct 3x4 portrait. Never rendered into exported photo. */
public final class GuideOverlayView extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);

    public GuideOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
        setClickable(false);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(dp(2f));
        line.setColor(Color.argb(190, 210, 215, 220));
        dash.set(line);
        dash.setColor(Color.argb(175, 180, 190, 198));
        dash.setPathEffect(new DashPathEffect(new float[]{dp(8), dp(6)}, 0));
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Safe 3x4 crop frame.
        float m = Math.max(dp(8), w * 0.035f);
        RectF frame = new RectF(m, m, w - m, h - m);
        c.drawRect(frame, dash);

        // Head placement guide (ellipse-like upper contour).
        float cx = w * 0.50f;
        float headW = w * 0.52f;
        float headH = h * 0.47f;
        RectF head = new RectF(cx - headW/2f, h * 0.14f, cx + headW/2f, h * 0.14f + headH);
        Path headPath = new Path();
        headPath.addArc(head, 200f, 140f);
        c.drawPath(headPath, line);

        // Upper hair/head-height reference.
        Path crown = new Path();
        float yTop = h * 0.21f;
        crown.moveTo(cx - headW * 0.43f, yTop + headH * 0.11f);
        crown.quadTo(cx, yTop - headH * 0.16f, cx + headW * 0.43f, yTop + headH * 0.11f);
        c.drawPath(crown, line);

        // Chin/neck/shoulder guide.
        Path shoulders = new Path();
        float chinY = h * 0.61f;
        shoulders.moveTo(w * 0.25f, h * 0.87f);
        shoulders.quadTo(w * 0.34f, h * 0.72f, w * 0.41f, chinY);
        shoulders.quadTo(cx, h * 0.67f, w * 0.59f, chinY);
        shoulders.quadTo(w * 0.66f, h * 0.72f, w * 0.75f, h * 0.87f);
        c.drawPath(shoulders, line);

        // Horizontal eye/face reference line.
        float eyeY = h * 0.43f;
        c.drawLine(w * 0.21f, eyeY, w * 0.79f, eyeY, dash);
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
