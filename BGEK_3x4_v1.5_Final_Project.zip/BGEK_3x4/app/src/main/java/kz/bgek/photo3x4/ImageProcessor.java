package kz.bgek.photo3x4;

import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.media.ExifInterface;
import java.io.*;

public final class ImageProcessor {
    private ImageProcessor() {}

    public static Bitmap process(Context c, Uri uri) throws Exception {
        Bitmap src;
        int orientation = ExifInterface.ORIENTATION_NORMAL;
        try (InputStream exifIn=c.getContentResolver().openInputStream(uri)) {
            if (exifIn != null) {
                ExifInterface exif = new ExifInterface(exifIn);
                orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            }
        } catch (Exception ignored) {}
        // Decode a scaled version first. Modern phone cameras can produce 12–50 MP images;
        // decoding the original at full resolution may cause OutOfMemoryError immediately
        // after returning from the camera. The editor only needs a moderate source size.
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in=c.getContentResolver().openInputStream(uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0)
            throw new IOException("Не удалось определить размер изображения");

        final int MAX_SIDE = 3200;
        int sample = 1;
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        while (max / sample > MAX_SIDE * 2) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        try (InputStream in=c.getContentResolver().openInputStream(uri)) {
            src = BitmapFactory.decodeStream(in, null, opts);
        }
        if (src==null) throw new IOException("Не удалось прочитать изображение");
        src = orient(src, orientation);

        int sw=src.getWidth(), sh=src.getHeight();
        float target=3f/4f, ratio=(float)sw/sh;
        int x=0,y=0,cw=sw,ch=sh;
        if (ratio>target) { cw=Math.round(sh*target); x=(sw-cw)/2; }
        else { ch=Math.round(sw/target); y=(sh-ch)/2; }
        Bitmap crop=Bitmap.createBitmap(src,x,y,cw,ch);
        // Keep a high-resolution working image so e-mail/export quality does not depend on screen preview.
        // 1200x1600 is ~4x the old pixel count while remaining safe for on-device ML/background processing.
        Bitmap scaled=Bitmap.createScaledBitmap(crop,1200,1600,true);
        if (crop!=src) crop.recycle();
        if (src!=scaled && !src.isRecycled()) src.recycle();
        return autoTone(scaled);
    }

    public static Bitmap applyEdits(Bitmap base, float zoom, float rotation,
                                    int brightness, float contrast, float saturation) {
        int w=1200,h=1600;
        Bitmap geom=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(geom);
        canvas.drawColor(Color.WHITE);

        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        Matrix m=new Matrix();
        m.postTranslate(-base.getWidth()/2f,-base.getHeight()/2f);
        m.postScale(zoom,zoom);
        m.postRotate(rotation);
        m.postTranslate(w/2f,h/2f);
        canvas.drawBitmap(base,m,p);

        ColorMatrix sat=new ColorMatrix();
        sat.setSaturation(saturation);
        ColorMatrix con=new ColorMatrix(new float[]{
                contrast,0,0,0,brightness,
                0,contrast,0,0,brightness,
                0,0,contrast,0,brightness,
                0,0,0,1,0
        });
        sat.postConcat(con);
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(out);
        Paint cp=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        cp.setColorFilter(new ColorMatrixColorFilter(sat));
        c.drawBitmap(geom,0,0,cp);
        geom.recycle();
        return out;
    }

    /** A4 portrait at 300 dpi. Six vertical 30x40 mm photos in one horizontal row. */
    public static Bitmap makeA4Six(Bitmap photo3x4) {
        final int A4W=2480, A4H=3508;
        final int PW=354, PH=472; // 30x40 mm @ 300 dpi
        final int COUNT=6;
        final int GAPX=28;
        Bitmap page=Bitmap.createBitmap(A4W,A4H,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(page);
        canvas.drawColor(Color.WHITE);
        Bitmap small=Bitmap.createScaledBitmap(photo3x4,PW,PH,true);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        int totalW=PW*COUNT+GAPX*(COUNT-1);
        int sx=(A4W-totalW)/2;
        int sy=160; // top row, ~13.5 mm from the top at 300 dpi
        Paint line=new Paint();
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(2);
        line.setColor(Color.LTGRAY);
        for(int col=0;col<COUNT;col++){
            int x=sx+col*(PW+GAPX);
            canvas.drawBitmap(small,x,sy,p);
            canvas.drawRect(x,sy,x+PW,sy+PH,line);
        }
        if(small!=photo3x4) small.recycle();
        return page;
    }

    private static Bitmap orient(Bitmap src, int orientation) {
        float degrees=0f;
        if (orientation==ExifInterface.ORIENTATION_ROTATE_90) degrees=90f;
        else if (orientation==ExifInterface.ORIENTATION_ROTATE_180) degrees=180f;
        else if (orientation==ExifInterface.ORIENTATION_ROTATE_270) degrees=270f;
        if (degrees==0f) return src;
        Matrix m=new Matrix();
        m.postRotate(degrees);
        Bitmap out=Bitmap.createBitmap(src,0,0,src.getWidth(),src.getHeight(),m,true);
        if(out!=src) src.recycle();
        return out;
    }

    private static Bitmap autoTone(Bitmap b) {
        int w=b.getWidth(), h=b.getHeight();
        int[] px=new int[w*h]; b.getPixels(px,0,w,0,0,w,h);
        double sum=0,sum2=0; int step=Math.max(1,px.length/50000),n=0;
        for(int i=0;i<px.length;i+=step){ int c=px[i]; double l=.2126*Color.red(c)+.7152*Color.green(c)+.0722*Color.blue(c); sum+=l; sum2+=l*l; n++; }
        double mean=sum/n, var=Math.max(1,sum2/n-mean*mean), sd=Math.sqrt(var);
        double alpha=Math.max(.88,Math.min(1.28,48.0/sd));
        double beta=132-alpha*mean;
        for(int i=0;i<px.length;i++){
            int c=px[i];
            int r=clip((int)(Color.red(c)*alpha+beta));
            int g=clip((int)(Color.green(c)*alpha+beta));
            int bl=clip((int)(Color.blue(c)*alpha+beta));
            px[i]=Color.rgb(r,g,bl);
        }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); out.setPixels(px,0,w,0,0,w,h); b.recycle(); return out;
    }
    private static int clip(int x){ return x<0?0:(x>255?255:x); }
}
