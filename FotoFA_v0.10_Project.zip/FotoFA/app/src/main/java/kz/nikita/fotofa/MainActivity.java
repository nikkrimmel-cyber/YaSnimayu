
package kz.nikita.fotofa;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.*;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA=10, REQ_CAM_PERMISSION=11, REQ_GALLERY=12;
    private static final String KEY_ALIAS="fotofa_mail_key";
    private static final int RED=Color.rgb(255,38,48);
    private SharedPreferences prefs;
    private Uri photoUri;
    private final ExecutorService exec=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("settings",MODE_PRIVATE);
        showMain();
    }


    private GradientDrawable rounded(int color,int radius){
        GradientDrawable g=new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }

    private GradientDrawable outlined(int color,int strokeColor,int radius){
        GradientDrawable g=rounded(color,radius);
        g.setStroke(dp(1),strokeColor); return g;
    }

    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    private Button actionButton(String value,boolean primary){
        Button b=new Button(this);
        b.setText(value); b.setAllCaps(false); b.setTextSize(19);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(primary?rounded(RED,18):outlined(Color.TRANSPARENT,Color.rgb(150,150,155),18));
        return b;
    }

    private EditText nativeField(String hint,String value,boolean multi){
        EditText e=new EditText(this);
        e.setHint(hint); e.setHintTextColor(Color.rgb(125,125,130));
        e.setText(value); e.setTextColor(Color.WHITE); e.setTextSize(17);
        e.setPadding(dp(16),multi?dp(12):0,dp(16),multi?dp(12):0);
        e.setBackground(outlined(Color.rgb(28,30,34),Color.rgb(72,75,82),14));
        e.setSingleLine(!multi);
        if(multi){ e.setMinLines(2); e.setGravity(Gravity.TOP); }
        return e;
    }

    private void addLabel(LinearLayout parent,String value){
        TextView l=text(value,17,Color.WHITE,true);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,dp(18),0,dp(7));
        parent.addView(l,lp);
    }

    private void showMain(){
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(5,5,5));

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        sc.addView(page,new ScrollView.LayoutParams(-1,-2));
        root.addView(sc,new FrameLayout.LayoutParams(-1,-1));

        FrameLayout heroWrap=new FrameLayout(this);
        ImageView hero=new ImageView(this);
        hero.setImageResource(R.drawable.hero);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        heroWrap.addView(hero,new FrameLayout.LayoutParams(-1,-1));

        TextView gear=text("⚙",26,Color.WHITE,false); gear.setGravity(Gravity.CENTER);
        gear.setBackground(outlined(Color.argb(120,0,0,0),Color.WHITE,28));
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(52),dp(52));
        gp.gravity=Gravity.TOP|Gravity.LEFT; gp.setMargins(dp(16),dp(16),0,0);
        heroWrap.addView(gear,gp); gear.setOnClickListener(v->showSettings());

        TextView help=text("?",27,Color.WHITE,true); help.setGravity(Gravity.CENTER);
        help.setBackground(outlined(Color.argb(120,0,0,0),Color.WHITE,28));
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(dp(52),dp(52));
        hp.gravity=Gravity.TOP|Gravity.RIGHT; hp.setMargins(0,dp(16),dp(16),0);
        heroWrap.addView(help,hp); help.setOnClickListener(v->showHelp());

        page.addView(heroWrap,new LinearLayout.LayoutParams(-1,dp(470)));

        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(22),dp(12),dp(22),dp(28));
        page.addView(body,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout titleRow=new LinearLayout(this); titleRow.setGravity(Gravity.CENTER);
        TextView t1=text("Фото ",48,Color.WHITE,true);
        TextView t2=text("ФА",48,RED,true);
        titleRow.addView(t1); titleRow.addView(t2); body.addView(titleRow);

        TextView sub=text("Сделал фото — и оно уже в пути",22,Color.LTGRAY,false);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);
        sp.setMargins(0,dp(4),0,dp(18)); body.addView(sub,sp);

        TextView auto=text("✈  Фото автоматически отправляется после съёмки",17,Color.WHITE,false);
        auto.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,-2);
        ap.setMargins(0,0,0,dp(18)); body.addView(auto,ap);

        Button photo=actionButton("📷  Сделать фото",true);
        body.addView(photo,new LinearLayout.LayoutParams(-1,dp(64)));
        photo.setOnClickListener(v->{
            if(!configured()){
                Toast.makeText(this,"Сначала сохраните настройки почты",Toast.LENGTH_SHORT).show();
                showSettings();
                return;
            }
            takePhoto();
        });

        Space gapGallery=new Space(this); body.addView(gapGallery,new LinearLayout.LayoutParams(1,dp(10)));
        Button gallery=actionButton("🖼  Выбрать фото из галереи",false);
        body.addView(gallery,new LinearLayout.LayoutParams(-1,dp(58)));
        gallery.setOnClickListener(v->{
            if(!configured()){
                Toast.makeText(this,"Сначала сохраните настройки почты",Toast.LENGTH_SHORT).show();
                showSettings();
                return;
            }
            chooseFromGallery();
        });

        Space gap=new Space(this); body.addView(gap,new LinearLayout.LayoutParams(1,dp(12)));
        Button about=actionButton("ⓘ  О программе",false);
        body.addView(about,new LinearLayout.LayoutParams(-1,dp(58)));
        about.setOnClickListener(v->showAbout());

        setContentView(root);
    }

    private boolean configured(){
        return !prefs.getString("login","").isEmpty()
            && !prefs.getString("recipients","").isEmpty()
            && !getPassword().isEmpty();
    }

    private void showAbout(){
        ScrollView sc=new ScrollView(this);
        sc.setBackgroundColor(Color.rgb(7,7,8));
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setGravity(Gravity.CENTER_HORIZONTAL);
        p.setPadding(dp(24),dp(18),dp(24),dp(30));
        sc.addView(p);

        TextView back=text("‹   О программе",26,Color.WHITE,true);
        p.addView(back,new LinearLayout.LayoutParams(-1,dp(58)));
        back.setGravity(Gravity.CENTER_VERTICAL); back.setOnClickListener(v->showMain());

        ImageView icon=new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(190),dp(190));
        ip.setMargins(0,dp(8),0,dp(8)); p.addView(icon,ip);

        TextView name=text("Фото ФА",28,Color.WHITE,true); p.addView(name);
        TextView ver=text("Версия 0.10",15,Color.LTGRAY,false); p.addView(ver);

        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18),dp(18),dp(18),dp(18));
        card.setBackground(outlined(Color.rgb(22,23,26),Color.rgb(63,65,70),16));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);
        cp.setMargins(0,dp(20),0,dp(16)); p.addView(card,cp);

        card.addView(text("Разработчик",15,Color.LTGRAY,false));
        TextView dev=text("Антошкин Никита Викторович",19,RED,true);
        LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(-1,-2); dlp.setMargins(0,dp(4),0,dp(16)); card.addView(dev,dlp);
        card.addView(text("Телефон",15,Color.LTGRAY,false));
        card.addView(text("87027257995",18,Color.WHITE,false));
        TextView em=text("nikkrimmel@gmail.com",18,RED,false); card.addView(em);
        TextView purpose=text("\nНазначение\nАвтоматическая отправка фото на указанные e-mail адреса с возможностью добавления комментария.",16,Color.WHITE,false);
        card.addView(purpose);

        Button close=actionButton("Закрыть",false);
        p.addView(close,new LinearLayout.LayoutParams(-1,dp(58)));
        close.setOnClickListener(v->showMain());
        setContentView(sc);
    }

    private void showHelp(){
        ScrollView sc=new ScrollView(this);
        sc.setBackgroundColor(Color.rgb(7,7,8));
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(24),dp(18),dp(24),dp(30));
        sc.addView(p);

        TextView back=text("‹   Как создать пароль приложения",23,Color.WHITE,true);
        p.addView(back,new LinearLayout.LayoutParams(-1,dp(60)));
        back.setGravity(Gravity.CENTER_VERTICAL); back.setOnClickListener(v->showMain());

        String[] steps={
            "1. Откройте Google Аккаунт.",
            "2. Перейдите в раздел «Безопасность».",
            "3. Убедитесь, что включена двухэтапная аутентификация.",
            "4. Откройте «Пароли приложений».",
            "5. Создайте новый пароль, например «Фото ФА».",
            "6. Скопируйте выданный 16-значный пароль.",
            "7. Вставьте его в настройках приложения. Пробелы удаляются автоматически."
        };
        for(String x:steps){
            TextView item=text(x,18,Color.WHITE,false);
            item.setPadding(dp(14),dp(14),dp(14),dp(14));
            item.setBackground(rounded(Color.rgb(22,23,26),12));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(10));
            p.addView(item,lp);
        }
        p.addView(text("Важно: используйте пароль приложения Google, а не обычный пароль от почты.",17,RED,true));
        setContentView(sc);
    }

    private void showSettings(){
        ScrollView sc=new ScrollView(this);
        sc.setBackgroundColor(Color.rgb(7,7,8));
        LinearLayout p=new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(22),dp(16),dp(22),dp(32));
        sc.addView(p);

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=text("‹",42,Color.WHITE,false); back.setGravity(Gravity.CENTER);
        top.addView(back,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout titles=new LinearLayout(this); titles.setOrientation(LinearLayout.VERTICAL); titles.setGravity(Gravity.CENTER);
        TextView h=text("Настройки отправки",25,Color.WHITE,true); h.setGravity(Gravity.CENTER);
        TextView sh=text("Фото ФА",16,Color.LTGRAY,false); sh.setGravity(Gravity.CENTER);
        titles.addView(h); titles.addView(sh); top.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        TextView help=text("?",25,Color.WHITE,true); help.setGravity(Gravity.CENTER); help.setBackground(outlined(Color.TRANSPARENT,Color.WHITE,28));
        top.addView(help,new LinearLayout.LayoutParams(dp(52),dp(52)));
        p.addView(top);
        back.setOnClickListener(v->showMain()); help.setOnClickListener(v->showHelp());

        addLabel(p,"Почтовый сервис");
        Spinner provider=new Spinner(this);
        provider.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Gmail","iCloud Mail"}));
        provider.setSelection(prefs.getString("provider","gmail").equals("icloud")?1:0);
        provider.setBackground(outlined(Color.rgb(28,30,34),Color.rgb(72,75,82),14));
        p.addView(provider,new LinearLayout.LayoutParams(-1,dp(56)));

        addLabel(p,"Отправитель");
        EditText login=nativeField("yourmail@gmail.com",prefs.getString("login",""),false);
        p.addView(login,new LinearLayout.LayoutParams(-1,dp(58)));

        addLabel(p,"Пароль приложения");
        EditText pass=nativeField("16-значный пароль без пробелов",getPassword(),false);
        pass.setInputType(0x00000081);
        p.addView(pass,new LinearLayout.LayoutParams(-1,dp(58)));

        Space passGap=new Space(this);
        p.addView(passGap,new LinearLayout.LayoutParams(1,dp(10)));

        Button createPassword=actionButton("🔐  Создать пароль",false);
        p.addView(createPassword,new LinearLayout.LayoutParams(-1,dp(54)));
        createPassword.setOnClickListener(v->openAppPasswordsPage());

        addLabel(p,"Получатели");
        EditText rec=nativeField("user1@gmail.com, user2@gmail.com",prefs.getString("recipients",""),true);
        p.addView(rec,new LinearLayout.LayoutParams(-1,dp(92)));
        TextView hint=text("Можно указывать несколько адресатов через запятую или ;",14,Color.rgb(155,155,160),false);
        LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2); hlp.setMargins(dp(4),dp(5),0,0); p.addView(hint,hlp);

        addLabel(p,"Комментарий");
        EditText comment=nativeField("Фото с телефона",prefs.getString("default_comment",""),false);
        p.addView(comment,new LinearLayout.LayoutParams(-1,dp(58)));

        LinearLayout autoRow=new LinearLayout(this); autoRow.setGravity(Gravity.CENTER_VERTICAL); autoRow.setPadding(0,dp(20),0,dp(16));
        autoRow.addView(text("✈  Автоотправка после фото",17,Color.WHITE,true),new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this); sw.setChecked(true); sw.setEnabled(false); autoRow.addView(sw);
        p.addView(autoRow);

        Button save=actionButton("💾  Сохранить настройки",true);
        p.addView(save,new LinearLayout.LayoutParams(-1,dp(62)));
        save.setOnClickListener(v->{
            prefs.edit()
                .putString("provider",provider.getSelectedItemPosition()==1?"icloud":"gmail")
                .putString("login",login.getText().toString().trim())
                .putString("recipients",rec.getText().toString().trim())
                .putString("default_comment",comment.getText().toString().trim())
                .apply();
            try{ savePassword(pass.getText().toString().replaceAll("\\s+","")); }
            catch(Exception ex){ Toast.makeText(this,"Ошибка сохранения пароля",Toast.LENGTH_LONG).show(); return; }
            if(configured()){ Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show(); showMain(); }
            else Toast.makeText(this,"Заполните логин, пароль приложения и получателей",Toast.LENGTH_LONG).show();
        });
        setContentView(sc);
    }

    private void chooseProviderAndLogin(){
        String[] items={"Gmail","iCloud Mail"};
        new AlertDialog.Builder(this)
            .setTitle("Почтовый сервис")
            .setItems(items,(d,which)->{
                prefs.edit().putString("provider",which==1?"icloud":"gmail").apply();
                editTextSetting("Логин почты","login",prefs.getString("login",""),false);
            }).show();
    }

    private void editPassword(){
        final EditText e=new EditText(this);
        e.setSingleLine(true);
        e.setInputType(0x00000081);
        e.setHint("16-значный пароль приложения");
        e.setText(getPassword());
        new AlertDialog.Builder(this)
            .setTitle("Пароль приложения")
            .setMessage("Для Gmail вставьте 16-значный пароль приложения. Пробелы удаляются автоматически.")
            .setView(e)
            .setPositiveButton("Сохранить",(d,w)->{
                String p=e.getText().toString().replaceAll("\\s+","");
                try{ savePassword(p); showSettings(); }
                catch(Exception ex){ Toast.makeText(this,"Ошибка сохранения пароля",Toast.LENGTH_LONG).show(); }
            })
            .setNegativeButton("Отмена",null).show();
    }

    private void editRecipients(){
        final EditText e=new EditText(this);
        e.setMinLines(3);
        e.setText(prefs.getString("recipients",""));
        e.setHint("user1@mail.com, user2@mail.com; user3@mail.com");
        new AlertDialog.Builder(this)
            .setTitle("Получатели")
            .setMessage("Можно указать несколько адресов через запятую или точку с запятой.")
            .setView(e)
            .setPositiveButton("Сохранить",(d,w)->{
                prefs.edit().putString("recipients",e.getText().toString().trim()).apply();
                showSettings();
            })
            .setNegativeButton("Отмена",null).show();
    }

    private void editTextSetting(String title,String key,String def,boolean secret){
        final EditText e=new EditText(this);
        e.setSingleLine(!key.equals("default_comment"));
        e.setText(prefs.getString(key,def));
        new AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("Сохранить",(d,w)->{
                prefs.edit().putString(key,e.getText().toString().trim()).apply();
                showSettings();
            })
            .setNegativeButton("Отмена",null).show();
    }

    private void openAppPasswordsPage(){
        try{
            // Используем стабильный адрес без временного параметра rapt,
            // чтобы кнопка работала и после истечения текущей сессии Google.
            Uri url=Uri.parse("https://myaccount.google.com/apppasswords");
            Intent i=new Intent(Intent.ACTION_VIEW,url);
            startActivity(i);
        }catch(Exception e){
            Toast.makeText(this,"Не удалось открыть страницу Google: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void chooseFromGallery(){
        try{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            i.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i,REQ_GALLERY);
        }catch(Exception e){
            Toast.makeText(this,"Не удалось открыть галерею: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    private void takePhoto(){
        try{
            if(Build.VERSION.SDK_INT>=23 &&
                    checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAM_PERMISSION);
                return;
            }
            launchCamera();
        }catch(Exception e){
            Toast.makeText(this,"Не удалось открыть камеру: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){
        super.onRequestPermissionsResult(req,p,g);
        if(req==REQ_CAM_PERMISSION){
            if(g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED){
                launchCamera();
            }else{
                Toast.makeText(this,"Для съёмки нужно разрешение на камеру",Toast.LENGTH_LONG).show();
            }
        }
    }

    private void launchCamera(){
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(i.resolveActivity(getPackageManager())==null){
            Toast.makeText(this,"На устройстве не найдено приложение камеры",Toast.LENGTH_LONG).show();
            return;
        }

        ContentValues values=new ContentValues();
        String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.getDefault()).format(new Date());
        values.put(MediaStore.Images.Media.DISPLAY_NAME,"FotoFA_"+stamp+".jpg");
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        if(Build.VERSION.SDK_INT>=29){
            values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FotoFA");
        }

        photoUri=getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);

        if(photoUri==null){
            Toast.makeText(this,"Не удалось создать файл для фотографии",Toast.LENGTH_LONG).show();
            return;
        }

        i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try{
            startActivityForResult(i,REQ_CAMERA);
        }catch(Exception e){
            try{ getContentResolver().delete(photoUri,null,null); }catch(Exception ignored){}
            photoUri=null;
            Toast.makeText(this,"Ошибка запуска камеры: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);

        if(req==REQ_GALLERY){
            if(result==RESULT_OK && data!=null && data.getData()!=null){
                photoUri=data.getData();
                try{
                    int takeFlags=data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
                    if(takeFlags!=0){
                        getContentResolver().takePersistableUriPermission(photoUri,takeFlags);
                    }
                }catch(Exception ignored){}
                sendPhoto();
            }else{
                Toast.makeText(this,"Выбор фото отменён",Toast.LENGTH_SHORT).show();
                showMain();
            }
            return;
        }

        if(req!=REQ_CAMERA) return;

        if(result==RESULT_OK && photoUri!=null){
            sendPhoto();
        }else{
            if(photoUri!=null){
                try{ getContentResolver().delete(photoUri,null,null); }catch(Exception ignored){}
                photoUri=null;
            }
            Toast.makeText(this,"Съёмка отменена",Toast.LENGTH_SHORT).show();
            showMain();
        }
    }

    private List<String> parseRecipients(String raw){
        LinkedHashSet<String> out=new LinkedHashSet<>();
        for(String s:raw.split("[,;\\n]+")){
            String x=s.trim();
            if(!x.isEmpty() && x.contains("@")) out.add(x);
        }
        return new ArrayList<>(out);
    }

    private void sendPhoto(){
        final List<String> recipients=parseRecipients(prefs.getString("recipients",""));
        if(recipients.isEmpty()){
            Toast.makeText(this,"Не указаны получатели",Toast.LENGTH_LONG).show(); showSettings(); return;
        }
        showStatus("Отправляем фото…");
        exec.execute(()->{
            try{
                String provider=prefs.getString("provider","gmail");
                String host=provider.equals("icloud")?"smtp.mail.me.com":"smtp.gmail.com";
                smtpSend(host,587,prefs.getString("login",""),getPassword(),recipients,photoUri);
                runOnUiThread(()->showStatus("Фото отправлено"));
            }catch(Exception e){
                runOnUiThread(()->showError(e.getMessage()));
            }
        });
    }

    private void showStatus(String s){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.rgb(8,8,8));
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(28);
        t.setGravity(Gravity.CENTER); l.addView(t,new LinearLayout.LayoutParams(-1,-2));
        setContentView(l);
        if(s.contains("отправлено")){
            l.setOnClickListener(v->showMain());
            new Handler().postDelayed(this::showMain,1400);
        }
    }

    private void showError(String m){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40,100,40,40); l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.rgb(8,8,8));
        TextView h=new TextView(this); h.setText("Не удалось отправить"); h.setTextColor(Color.WHITE); h.setTextSize(30);
        TextView e=new TextView(this); e.setText(m==null?"Неизвестная ошибка":m); e.setTextColor(Color.LTGRAY); e.setTextSize(17); e.setPadding(0,60,0,60);
        Button retry=new Button(this); retry.setText("Повторить отправку"); retry.setOnClickListener(v->sendPhoto());
        Button settings=new Button(this); settings.setText("Проверить настройки"); settings.setOnClickListener(v->showSettings());
        l.addView(h); l.addView(e); l.addView(retry,new LinearLayout.LayoutParams(-1,-2)); l.addView(settings,new LinearLayout.LayoutParams(-1,-2));
        setContentView(l);
    }

    private void smtpSend(String host,int port,String login,String password,List<String> recipients,Uri uri)throws Exception{
        password=password.replaceAll("\\s+","");
        Socket socket=new Socket(host,port); socket.setSoTimeout(25000);
        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.US_ASCII));
        BufferedWriter out=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.US_ASCII));
        expect(readResp(in),220); sendLine(out,"EHLO fotofa.android"); expect(readResp(in),250);
        sendLine(out,"STARTTLS"); expect(readResp(in),220);

        SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
        SSLSocket ssl=(SSLSocket)sf.createSocket(socket,host,port,true);
        ssl.setUseClientMode(true); ssl.startHandshake();
        in=new BufferedReader(new InputStreamReader(ssl.getInputStream(),StandardCharsets.US_ASCII));
        out=new BufferedWriter(new OutputStreamWriter(ssl.getOutputStream(),StandardCharsets.US_ASCII));

        sendLine(out,"EHLO fotofa.android"); expect(readResp(in),250);
        sendLine(out,"AUTH LOGIN"); expect(readResp(in),334);
        sendLine(out,b64(login.getBytes(StandardCharsets.UTF_8))); expect(readResp(in),334);
        sendLine(out,b64(password.getBytes(StandardCharsets.UTF_8))); expect(readResp(in),235);

        sendLine(out,"MAIL FROM:<"+login+">"); expect(readResp(in),250);
        for(String rcpt:recipients){
            sendLine(out,"RCPT TO:<"+rcpt+">");
            String resp=readResp(in); int c=code(resp);
            if(c!=250 && c!=251) throw new IOException("SMTP отклонил адрес: "+rcpt+" ("+c+")");
        }

        sendLine(out,"DATA"); expect(readResp(in),354);
        String boundary="----FotoFA_"+UUID.randomUUID().toString().replace("-","");
        String subject="Фото ФА";
        String to=join(recipients,", ");

        write(out,"From: <"+login+">\r\n");
        write(out,"To: "+to+"\r\n");
        write(out,"Subject: =?UTF-8?B?"+b64(subject.getBytes(StandardCharsets.UTF_8))+"?=\r\n");
        write(out,"MIME-Version: 1.0\r\n");
        write(out,"Content-Type: multipart/mixed; boundary=\""+boundary+"\"\r\n\r\n");
        write(out,"--"+boundary+"\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        String body=prefs.getString("default_comment","Фото с телефона")+"\n"
            +new SimpleDateFormat("dd.MM.yyyy HH:mm:ss",Locale.getDefault()).format(new Date());
        write(out,wrap76(b64(body.getBytes(StandardCharsets.UTF_8)))+"\r\n");
        write(out,"--"+boundary+"\r\nContent-Type: image/jpeg; name=\"photo.jpg\"\r\n"
            +"Content-Disposition: attachment; filename=\"photo.jpg\"\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        try(InputStream is=getContentResolver().openInputStream(uri)){
            byte[] buf=new byte[57]; int n;
            while((n=is.read(buf))!=-1){
                byte[] chunk=n==buf.length?buf:Arrays.copyOf(buf,n);
                write(out,b64(chunk)+"\r\n");
            }
        }
        write(out,"--"+boundary+"--\r\n.\r\n"); out.flush(); expect(readResp(in),250);
        sendLine(out,"QUIT"); ssl.close();
    }

    private static String join(List<String> a,String sep){
        StringBuilder s=new StringBuilder();
        for(int i=0;i<a.size();i++){ if(i>0)s.append(sep); s.append("<").append(a.get(i)).append(">"); }
        return s.toString();
    }
    private void expect(String r,int exp)throws IOException{
        int c=code(r);
        if(c!=exp){
            if(c==534||c==535) throw new IOException("Ошибка авторизации. Проверьте логин и 16-значный пароль приложения без пробелов.");
            throw new IOException("Ошибка SMTP "+c);
        }
    }
    private int code(String r){ try{return Integer.parseInt(r.substring(0,3));}catch(Exception e){return -1;} }
    private String readResp(BufferedReader in)throws IOException{
        String first=in.readLine(); if(first==null)throw new EOFException("SMTP закрыл соединение");
        StringBuilder s=new StringBuilder(first);
        if(first.length()>3 && first.charAt(3)=='-'){
            String end=first.substring(0,3)+" "; String line;
            while((line=in.readLine())!=null){ s.append("\n").append(line); if(line.startsWith(end))break; }
        }
        return s.toString();
    }
    private void sendLine(BufferedWriter o,String s)throws IOException{ write(o,s+"\r\n"); o.flush(); }
    private void write(BufferedWriter o,String s)throws IOException{o.write(s);}
    private String b64(byte[] b){return Base64.encodeToString(b,Base64.NO_WRAP);}
    private String wrap76(String s){
        StringBuilder r=new StringBuilder(); for(int i=0;i<s.length();i+=76){if(i>0)r.append("\r\n");r.append(s,i,Math.min(i+76,s.length()));} return r.toString();
    }

    private void savePassword(String password)throws Exception{
        SecretKey key=getKey(); Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE,key);
        prefs.edit().putString("p_iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP))
            .putString("p_enc",Base64.encodeToString(c.doFinal(password.replaceAll("\\s+","").getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP)).apply();
    }
    private String getPassword(){
        try{
            String iv=prefs.getString("p_iv",""), en=prefs.getString("p_enc","");
            if(iv.isEmpty()||en.isEmpty())return "";
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,getKey(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(en,Base64.NO_WRAP)),StandardCharsets.UTF_8).replaceAll("\\s+","");
        }catch(Exception e){return "";}
    }

    private int dp(int v){
        return (int)(v*getResources().getDisplayMetrics().density+0.5f);
    }

    private SecretKey getKey()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }

    @Override public void onBackPressed(){ showMain(); }
    @Override protected void onDestroy(){ exec.shutdownNow(); super.onDestroy(); }
}
