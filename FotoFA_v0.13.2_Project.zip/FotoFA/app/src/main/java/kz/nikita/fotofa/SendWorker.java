package kz.nikita.fotofa;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class SendWorker extends Worker {
    private static final String KEY_ALIAS="fotofa_mail_key";
    private static final long SAFE_BATCH_BYTES=18L*1024L*1024L;
    private final Context ctx;
    private final SharedPreferences prefs;

    public SendWorker(@NonNull Context context,@NonNull WorkerParameters params){
        super(context,params);
        ctx=context.getApplicationContext();
        prefs=ctx.getSharedPreferences("settings",Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public Result doWork(){
        String pathsRaw=getInputData().getString("paths");
        if(pathsRaw==null || pathsRaw.trim().isEmpty()){
            finish(false,"Нет файлов для отправки",0,0);
            return Result.failure();
        }

        ArrayList<FileItem> files=new ArrayList<>();
        long totalBytes=0;
        for(String p:pathsRaw.split("\\n")){
            File f=new File(p.trim());
            if(f.exists()){
                files.add(new FileItem(f));
                totalBytes+=f.length();
            }
        }

        if(files.isEmpty()){
            finish(false,"Файлы очереди не найдены",0,0);
            return Result.failure();
        }

        setState("Отправляется • "+files.size()+" фото");

        try{
            String provider=prefs.getString("provider","gmail");
            String host="icloud".equals(provider)?"smtp.mail.me.com":"smtp.gmail.com";
            String login=prefs.getString("login","");
            String password=getPassword();
            List<String> recipients=parseRecipients(prefs.getString("recipients",""));

            if(login.isEmpty() || password.isEmpty() || recipients.isEmpty()){
                throw new IOException("Не заполнены настройки почты");
            }

            ArrayList<ArrayList<FileItem>> batches=splitIntoBatches(files);
            int totalParts=batches.size();

            for(int i=0;i<totalParts;i++){
                setState("Отправляется письмо "+(i+1)+" из "+totalParts);
                smtpSendBatch(host,587,login,password,recipients,batches.get(i),i+1,totalParts);
            }

            for(FileItem item:files){
                try{ item.file.delete(); }catch(Exception ignored){}
            }

            finish(true,"УСПЕШНО • "+files.size()+" фото • "+formatBytes(totalBytes)
                    +(totalParts>1?" • писем: "+totalParts:""),files.size(),totalBytes);
            return Result.success();

        }catch(Exception e){
            String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
            finish(false,"ОШИБКА • "+files.size()+" фото • "+shorten(msg,100),files.size(),totalBytes);
            return Result.failure();
        }
    }

    private void setState(String state){
        prefs.edit().putString("queue_state",state).apply();
    }

    private void finish(boolean ok,String entry,int count,long bytes){
        int pending=Math.max(0,prefs.getInt("queue_pending",1)-1);
        String finalState=pending>0?"В очереди: "+pending:(ok?"Последняя отправка успешна":"Последняя отправка с ошибкой");

        String stamp=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date());
        String old=prefs.getString("send_history","");
        String line=stamp+" • "+entry;
        String combined=old.isEmpty()?line:(old+"\n"+line);

        String[] all=combined.split("\\n");
        if(all.length>100){
            StringBuilder sb=new StringBuilder();
            for(int i=all.length-100;i<all.length;i++){
                if(sb.length()>0) sb.append("\n");
                sb.append(all[i]);
            }
            combined=sb.toString();
        }

        prefs.edit()
                .putInt("queue_pending",pending)
                .putString("queue_state",finalState)
                .putString("send_history",combined)
                .apply();
    }

    private static String shorten(String s,int max){
        if(s==null) return "";
        return s.length()<=max?s:s.substring(0,max-1)+"…";
    }

    private List<String> parseRecipients(String raw){
        LinkedHashSet<String> out=new LinkedHashSet<>();
        for(String s:raw.split("[,;\\n]+")){
            String x=s.trim();
            if(!x.isEmpty() && x.contains("@")) out.add(x);
        }
        return new ArrayList<>(out);
    }

    private static class FileItem{
        final File file;
        final long bytes;
        FileItem(File f){ file=f; bytes=f.length(); }
    }

    private ArrayList<ArrayList<FileItem>> splitIntoBatches(List<FileItem> all){
        ArrayList<ArrayList<FileItem>> batches=new ArrayList<>();
        ArrayList<FileItem> current=new ArrayList<>();
        long currentBytes=0;

        for(FileItem p:all){
            if(!current.isEmpty() && currentBytes+p.bytes>SAFE_BATCH_BYTES){
                batches.add(current);
                current=new ArrayList<>();
                currentBytes=0;
            }
            current.add(p);
            currentBytes+=p.bytes;
        }
        if(!current.isEmpty()) batches.add(current);
        return batches;
    }

    private void smtpSendBatch(String host,int port,String login,String password,
                               List<String> recipients,List<FileItem> images,
                               int part,int totalParts)throws Exception{
        password=password.replaceAll("\\s+","");
        Socket socket=new Socket(host,port);
        socket.setSoTimeout(180000);

        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.US_ASCII));
        BufferedWriter out=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.US_ASCII));
        expect(readResp(in),220);
        sendLine(out,"EHLO fotofa.android"); expect(readResp(in),250);
        sendLine(out,"STARTTLS"); expect(readResp(in),220);

        SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
        SSLSocket ssl=(SSLSocket)sf.createSocket(socket,host,port,true);
        ssl.setSoTimeout(180000);
        ssl.setUseClientMode(true);
        ssl.startHandshake();

        in=new BufferedReader(new InputStreamReader(ssl.getInputStream(),StandardCharsets.US_ASCII));
        out=new BufferedWriter(new OutputStreamWriter(ssl.getOutputStream(),StandardCharsets.US_ASCII));

        sendLine(out,"EHLO fotofa.android"); expect(readResp(in),250);
        sendLine(out,"AUTH LOGIN"); expect(readResp(in),334);
        sendLine(out,b64(login.getBytes(StandardCharsets.UTF_8))); expect(readResp(in),334);
        sendLine(out,b64(password.getBytes(StandardCharsets.UTF_8))); expect(readResp(in),235);

        sendLine(out,"MAIL FROM:<"+login+">"); expect(readResp(in),250);
        for(String rcpt:recipients){
            sendLine(out,"RCPT TO:<"+rcpt+">");
            String resp=readResp(in);
            int c=code(resp);
            if(c!=250 && c!=251) throw new IOException("SMTP отклонил адрес: "+rcpt+" ("+c+")");
        }

        sendLine(out,"DATA"); expect(readResp(in),354);

        String boundary="----FotoFA_"+UUID.randomUUID().toString().replace("-","");
        String subject=totalParts>1?"Фото ФА — часть "+part+" из "+totalParts:"Фото ФА";
        String to=join(recipients,", ");

        write(out,"From: <"+login+">\r\n");
        write(out,"To: "+to+"\r\n");
        write(out,"Subject: =?UTF-8?B?"+b64(subject.getBytes(StandardCharsets.UTF_8))+"?=\r\n");
        write(out,"MIME-Version: 1.0\r\n");
        write(out,"Content-Type: multipart/mixed; boundary=\""+boundary+"\"\r\n\r\n");

        write(out,"--"+boundary+"\r\n");
        write(out,"Content-Type: text/plain; charset=UTF-8\r\n");
        write(out,"Content-Transfer-Encoding: base64\r\n\r\n");

        String body=prefs.getString("default_comment","Фото с телефона")
                +"\n"+new SimpleDateFormat("dd.MM.yyyy HH:mm:ss",Locale.getDefault()).format(new Date())
                +(totalParts>1?"\nЧасть "+part+" из "+totalParts:"");
        write(out,wrap76(b64(body.getBytes(StandardCharsets.UTF_8)))+"\r\n");

        for(FileItem img:images){
            String name=img.file.getName();
            write(out,"--"+boundary+"\r\n");
            write(out,"Content-Type: image/jpeg; name=\""+name+"\"\r\n");
            write(out,"Content-Disposition: attachment; filename=\""+name+"\"\r\n");
            write(out,"Content-Transfer-Encoding: base64\r\n\r\n");

            try(InputStream is=new FileInputStream(img.file)){
                byte[] buf=new byte[57];
                int n;
                while((n=is.read(buf))!=-1){
                    byte[] chunk=n==buf.length?buf:Arrays.copyOf(buf,n);
                    write(out,b64(chunk)+"\r\n");
                }
            }
        }

        write(out,"--"+boundary+"--\r\n.\r\n");
        out.flush();
        expect(readResp(in),250);
        sendLine(out,"QUIT");
        ssl.close();
    }

    private void expect(String r,int exp)throws IOException{
        int c=code(r);
        if(c!=exp){
            if(c==534||c==535){
                throw new IOException("Ошибка авторизации. Проверьте логин и пароль приложения.");
            }
            throw new IOException("Ошибка SMTP "+c);
        }
    }

    private int code(String r){
        try{return Integer.parseInt(r.substring(0,3));}
        catch(Exception e){return -1;}
    }

    private String readResp(BufferedReader in)throws IOException{
        String first=in.readLine();
        if(first==null) throw new EOFException("SMTP закрыл соединение");

        StringBuilder s=new StringBuilder(first);
        if(first.length()>3 && first.charAt(3)=='-'){
            String end=first.substring(0,3)+" ";
            String line;
            while((line=in.readLine())!=null){
                s.append("\n").append(line);
                if(line.startsWith(end)) break;
            }
        }
        return s.toString();
    }

    private void sendLine(BufferedWriter o,String s)throws IOException{
        write(o,s+"\r\n");
        o.flush();
    }

    private void write(BufferedWriter o,String s)throws IOException{
        o.write(s);
    }

    private String b64(byte[] b){
        return Base64.encodeToString(b,Base64.NO_WRAP);
    }

    private String wrap76(String s){
        StringBuilder r=new StringBuilder();
        for(int i=0;i<s.length();i+=76){
            if(i>0) r.append("\r\n");
            r.append(s,i,Math.min(i+76,s.length()));
        }
        return r.toString();
    }

    private static String join(List<String> a,String sep){
        StringBuilder s=new StringBuilder();
        for(int i=0;i<a.size();i++){
            if(i>0) s.append(sep);
            s.append("<").append(a.get(i)).append(">");
        }
        return s.toString();
    }

    private String getPassword(){
        try{
            String iv=prefs.getString("p_iv","");
            String en=prefs.getString("p_enc","");
            if(iv.isEmpty()||en.isEmpty()) return "";

            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,getKey(),
                    new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));

            return new String(c.doFinal(Base64.decode(en,Base64.NO_WRAP)),
                    StandardCharsets.UTF_8).replaceAll("\\s+","");
        }catch(Exception e){
            return "";
        }
    }

    private SecretKey getKey()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        return ((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();
    }

    private String formatBytes(long bytes){
        if(bytes<=0) return "0 МБ";
        double mb=bytes/(1024.0*1024.0);
        if(mb<1.0) return String.format(Locale.getDefault(),"%.1f КБ",bytes/1024.0);
        return String.format(Locale.getDefault(),"%.1f МБ",mb);
    }
}
