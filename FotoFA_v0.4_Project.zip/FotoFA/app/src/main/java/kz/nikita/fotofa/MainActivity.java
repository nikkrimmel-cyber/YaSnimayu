
package kz.nikita.fotofa;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.net.ssl.*;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA=10, REQ_CAM_PERMISSION=11;
    private static final String KEY_ALIAS="fotofa_mail_key";
    private SharedPreferences prefs;
    private Uri photoUri;
    private final ExecutorService exec=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("settings",MODE_PRIVATE);
        showMain();
    }

    private void showArtwork(int drawable){
        FrameLayout root=new FrameLayout(this);
        ImageView bg=new ImageView(this);
        bg.setImageResource(drawable);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private View hotspot(FrameLayout root,float l,float t,float r,float b){
        View v=new View(this);
        v.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(
                (int)(getResources().getDisplayMetrics().widthPixels*(r-l)),
                (int)(getResources().getDisplayMetrics().heightPixels*(b-t)));
        p.leftMargin=(int)(getResources().getDisplayMetrics().widthPixels*l);
        p.topMargin=(int)(getResources().getDisplayMetrics().heightPixels*t);
        root.addView(v,p);
        return v;
    }

    private FrameLayout artRoot(int drawable){
        FrameLayout root=new FrameLayout(this);
        ImageView bg=new ImageView(this);
        bg.setImageResource(drawable);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(bg,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        return root;
    }

    private void showMain(){
        FrameLayout r=artRoot(R.drawable.screen_main);
        // ? help
        hotspot(r,.86f,.02f,.99f,.13f).setOnClickListener(v->showHelp());
        // make photo
        View photo=hotspot(r,.07f,.78f,.93f,.89f);
        photo.setOnClickListener(v->{ if(configured()) takePhoto(); else showSettings(); });
        photo.setOnLongClickListener(v->{ showSettings(); return true; });
        // about
        hotspot(r,.07f,.90f,.93f,.99f).setOnClickListener(v->showAbout());
    }

    private boolean configured(){
        return !prefs.getString("login","").isEmpty()
            && !prefs.getString("recipients","").isEmpty()
            && !getPassword().isEmpty();
    }

    private void showAbout(){
        FrameLayout r=artRoot(R.drawable.screen_about);
        hotspot(r,0f,0f,.18f,.12f).setOnClickListener(v->showMain());
    }

    private void showHelp(){
        FrameLayout r=artRoot(R.drawable.screen_help);
        hotspot(r,0f,0f,.18f,.12f).setOnClickListener(v->showMain());
    }

    private void showSettings(){
        FrameLayout r=artRoot(R.drawable.screen_settings);

        // Back arrow
        hotspot(r,0f,0f,.18f,.10f).setOnClickListener(v->showMain());

        // Sender/provider + login
        hotspot(r,.08f,.16f,.94f,.25f).setOnClickListener(v->chooseProviderAndLogin());

        // App password; always strip whitespace automatically
        hotspot(r,.08f,.27f,.94f,.36f).setOnClickListener(v->editPassword());

        // Recipients, comma or semicolon separated
        hotspot(r,.08f,.38f,.94f,.55f).setOnClickListener(v->editRecipients());

        // Comment
        hotspot(r,.08f,.57f,.94f,.66f).setOnClickListener(v->editTextSetting(
                "Комментарий","default_comment","Фото с телефона",false));

        // Auto-send switch area: retained visually; feature is always on.
        hotspot(r,.72f,.68f,.97f,.77f).setOnClickListener(v->
                Toast.makeText(this,"Автоотправка после фото включена",Toast.LENGTH_SHORT).show());

        // Save
        hotspot(r,.06f,.82f,.95f,.96f).setOnClickListener(v->{
            if(!configured()){
                Toast.makeText(this,"Заполните логин, пароль приложения и получателей.",Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,"Настройки сохранены",Toast.LENGTH_SHORT).show();
                showMain();
            }
        });
    }

    private void chooseProviderAndLogin(){
        String[] items={"Gmail","iCloud Mail"};
        new AlertDialog.Builder(this)
            .setTitle("Почтовый сервис")
            .setItems(items,(d,which)->{
                prefs.edit().putString("provider",which==1?"icloud":"gmail").apply();
                editTextSetting("Логин почты","login",prefs.getString("login",""),false);
            }).show();
    }

    private void editPassword(){
        final EditText e=new EditText(this);
        e.setSingleLine(true);
        e.setInputType(0x00000081);
        e.setHint("16-значный пароль приложения");
        e.setText(getPassword());
        new AlertDialog.Builder(this)
            .setTitle("Пароль приложения")
            .setMessage("Для Gmail вставьте 16-значный пароль приложения. Пробелы удаляются автоматически.")
            .setView(e)
            .setPositiveButton("Сохранить",(d,w)->{
                String p=e.getText().toString().replaceAll("\\s+","");
                try{ savePassword(p); }
                catch(Exception ex){ Toast.makeText(this,"Ошибка сохранения пароля",Toast.LENGTH_LONG).show(); }
            })
            .setNegativeButton("Отмена",null).show();
    }

    private void editRecipients(){
        final EditText e=new EditText(this);
        e.setMinLines(3);
        e.setText(prefs.getString("recipients",""));
        e.setHint("user1@mail.com, user2@mail.com; user3@mail.com");
        new AlertDialog.Builder(this)
            .setTitle("Получатели")
            .setMessage("Можно указать несколько адресов через запятую или точку с запятой.")
            .setView(e)
            .setPositiveButton("Сохранить",(d,w)->prefs.edit()
                    .putString("recipients",e.getText().toString().trim()).apply())
            .setNegativeButton("Отмена",null).show();
    }

    private void editTextSetting(String title,String key,String def,boolean secret){
        final EditText e=new EditText(this);
        e.setSingleLine(!key.equals("default_comment"));
        e.setText(prefs.getString(key,def));
        new AlertDialog.Builder(this).setTitle(title).setView(e)
            .setPositiveButton("Сохранить",(d,w)->prefs.edit()
                    .putString(key,e.getText().toString().trim()).apply())
            .setNegativeButton("Отмена",null).show();
    }

    private void takePhoto(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAM_PERMISSION); return;
        }
        launchCamera();
    }

    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){
        super.onRequestPermissionsResult(req,p,g);
        if(req==REQ_CAM_PERMISSION && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) launchCamera();
    }

    private void launchCamera(){
        ContentValues values=new ContentValues();
        String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.getDefault()).format(new Date());
        values.put(MediaStore.Images.Media.DISPLAY_NAME,"FotoFA_"+stamp+".jpg");
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/FotoFA");
        photoUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT,photoUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(i,REQ_CAMERA);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==REQ_CAMERA && result==RESULT_OK && photoUri!=null) sendPhoto();
    }

    private List<String> parseRecipients(String raw){
        LinkedHashSet<String> out=new LinkedHashSet<>();
        for(String s:raw.split("[,;\\n]+")){
            String x=s.trim();
            if(!x.isEmpty() && x.contains("@")) out.add(x);
        }
        return new ArrayList<>(out);
    }

    private void sendPhoto(){
        final List<String> recipients=parseRecipients(prefs.getString("recipients",""));
        if(recipients.isEmpty()){
            Toast.makeText(this,"Не указаны получатели",Toast.LENGTH_LONG).show(); showSettings(); return;
        }
        showStatus("Отправляем фото…");
        exec.execute(()->{
            try{
                String provider=prefs.getString("provider","gmail");
                String host=provider.equals("icloud")?"smtp.mail.me.com":"smtp.gmail.com";
                smtpSend(host,587,prefs.getString("login",""),getPassword(),recipients,photoUri);
                runOnUiThread(()->showStatus("Фото отправлено"));
            }catch(Exception e){
                runOnUiThread(()->showError(e.getMessage()));
            }
        });
    }

    private void showStatus(String s){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.rgb(8,8,8));
        TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(28);
        t.setGravity(Gravity.CENTER); l.addView(t,new LinearLayout.LayoutParams(-1,-2));
        setContentView(l);
        if(s.contains("отправлено")){
            l.setOnClickListener(v->showMain());
            new Handler().postDelayed(this::showMain,1400);
        }
    }

    private void showError(String m){
        LinearLayout l=new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL); l.setPadding(40,100,40,40); l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.rgb(8,8,8));
        TextView h=new TextView(this); h.setText("Не удалось отправить"); h.setTextColor(Color.WHITE); h.setTextSize(30);
        TextView e=new TextView(this); e.setText(m==null?"Неизвестная ошибка":m); e.setTextColor(Color.LTGRAY); e.setTextSize(17); e.setPadding(0,60,0,60);
        Button retry=new Button(this); retry.setText("Повторить отправку"); retry.setOnClickListener(v->sendPhoto());
        Button settings=new Button(this); settings.setText("Проверить настройки"); settings.setOnClickListener(v->showSettings());
        l.addView(h); l.addView(e); l.addView(retry,new LinearLayout.LayoutParams(-1,-2)); l.addView(settings,new LinearLayout.LayoutParams(-1,-2));
        setContentView(l);
    }

    private void smtpSend(String host,int port,String login,String password,List<String> recipients,Uri uri)throws Exception{
        password=password.replaceAll("\\s+","");
        Socket socket=new Socket(host,port); socket.setSoTimeout(25000);
        BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.US_ASCII));
        BufferedWriter out=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.US_ASCII));
        expect(readResp(in),220); sendLine(out,"EHLO fotofa.android"); expect(readResp(in),250);
        sendLine(out,"STARTTLS"); expect(readResp(in),220);

        SSLSocketFactory sf=(SSLSocketFactory)SSLSocketFactory.getDefault();
        SSLSocket ssl=(SSLSocket)sf.createSocket(socket,host,port,true);
        ssl.setUseClientMode(true); ssl.startHandshake();
        in=new BufferedReader(new InputStreamReader(ssl.getInputStream(),StandardCharsets.US_ASCII));
        out=new BufferedWriter(new OutputStreamWriter(ssl.getOutputStream(),StandardCharsets.US_ASCII));

        sendLine(out,"EHLO fotofa.android"); expect(readResp(in),250);
        sendLine(out,"AUTH LOGIN"); expect(readResp(in),334);
        sendLine(out,b64(login.getBytes(StandardCharsets.UTF_8))); expect(readResp(in),334);
        sendLine(out,b64(password.getBytes(StandardCharsets.UTF_8))); expect(readResp(in),235);

        sendLine(out,"MAIL FROM:<"+login+">"); expect(readResp(in),250);
        for(String rcpt:recipients){
            sendLine(out,"RCPT TO:<"+rcpt+">");
            String resp=readResp(in); int c=code(resp);
            if(c!=250 && c!=251) throw new IOException("SMTP отклонил адрес: "+rcpt+" ("+c+")");
        }

        sendLine(out,"DATA"); expect(readResp(in),354);
        String boundary="----FotoFA_"+UUID.randomUUID().toString().replace("-","");
        String subject="Фото ФА";
        String to=join(recipients,", ");

        write(out,"From: <"+login+">\r\n");
        write(out,"To: "+to+"\r\n");
        write(out,"Subject: =?UTF-8?B?"+b64(subject.getBytes(StandardCharsets.UTF_8))+"?=\r\n");
        write(out,"MIME-Version: 1.0\r\n");
        write(out,"Content-Type: multipart/mixed; boundary=\""+boundary+"\"\r\n\r\n");
        write(out,"--"+boundary+"\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        String body=prefs.getString("default_comment","Фото с телефона")+"\n"
            +new SimpleDateFormat("dd.MM.yyyy HH:mm:ss",Locale.getDefault()).format(new Date());
        write(out,wrap76(b64(body.getBytes(StandardCharsets.UTF_8)))+"\r\n");
        write(out,"--"+boundary+"\r\nContent-Type: image/jpeg; name=\"photo.jpg\"\r\n"
            +"Content-Disposition: attachment; filename=\"photo.jpg\"\r\nContent-Transfer-Encoding: base64\r\n\r\n");
        try(InputStream is=getContentResolver().openInputStream(uri)){
            byte[] buf=new byte[57]; int n;
            while((n=is.read(buf))!=-1){
                byte[] chunk=n==buf.length?buf:Arrays.copyOf(buf,n);
                write(out,b64(chunk)+"\r\n");
            }
        }
        write(out,"--"+boundary+"--\r\n.\r\n"); out.flush(); expect(readResp(in),250);
        sendLine(out,"QUIT"); ssl.close();
    }

    private static String join(List<String> a,String sep){
        StringBuilder s=new StringBuilder();
        for(int i=0;i<a.size();i++){ if(i>0)s.append(sep); s.append("<").append(a.get(i)).append(">"); }
        return s.toString();
    }
    private void expect(String r,int exp)throws IOException{
        int c=code(r);
        if(c!=exp){
            if(c==534||c==535) throw new IOException("Ошибка авторизации. Проверьте логин и 16-значный пароль приложения без пробелов.");
            throw new IOException("Ошибка SMTP "+c);
        }
    }
    private int code(String r){ try{return Integer.parseInt(r.substring(0,3));}catch(Exception e){return -1;} }
    private String readResp(BufferedReader in)throws IOException{
        String first=in.readLine(); if(first==null)throw new EOFException("SMTP закрыл соединение");
        StringBuilder s=new StringBuilder(first);
        if(first.length()>3 && first.charAt(3)=='-'){
            String end=first.substring(0,3)+" "; String line;
            while((line=in.readLine())!=null){ s.append("\n").append(line); if(line.startsWith(end))break; }
        }
        return s.toString();
    }
    private void sendLine(BufferedWriter o,String s)throws IOException{ write(o,s+"\r\n"); o.flush(); }
    private void write(BufferedWriter o,String s)throws IOException{o.write(s);}
    private String b64(byte[] b){return Base64.encodeToString(b,Base64.NO_WRAP);}
    private String wrap76(String s){
        StringBuilder r=new StringBuilder(); for(int i=0;i<s.length();i+=76){if(i>0)r.append("\r\n");r.append(s,i,Math.min(i+76,s.length()));} return r.toString();
    }

    private void savePassword(String password)throws Exception{
        SecretKey key=getKey(); Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE,key);
        prefs.edit().putString("p_iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP))
            .putString("p_enc",Base64.encodeToString(c.doFinal(password.replaceAll("\\s+","").getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP)).apply();
    }
    private String getPassword(){
        try{
            String iv=prefs.getString("p_iv",""), en=prefs.getString("p_enc","");
            if(iv.isEmpty()||en.isEmpty())return "";
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,getKey(),new GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(en,Base64.NO_WRAP)),StandardCharsets.UTF_8).replaceAll("\\s+","");
        }catch(Exception e){return "";}
    }
    private SecretKey getKey()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        if(ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null)).getSecretKey();
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return kg.generateKey();
    }

    @Override public void onBackPressed(){ showMain(); }
    @Override protected void onDestroy(){ exec.shutdownNow(); super.onDestroy(); }
}
