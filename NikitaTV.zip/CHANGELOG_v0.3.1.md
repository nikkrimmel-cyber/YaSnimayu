# Nikita TV v0.3.1

- Media3 downgraded from 1.11.1 to 1.9.4 for compileSdk 35 compatibility.
- Kept ExoPlayer, HLS/DASH playback, and fallback stream switching.
- Build toolchain remains AGP 8.7.3 + Gradle 8.9 + JDK 17 + Android SDK 35.
