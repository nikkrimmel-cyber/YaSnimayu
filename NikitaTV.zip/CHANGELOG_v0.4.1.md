# Никита ТВ v0.4.1

- Исправлена Java-компиляция PlayerActivity для Media3 1.9.4.
- В Java API Media3 используется `player.isPlaying()`, а не `player.getIsPlaying()`.
- Сохранены мировой M3U-каталог, резервные источники и 30-секундный тайм-аут запуска/буферизации.
