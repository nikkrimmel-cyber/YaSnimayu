# Nikita TV v0.4.2

- Исправлена Java-компиляция PlayerActivity: удалён вызов `player.isPlaying()`, который не находился при текущей конфигурации Media3.
- Состояние успешного старта теперь определяется по `Player.STATE_READY` + `getPlayWhenReady()`.
- Сохранён тайм-аут 30 секунд для старта источника.
- Сохранён тайм-аут 30 секунд при непрерывной буферизации уже запущенного канала.
- Глобальный каталог, поиск, страны, категории и резервные источники сохранены.

Build packaging fix FINAL-1:
- versionCode 9
- versionName 0.4.2
- BUILD_ID NIKITATV-0.4.2-FINAL-1
- GitHub workflow validates BUILD_ID to prevent old ZIP confusion.
