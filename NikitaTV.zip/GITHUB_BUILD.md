# Сборка Nikita TV через GitHub Actions

Workflow: `.github/workflows/build-apk.yml`.

## Как запустить
1. Загрузите содержимое проекта в корень репозитория GitHub.
2. Откройте вкладку **Actions**.
3. Выберите **Build Nikita TV APK**.
4. Нажмите **Run workflow**.
5. После завершения откройте запуск и скачайте артефакт **NikitaTV-debug-apk**.
6. Внутри артефакта находится `app-debug.apk`.

## Важно
Workflow использует Android SDK, уже установленный на runner `ubuntu-latest`, и не вызывает `android-actions/setup-android`. Это устраняет ошибку `Wrong version in preinstalled sdkmanager`.
