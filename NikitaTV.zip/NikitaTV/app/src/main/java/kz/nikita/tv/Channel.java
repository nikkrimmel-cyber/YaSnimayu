package kz.nikita.tv;

public class Channel {
    public final String name;
    public final String category;
    public final String country;
    public final String url;
    public final String[] urls;
    public final int accent;

    public Channel(String name, String category, String country, String url, int accent, String... fallbackUrls) {
        this.name = name;
        this.category = category;
        this.country = country;
        this.url = url;
        this.accent = accent;
        int extra = fallbackUrls == null ? 0 : fallbackUrls.length;
        this.urls = new String[1 + extra];
        this.urls[0] = url;
        if (extra > 0) System.arraycopy(fallbackUrls, 0, this.urls, 1, extra);
    }
}
