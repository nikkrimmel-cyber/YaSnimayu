package kz.nikita.tv;

import android.app.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private PlayerView playerView;
    private ExoPlayer player;
    private ProgressBar progress;
    private TextView status;
    private String name;
    private String[] urls;
    private boolean tvMode;
    private int sourceIndex = 0;
    private boolean exhausted = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        name=getIntent().getStringExtra("name");
        urls=getIntent().getStringArrayExtra("urls");
        if(urls==null || urls.length==0){
            String single=getIntent().getStringExtra("url");
            urls=single==null?new String[0]:new String[]{single};
        }
        tvMode=getIntent().getBooleanExtra("ui_tv",false);
        build();
        initPlayer();
        playCurrent();
    }

    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView text(String s,int sp,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}

    private void build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);

        playerView=new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setKeepScreenOn(true);
        root.addView(playerView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(18),dp(10),dp(18),dp(10));top.setBackgroundColor(0x99000000);
        Button back=new Button(this);back.setText("‹");back.setTextSize(tvMode?26:22);back.setTextColor(Color.WHITE);back.setBackground(round(0xAA173448,12));back.setOnClickListener(v->finish());back.setFocusable(true);
        top.addView(back,new LinearLayout.LayoutParams(dp(58),dp(50)));
        TextView title=text(name==null?"Канал":name,tvMode?24:19,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(50),1);tp.leftMargin=dp(14);top.addView(title,tp);
        TextView live=text("● LIVE",tvMode?15:12,true);live.setTextColor(0xFFFF4B55);top.addView(live,new LinearLayout.LayoutParams(dp(80),dp(50)));
        FrameLayout.LayoutParams topP=new FrameLayout.LayoutParams(-1,dp(72),Gravity.TOP);root.addView(top,topP);

        progress=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(56),dp(56),Gravity.CENTER);root.addView(progress,pp);
        status=text("Подключение…",tvMode?16:13,false);status.setGravity(Gravity.CENTER);status.setBackground(round(0xCC000000,10));status.setPadding(dp(14),dp(8),dp(14),dp(8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);sp.topMargin=dp(82);root.addView(status,sp);

        setContentView(root);
    }

    private void initPlayer(){
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if(state==Player.STATE_BUFFERING){
                    progress.setVisibility(View.VISIBLE);
                    status.setText(sourceText("Буферизация…"));
                    status.setVisibility(View.VISIBLE);
                } else if(state==Player.STATE_READY){
                    progress.setVisibility(View.GONE);
                    status.setVisibility(View.GONE);
                    exhausted=false;
                }
            }

            @Override public void onPlayerError(PlaybackException error) {
                tryNextSource(error);
            }
        });
    }

    private String sourceText(String prefix){
        if(urls.length<=1) return prefix;
        return prefix+" Источник "+(sourceIndex+1)+"/"+urls.length;
    }

    private void playCurrent(){
        if(urls.length==0){ showError("У канала нет ссылки"); return; }
        if(sourceIndex<0 || sourceIndex>=urls.length) sourceIndex=0;
        exhausted=false;
        progress.setVisibility(View.VISIBLE);
        status.setText(sourceText("Подключение…"));
        status.setVisibility(View.VISIBLE);
        player.stop();
        player.clearMediaItems();
        player.setMediaItem(MediaItem.fromUri(urls[sourceIndex]));
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void tryNextSource(PlaybackException error){
        if(exhausted) return;
        if(sourceIndex+1 < urls.length){
            sourceIndex++;
            progress.setVisibility(View.VISIBLE);
            status.setText(sourceText("Основной поток недоступен. Пробую резервный…"));
            status.setVisibility(View.VISIBLE);
            handler.postDelayed(this::playCurrent, 500);
        }else{
            exhausted=true;
            showError("Не удалось подключиться ни к одному доступному потоку этого канала. Возможна временная недоступность или региональное ограничение.");
        }
    }

    private void showError(String msg){
        progress.setVisibility(View.GONE);status.setText(msg);status.setVisibility(View.VISIBLE);
        new AlertDialog.Builder(this)
                .setTitle(name)
                .setMessage(msg)
                .setPositiveButton("Повторить",(d,w)->{sourceIndex=0; playCurrent();})
                .setNegativeButton("Назад",(d,w)->finish())
                .show();
    }

    @Override protected void onPause(){super.onPause();if(player!=null)player.pause();}
    @Override protected void onResume(){super.onResume();if(player!=null && player.getPlaybackState()==Player.STATE_READY)player.play();}
    @Override protected void onDestroy(){
        handler.removeCallbacksAndMessages(null);
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
