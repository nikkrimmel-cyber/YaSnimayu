package kz.nikita.tv;

public class Channel {
    public final String id;
    public final String name;
    public final String category;
    public final String country;
    public final String logo;
    public final String url;
    public final String[] urls;
    public final String[] userAgents;
    public final String[] referrers;
    public final int accent;

    public Channel(String name, String category, String country, String url, int accent, String... fallbackUrls) {
        this("", name, category, country, "", buildUrls(url, fallbackUrls), null, null, accent);
    }

    public Channel(String id, String name, String category, String country, String logo,
                   String[] urls, String[] userAgents, String[] referrers, int accent) {
        this.id = safe(id);
        this.name = safe(name);
        this.category = safe(category).isEmpty() ? "Другое" : safe(category);
        this.country = safe(country).toUpperCase();
        this.logo = safe(logo);
        this.urls = urls == null ? new String[0] : urls;
        this.userAgents = normalizeParallel(userAgents, this.urls.length);
        this.referrers = normalizeParallel(referrers, this.urls.length);
        this.url = this.urls.length == 0 ? "" : this.urls[0];
        this.accent = accent;
    }

    private static String[] buildUrls(String first, String[] fallback) {
        int extra = fallback == null ? 0 : fallback.length;
        String[] result = new String[1 + extra];
        result[0] = safe(first);
        if (extra > 0) System.arraycopy(fallback, 0, result, 1, extra);
        return result;
    }

    private static String[] normalizeParallel(String[] src, int size) {
        String[] out = new String[size];
        if (src != null) System.arraycopy(src, 0, out, 0, Math.min(src.length, size));
        for (int i = 0; i < out.length; i++) out[i] = safe(out[i]);
        return out;
    }

    private static String safe(String s) { return s == null ? "" : s.trim(); }
}
