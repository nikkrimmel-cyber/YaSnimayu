package kz.nikita.tv;

import android.graphics.Color;
import java.util.ArrayList;
import java.util.List;

public final class ChannelRepository {
    private ChannelRepository() {}

    private static Channel channel(String id, String name, String category, String country, String url, int accent, String... fallbackUrls) {
        int extra = fallbackUrls == null ? 0 : fallbackUrls.length;
        String[] urls = new String[1 + extra];
        urls[0] = url;
        if (extra > 0) System.arraycopy(fallbackUrls, 0, urls, 1, extra);
        return new Channel(id, name, category, country, "", urls, null, null, accent);
    }

    public static List<Channel> all() {
        List<Channel> c = new ArrayList<>();

        c.add(channel("Qazaqstan.kz", "Qazaqstan", "Казахстан", "KZ", "https://qazaqstantv-stream.qazcdn.com/qazaqstantv/qazaqstantv/playlist.m3u8", Color.rgb(33,150,243)));
        c.add(channel("Balapan.kz", "Balapan", "Детские", "KZ", "https://balapantv-stream.qazcdn.com/balapantv/balapantv/playlist.m3u8", Color.rgb(156,39,176)));
        c.add(channel("AbaiTV.kz", "Abai TV", "Культура", "KZ", "https://abaitv-stream.qazcdn.com/abaitv/abaitv/playlist.m3u8", Color.rgb(121,85,72)));
        c.add(channel("JibekJoly.kz", "Jibek Joly", "Казахстан", "KZ", "https://stream.qazcdn.net/ex6r514/jjtv/playlist.m3u8", Color.rgb(0,150,136)));
        c.add(channel("QazSport.kz", "Qazsport", "Спорт", "KZ", "https://qazsporttv-stream.qazcdn.com/qazsporttv/qazsporttv/playlist.m3u8", Color.rgb(0,121,107)));
        c.add(channel("31Kanal.kz", "31 Канал", "Развлекательные", "KZ", "https://streams.adapto.kz/hls/live/31kz/main_stream.m3u8", Color.rgb(244,67,54)));
        c.add(channel("24KZ.kz", "24KZ", "Новости", "KZ", "https://fs.uplink.kz/24KZ/mono.m3u8?token=onlinetv", Color.rgb(229,57,53)));
        c.add(channel("Khabar.kz", "Хабар", "Казахстан", "KZ", "https://fs.uplink.kz/habar/mono.m3u8?token=onlinetv", Color.rgb(255,193,7)));

        c.add(channel("Russia1.ru", "Россия 1", "Россия", "RU", "https://stream.smotrim.ru/hls2/russia_hd/playlist_6.m3u8", Color.rgb(30,88,195)));
        c.add(channel("Russia24.ru", "Россия 24", "Новости", "RU", "https://stream.smotrim.ru/hls2/russia24nl_smotrim/playlist_5.m3u8", Color.rgb(13,71,161)));
        c.add(channel("RussiaK.ru", "Россия-К", "Культура", "RU", "https://stream.smotrim.ru/hls2/russia_k/playlist_5.m3u8", Color.rgb(63,81,181)));
        c.add(channel("NTV.ru", "НТВ", "Россия", "RU", "https://cdn-dvr.ntv.ru/ntv0_hd/index.m3u8", Color.rgb(0,151,82)));
        c.add(channel("TNT.ru", "ТНТ", "Развлекательные", "RU", "http://45.153.24.78/TNT/index.m3u8", Color.rgb(255,152,0),
                "http://stream.mcquack.net/135/index.m3u8", "http://flussonic.linkintel.ru/tnt/index.m3u8", "http://176.118.197.101/THT/index.m3u8"));
        c.add(channel("STS.ru", "СТС", "Развлекательные", "RU", "https://fs.uplink.kz/sts/mono.m3u8?token=onlinetv", Color.rgb(255,193,7),
                "http://176.118.197.101/CTC/index.m3u8", "http://45.153.24.78/STS/index.m3u8", "http://stream.mcquack.net/138/index.m3u8"));
        c.add(channel("Friday.ru", "Пятница!", "Развлекательные", "RU", "http://stream.mcquack.net/181/index.m3u8", Color.rgb(233,30,99), "http://flussonic.linkintel.ru/Pyatnica/index.m3u8"));
        c.add(channel("TV3.ru", "ТВ-3", "Развлекательные", "RU", "http://stream.mcquack.net/136/index.m3u8", Color.rgb(103,58,183), "http://flussonic.linkintel.ru/tv-3/index.m3u8", "http://176.118.197.101/TB3/index.m3u8"));
        c.add(channel("Carousel.ru", "Карусель", "Детские", "RU", "https://stream.smotrim.ru/hls2/karusel/playlist_3.m3u8", Color.rgb(255,64,129)));

        return c;
    }
}
