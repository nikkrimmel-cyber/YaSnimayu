package kz.nikita.tv;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ChannelSession {
    private static final List<Channel> channels = new ArrayList<>();
    private static int currentIndex = -1;

    private ChannelSession() {}

    public static synchronized void setChannels(List<Channel> source, Channel current) {
        channels.clear();
        if (source != null) channels.addAll(source);
        currentIndex = indexOf(current);
    }

    public static synchronized List<Channel> snapshot() {
        return Collections.unmodifiableList(new ArrayList<>(channels));
    }

    public static synchronized Channel current() {
        return currentIndex >= 0 && currentIndex < channels.size() ? channels.get(currentIndex) : null;
    }

    public static synchronized Channel move(int delta) {
        if (channels.isEmpty()) return null;
        if (currentIndex < 0 || currentIndex >= channels.size()) currentIndex = 0;
        currentIndex = (currentIndex + delta) % channels.size();
        if (currentIndex < 0) currentIndex += channels.size();
        return channels.get(currentIndex);
    }

    public static synchronized void setCurrent(Channel channel) {
        currentIndex = indexOf(channel);
    }

    public static synchronized int indexOf(Channel channel) {
        if (channel == null) return -1;
        for (int i = 0; i < channels.size(); i++) {
            Channel c = channels.get(i);
            if (!channel.id.isEmpty() && channel.id.equalsIgnoreCase(c.id)) return i;
            if (channel.name.equalsIgnoreCase(c.name) && channel.country.equalsIgnoreCase(c.country)) return i;
        }
        return -1;
    }
}
