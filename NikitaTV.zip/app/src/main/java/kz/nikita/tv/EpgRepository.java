package kz.nikita.tv;

import android.content.Context;
import android.util.JsonReader;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPInputStream;

public final class EpgRepository {
    private static final String GUIDES_API = "https://iptv-org.github.io/api/guides.json";
    private static final long INDEX_TTL_MS = 24L * 60L * 60L * 1000L;
    private static final long GUIDE_TTL_MS = 8L * 60L * 60L * 1000L;
    private static final Object INDEX_LOCK = new Object();
    private static volatile Map<String, List<String>> guideIndex;
    private static final Map<String, List<ProgramInfo>> memoryPrograms = new ConcurrentHashMap<>();

    private EpgRepository() {}

    public static final class ProgramInfo {
        public final long startMs;
        public final long stopMs;
        public final String title;
        public final String description;

        public ProgramInfo(long startMs, long stopMs, String title, String description) {
            this.startMs = startMs;
            this.stopMs = stopMs;
            this.title = title == null ? "" : title.trim();
            this.description = description == null ? "" : description.trim();
        }

        public String timeRange() {
            SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.getDefault());
            return f.format(new Date(startMs)) + " – " + f.format(new Date(stopMs));
        }
    }

    public interface Callback {
        void onLoaded(List<ProgramInfo> programs);
        void onUnavailable(String reason);
    }

    public static void loadSchedule(Context context, Channel channel, Callback callback) {
        if (channel == null || channel.id == null || channel.id.trim().isEmpty()) {
            callback.onUnavailable("Для этого канала нет идентификатора телепрограммы");
            return;
        }
        final Context app = context.getApplicationContext();
        final String channelId = baseId(channel.id);
        final String memoryKey = channelId.toLowerCase(Locale.ROOT);
        List<ProgramInfo> cached = memoryPrograms.get(memoryKey);
        if (cached != null && !cached.isEmpty()) {
            callback.onLoaded(cached);
            return;
        }
        new Thread(() -> {
            try {
                Map<String, List<String>> index = ensureGuideIndex(app);
                List<String> sources = index.get(memoryKey);
                if (sources == null || sources.isEmpty()) {
                    callback.onUnavailable("Для канала программа пока не найдена");
                    return;
                }
                Exception last = null;
                for (String source : sources) {
                    try {
                        File xml = ensureGuideFile(app, source);
                        List<ProgramInfo> programs = parsePrograms(xml, channelId);
                        if (!programs.isEmpty()) {
                            memoryPrograms.put(memoryKey, programs);
                            callback.onLoaded(programs);
                            return;
                        }
                    } catch (Exception e) {
                        last = e;
                    }
                }
                callback.onUnavailable(last == null ? "Программа недоступна" : "Не удалось загрузить программу");
            } catch (Exception e) {
                callback.onUnavailable("EPG недоступна: " + safeMessage(e));
            }
        }, "nikitatv-epg").start();
    }

    public static ProgramInfo current(List<ProgramInfo> programs) {
        long now = System.currentTimeMillis();
        if (programs == null) return null;
        for (ProgramInfo p : programs) if (p.startMs <= now && now < p.stopMs) return p;
        return null;
    }

    public static List<ProgramInfo> upcoming(List<ProgramInfo> programs, int limit) {
        List<ProgramInfo> out = new ArrayList<>();
        if (programs == null) return out;
        long now = System.currentTimeMillis();
        for (ProgramInfo p : programs) {
            if (p.stopMs > now) {
                out.add(p);
                if (out.size() >= limit) break;
            }
        }
        return out;
    }

    private static Map<String, List<String>> ensureGuideIndex(Context context) throws Exception {
        Map<String, List<String>> local = guideIndex;
        if (local != null) return local;
        synchronized (INDEX_LOCK) {
            if (guideIndex != null) return guideIndex;
            File cache = new File(context.getCacheDir(), "nikitatv_guides.json");
            if (!cache.exists() || System.currentTimeMillis() - cache.lastModified() > INDEX_TTL_MS) {
                downloadToFile(GUIDES_API, cache);
            }
            guideIndex = parseGuideIndex(cache);
            return guideIndex;
        }
    }

    private static Map<String, List<String>> parseGuideIndex(File file) throws Exception {
        Map<String, List<String>> out = new HashMap<>();
        try (InputStream in = new BufferedInputStream(new FileInputStream(file));
             InputStreamReader isr = new InputStreamReader(in, StandardCharsets.UTF_8);
             JsonReader reader = new JsonReader(isr)) {
            reader.beginArray();
            while (reader.hasNext()) {
                String channel = "";
                List<String> sources = new ArrayList<>();
                reader.beginObject();
                while (reader.hasNext()) {
                    String name = reader.nextName();
                    if ("channel".equals(name)) {
                        channel = nextNullableString(reader);
                    } else if ("sources".equals(name)) {
                        reader.beginArray();
                        while (reader.hasNext()) {
                            String url = "";
                            String format = "";
                            reader.beginObject();
                            while (reader.hasNext()) {
                                String n = reader.nextName();
                                if ("url".equals(n)) url = nextNullableString(reader);
                                else if ("format".equals(n)) format = nextNullableString(reader);
                                else reader.skipValue();
                            }
                            reader.endObject();
                            if (!url.isEmpty() && (format.isEmpty() || "XML".equalsIgnoreCase(format))) sources.add(url);
                        }
                        reader.endArray();
                    } else reader.skipValue();
                }
                reader.endObject();
                if (!channel.isEmpty() && !sources.isEmpty()) {
                    String key = baseId(channel).toLowerCase(Locale.ROOT);
                    List<String> list = out.get(key);
                    if (list == null) { list = new ArrayList<>(); out.put(key, list); }
                    for (String s : sources) if (!list.contains(s)) list.add(s);
                }
            }
            reader.endArray();
        }
        return out;
    }


    private static String nextNullableString(JsonReader reader) throws IOException {
        if (reader.peek() == android.util.JsonToken.NULL) { reader.nextNull(); return ""; }
        return reader.nextString();
    }

    private static File ensureGuideFile(Context context, String source) throws Exception {
        File dir = new File(context.getCacheDir(), "epg");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать кэш EPG");
        File file = new File(dir, sha1(source) + ".xml");
        if (!file.exists() || System.currentTimeMillis() - file.lastModified() > GUIDE_TTL_MS) {
            downloadToFile(source, file);
        }
        return file;
    }

    private static void downloadToFile(String urlString, File target) throws Exception {
        File parent = target.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        File tmp = new File(target.getAbsolutePath() + ".tmp");
        HttpURLConnection con = (HttpURLConnection) new URL(urlString).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(45000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "NikitaTV/0.5 Android");
        con.setRequestProperty("Accept", "application/xml,application/json,text/xml,*/*");
        int code = con.getResponseCode();
        if (code < 200 || code >= 300) {
            con.disconnect();
            throw new IOException("HTTP " + code);
        }
        String encoding = con.getContentEncoding();
        boolean gzip = (encoding != null && encoding.toLowerCase(Locale.ROOT).contains("gzip")) || urlString.toLowerCase(Locale.ROOT).endsWith(".gz");
        try (InputStream raw = new BufferedInputStream(con.getInputStream());
             InputStream in = gzip ? new GZIPInputStream(raw) : raw;
             OutputStream out = new BufferedOutputStream(new FileOutputStream(tmp))) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
        } finally {
            con.disconnect();
        }
        if (target.exists() && !target.delete()) throw new IOException("Не удалось обновить кэш EPG");
        if (!tmp.renameTo(target)) throw new IOException("Не удалось сохранить EPG");
    }

    private static List<ProgramInfo> parsePrograms(File file, String channelId) throws Exception {
        List<ProgramInfo> out = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            parser.setInput(in, "UTF-8");
            int event = parser.getEventType();
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && "programme".equals(parser.getName())) {
                    String ch = parser.getAttributeValue(null, "channel");
                    String start = parser.getAttributeValue(null, "start");
                    String stop = parser.getAttributeValue(null, "stop");
                    if (sameChannel(ch, channelId)) {
                        long startMs = parseXmlTvDate(start);
                        long stopMs = parseXmlTvDate(stop);
                        String title = "";
                        String desc = "";
                        int depth = parser.getDepth();
                        while (true) {
                            int e = parser.next();
                            if (e == XmlPullParser.END_DOCUMENT) break;
                            if (e == XmlPullParser.START_TAG) {
                                if ("title".equals(parser.getName()) && title.isEmpty()) title = parser.nextText();
                                else if ("desc".equals(parser.getName()) && desc.isEmpty()) desc = parser.nextText();
                            }
                            if (e == XmlPullParser.END_TAG && parser.getDepth() == depth && "programme".equals(parser.getName())) break;
                        }
                        if (startMs > 0 && stopMs > startMs) out.add(new ProgramInfo(startMs, stopMs, title, desc));
                    }
                }
                event = parser.next();
            }
        }
        out.sort(Comparator.comparingLong(p -> p.startMs));
        long now = System.currentTimeMillis();
        long min = now - 6L * 60L * 60L * 1000L;
        long max = now + 3L * 24L * 60L * 60L * 1000L;
        List<ProgramInfo> trimmed = new ArrayList<>();
        for (ProgramInfo p : out) if (p.stopMs >= min && p.startMs <= max) trimmed.add(p);
        return trimmed;
    }

    private static boolean sameChannel(String a, String b) {
        if (a == null || b == null) return false;
        return baseId(a).equalsIgnoreCase(baseId(b));
    }

    private static long parseXmlTvDate(String value) {
        if (value == null) return 0L;
        String s = value.trim();
        try {
            if (s.length() >= 20) {
                String normalized = s.substring(0, 14) + " " + s.substring(s.length() - 5);
                SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US);
                f.setLenient(true);
                Date d = f.parse(normalized);
                return d == null ? 0L : d.getTime();
            }
            if (s.length() >= 14) {
                SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss", Locale.US);
                f.setLenient(true);
                Date d = f.parse(s.substring(0, 14));
                return d == null ? 0L : d.getTime();
            }
        } catch (Exception ignored) {}
        return 0L;
    }

    private static String baseId(String id) {
        if (id == null) return "";
        String s = id.trim();
        int at = s.indexOf('@');
        return at > 0 ? s.substring(0, at) : s;
    }

    private static String sha1(String s) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-1");
        byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format(Locale.US, "%02x", b & 0xff));
        return sb.toString();
    }

    private static String safeMessage(Throwable t) {
        String m = t.getMessage();
        return m == null || m.trim().isEmpty() ? t.getClass().getSimpleName() : m;
    }
}
