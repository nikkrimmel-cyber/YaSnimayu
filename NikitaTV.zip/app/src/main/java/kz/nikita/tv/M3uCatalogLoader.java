package kz.nikita.tv;

import android.content.Context;
import android.graphics.Color;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class M3uCatalogLoader {
    private static final String[] PLAYLIST_URLS = {
            "https://iptv-org.github.io/iptv/index.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/index.m3u"
    };
    private static final String CACHE_FILE = "iptv_org_index.m3u";
    private static final long CACHE_TTL_MS = 12L * 60L * 60L * 1000L;
    private static final Pattern ATTR = Pattern.compile("([A-Za-z0-9_-]+)=\"([^\"]*)\"");
    private static final Pattern COUNTRY = Pattern.compile("\\.([A-Za-z]{2})$");

    private M3uCatalogLoader() {}

    public interface Callback {
        void onLoaded(List<Channel> channels, boolean fromCache, int streamEntries);
        void onError(String message);
    }

    public static void load(Context context, boolean forceRefresh, Callback callback) {
        new Thread(() -> {
            File cache = new File(context.getFilesDir(), CACHE_FILE);
            try {
                boolean fresh = cache.isFile() && (System.currentTimeMillis() - cache.lastModified()) < CACHE_TTL_MS;
                String text;
                boolean fromCache;
                if (!forceRefresh && fresh) {
                    text = readFile(cache);
                    fromCache = true;
                } else {
                    try {
                        text = downloadAny();
                        writeFile(cache, text);
                        fromCache = false;
                    } catch (Exception networkError) {
                        if (!cache.isFile()) throw networkError;
                        text = readFile(cache);
                        fromCache = true;
                    }
                }
                ParseResult parsed = parse(text);
                callback.onLoaded(parsed.channels, fromCache, parsed.streamEntries);
            } catch (Exception e) {
                callback.onError(e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "ошибка загрузки" : e.getMessage()));
            }
        }, "nikita-tv-catalog").start();
    }

    private static String downloadAny() throws IOException {
        IOException last = null;
        for (String url : PLAYLIST_URLS) {
            try { return download(url); }
            catch (IOException e) { last = e; }
        }
        throw last == null ? new IOException("Нет доступного источника каталога") : last;
    }

    private static String download(String urlString) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(urlString).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(30000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "NikitaTV/0.5 Android");
        con.setRequestProperty("Accept", "application/x-mpegURL,text/plain,*/*");
        int code = con.getResponseCode();
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
        try (InputStream in = con.getInputStream();
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder(3_000_000);
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        } finally {
            con.disconnect();
        }
    }

    private static void writeFile(File file, String text) throws IOException {
        File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
        try (OutputStream out = new FileOutputStream(tmp)) {
            out.write(text.getBytes(StandardCharsets.UTF_8));
        }
        if (file.exists() && !file.delete()) throw new IOException("Не удалось обновить кэш");
        if (!tmp.renameTo(file)) throw new IOException("Не удалось сохранить кэш");
    }

    private static String readFile(File file) throws IOException {
        try (InputStream in = new FileInputStream(file);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder((int)Math.min(file.length() + 1024, 4_000_000));
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.toString();
        }
    }

    private static ParseResult parse(String text) throws IOException {
        LinkedHashMap<String, ChannelBuilder> grouped = new LinkedHashMap<>();
        BufferedReader br = new BufferedReader(new StringReader(text));
        String line;
        Meta pending = null;
        int streams = 0;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF:")) {
                pending = parseExtInf(line);
                continue;
            }
            if (pending != null && line.startsWith("#EXTVLCOPT:http-user-agent=")) {
                pending.userAgent = line.substring("#EXTVLCOPT:http-user-agent=".length()).trim();
                continue;
            }
            if (pending != null && line.startsWith("#EXTVLCOPT:http-referrer=")) {
                pending.referrer = line.substring("#EXTVLCOPT:http-referrer=".length()).trim();
                continue;
            }
            if (line.startsWith("#")) continue;
            if (pending == null) continue;

            if (isSupportedUrl(line)) {
                streams++;
                String baseId = baseId(pending.id);
                String key = !baseId.isEmpty() ? baseId.toLowerCase(Locale.ROOT)
                        : (pending.name + "|" + pending.country).toLowerCase(Locale.ROOT);
                ChannelBuilder b = grouped.get(key);
                if (b == null) {
                    b = new ChannelBuilder();
                    b.id = baseId;
                    b.name = cleanupName(pending.name);
                    b.category = translateCategory(pending.group);
                    b.country = pending.country;
                    b.logo = pending.logo;
                    grouped.put(key, b);
                }
                if (!b.urls.contains(line)) {
                    b.urls.add(line);
                    b.userAgents.add(pending.userAgent);
                    b.referrers.add(pending.referrer);
                }
            }
            pending = null;
        }

        List<Channel> channels = new ArrayList<>(grouped.size());
        for (ChannelBuilder b : grouped.values()) {
            if (b.urls.isEmpty() || b.name.isEmpty()) continue;
            String[] urls = b.urls.toArray(new String[0]);
            String[] uas = b.userAgents.toArray(new String[0]);
            String[] refs = b.referrers.toArray(new String[0]);
            channels.add(new Channel(b.id, b.name, b.category, b.country, b.logo,
                    urls, uas, refs, accentFor(b.name)));
        }
        return new ParseResult(channels, streams);
    }

    private static Meta parseExtInf(String line) {
        Meta m = new Meta();
        Matcher attrs = ATTR.matcher(line);
        while (attrs.find()) {
            String k = attrs.group(1).toLowerCase(Locale.ROOT);
            String v = attrs.group(2).trim();
            if ("tvg-id".equals(k)) m.id = v;
            else if ("tvg-logo".equals(k)) m.logo = v;
            else if ("group-title".equals(k)) m.group = v;
            else if ("http-user-agent".equals(k)) m.userAgent = v;
            else if ("http-referrer".equals(k)) m.referrer = v;
        }
        int comma = findCommaOutsideQuotes(line);
        m.name = comma >= 0 && comma + 1 < line.length() ? line.substring(comma + 1).trim() : "Канал";
        String idBase = baseId(m.id);
        Matcher cm = COUNTRY.matcher(idBase);
        if (cm.find()) m.country = cm.group(1).toUpperCase(Locale.ROOT);
        return m;
    }

    private static int findCommaOutsideQuotes(String s) {
        boolean quoted = false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '"') quoted = !quoted;
            else if (ch == ',' && !quoted) return i;
        }
        return s.lastIndexOf(',');
    }

    private static boolean isSupportedUrl(String url) {
        String l = url.toLowerCase(Locale.ROOT);
        return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("rtsp://");
    }

    private static String baseId(String id) {
        if (id == null) return "";
        String s = id.trim();
        int at = s.indexOf('@');
        return at > 0 ? s.substring(0, at) : s;
    }

    private static String cleanupName(String name) {
        if (name == null) return "Канал";
        String s = name.trim();
        s = s.replaceAll("\\s*\\((?:144p|240p|270p|360p|480p|540p|576i|576p|720p|1080i|1080p|1440p|2160p|4K|UHD)\\)\\s*$", "");
        s = s.replaceAll("\\s+(?:SD|HD|FHD|UHD)\\s*$", "");
        return s.trim();
    }

    private static String translateCategory(String group) {
        if (group == null || group.trim().isEmpty()) return "Другое";
        String first = group.split(";")[0].trim().toLowerCase(Locale.ROOT);
        switch (first) {
            case "news": return "Новости";
            case "entertainment": return "Развлекательные";
            case "movies": return "Кино";
            case "series": return "Сериалы";
            case "kids": return "Детские";
            case "animation": return "Мультфильмы";
            case "sports": return "Спорт";
            case "music": return "Музыка";
            case "documentary": return "Документальные";
            case "culture": return "Культура";
            case "education": return "Образование";
            case "science": return "Наука";
            case "travel": return "Путешествия";
            case "cooking": return "Кулинария";
            case "comedy": return "Юмор";
            case "business": return "Бизнес";
            case "auto": return "Авто";
            case "weather": return "Погода";
            case "lifestyle": return "Стиль жизни";
            case "family": return "Семейные";
            case "classic": return "Классика";
            case "religious": return "Религиозные";
            case "shop": return "Магазины";
            case "legislative": return "Парламент";
            case "outdoor": return "Активный отдых";
            case "relax": return "Релакс";
            case "general": return "Общие";
            default:
                String raw = group.split(";")[0].trim();
                return raw.isEmpty() ? "Другое" : raw;
        }
    }

    private static int accentFor(String name) {
        int h = name == null ? 0 : name.hashCode();
        int r = 55 + ((h >>> 16) & 0x7F);
        int g = 70 + ((h >>> 8) & 0x6F);
        int b = 85 + (h & 0x6F);
        return Color.rgb(Math.min(r, 190), Math.min(g, 190), Math.min(b, 200));
    }

    private static final class Meta {
        String id = "";
        String name = "";
        String logo = "";
        String group = "";
        String country = "";
        String userAgent = "";
        String referrer = "";
    }

    private static final class ChannelBuilder {
        String id = "";
        String name = "";
        String logo = "";
        String category = "Другое";
        String country = "";
        final List<String> urls = new ArrayList<>();
        final List<String> userAgents = new ArrayList<>();
        final List<String> referrers = new ArrayList<>();
    }

    private static final class ParseResult {
        final List<Channel> channels;
        final int streamEntries;
        ParseResult(List<Channel> channels, int streamEntries) {
            this.channels = channels;
            this.streamEntries = streamEntries;
        }
    }
}
