package kz.nikita.tv;

import android.app.*;
import android.app.UiModeManager;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private final List<Channel> allChannels = new ArrayList<>();
    private GridLayout channelGrid;
    private TextView catalogStatus;
    private TextView channelTitle;
    private EditText searchBox;
    private String activeCategory = "Все";
    private String activeCountry = "";
    private String searchQuery = "";
    private int visibleLimit = 120;
    private boolean tvMode;
    private boolean remoteLoaded = false;
    private LinearLayout content;
    private final String[] categories = {
            "Все", "Казахстан", "Россия", "Новости", "Развлекательные", "Кино",
            "Сериалы", "Детские", "Спорт", "Музыка", "Документальные", "Культура"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,14,22));
        getWindow().setNavigationBarColor(Color.rgb(5,14,22));
        tvMode = resolveTvMode();
        allChannels.addAll(ChannelRepository.all());
        buildUi();
        loadGlobalCatalog(false);
    }

    private boolean resolveTvMode() {
        String mode = getSharedPreferences("nikita_tv", MODE_PRIVATE).getString("ui_mode", "auto");
        if ("tv".equals(mode)) return true;
        if ("phone".equals(mode)) return false;
        UiModeManager um = (UiModeManager)getSystemService(UI_MODE_SERVICE);
        if (um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        return getResources().getConfiguration().smallestScreenWidthDp >= 720;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setImageResource(kz.nikita.tv.R.drawable.bg_serebryansk);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1,-1));

        View shade = new View(this);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x66000000,0xB8061119,0xF2050E16});
        shade.setBackground(gd); root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        if (tvMode) root.addView(buildTvLayout()); else root.addView(buildPhoneLayout());
        setContentView(root);
    }

    private View buildTvLayout() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(22),dp(20),dp(22),dp(18));
        row.addView(buildSidebar(), new LinearLayout.LayoutParams(dp(250), -1));
        content = buildContent(true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,-1,1); cp.leftMargin=dp(18);
        row.addView(content, cp); return row;
    }

    private View buildPhoneLayout() {
        content = buildContent(false);
        return content;
    }

    private View buildSidebar() {
        LinearLayout side = new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(dp(14),dp(14),dp(14),dp(14));
        side.setBackground(round(0xB8071621,18));
        TextView logo=text("Никита ТВ",29,true); side.addView(logo,new LinearLayout.LayoutParams(-1,dp(64)));
        String[] items={"⌂  Главная","▣  ТВ каналы","🌍  Выбрать страну","↻  Обновить каталог","★  Избранное","◷  История","⚙  Режим интерфейса"};
        for(String s:items){
            TextView v=text(s,17,false); v.setFocusable(true); v.setClickable(true); v.setPadding(dp(14),0,dp(8),0); v.setBackground(round(0x221E88E5,12));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.bottomMargin=dp(8); side.addView(v,p);
            if(s.contains("Режим")) v.setOnClickListener(x->showModeDialog());
            else if(s.contains("страну")) v.setOnClickListener(x->showCountryDialog());
            else if(s.contains("Обновить")) v.setOnClickListener(x->loadGlobalCatalog(true));
        }
        Space space=new Space(this); side.addView(space,new LinearLayout.LayoutParams(1,0,1));
        TextView city=text("●  Серебрянск, ВКО\n   Бесплатное ТВ",14,false); city.setTextColor(0xFFD7E6F2); side.addView(city,new LinearLayout.LayoutParams(-1,dp(70)));
        return side;
    }

    private LinearLayout buildContent(boolean tv) {
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(tv?dp(10):dp(16), tv?0:dp(12), tv?dp(10):dp(16), dp(14));

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("Никита ТВ", tv?34:27,true); top.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        Button mode=new Button(this); mode.setText(tv?"📺 ТВ":"📱 Телефон"); mode.setTextColor(Color.WHITE); mode.setTextSize(tv?16:12); mode.setAllCaps(false); mode.setBackground(round(0xBB0D5CA8,12)); mode.setFocusable(true); mode.setOnClickListener(v->showModeDialog());
        top.addView(mode,new LinearLayout.LayoutParams(tv?dp(160):dp(120),dp(46))); main.addView(top);

        TextView hero=text(tv?"Серебрянск • тысячи бесплатных каналов со всего мира":"Серебрянск • ТВ со всего мира",tv?20:14,false);
        hero.setTextColor(0xFFE8F3FA); main.addView(hero,new LinearLayout.LayoutParams(-1,tv?dp(45):dp(32)));

        LinearLayout searchRow = new LinearLayout(this); searchRow.setOrientation(LinearLayout.HORIZONTAL); searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("Поиск канала, страны или категории");
        searchBox.setHintTextColor(0xFF92A9B8);
        searchBox.setTextColor(Color.WHITE);
        searchBox.setTextSize(tv?17:14);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setPadding(dp(14),0,dp(14),0);
        searchBox.setBackground(round(0xCC102632,12));
        searchBox.setFocusable(true);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s == null ? "" : s.toString().trim().toLowerCase(Locale.ROOT);
                visibleLimit = 120;
                refreshGrid();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        searchRow.addView(searchBox,new LinearLayout.LayoutParams(0,tv?dp(50):dp(46),1));

        Button countries = new Button(this); countries.setText("🌍 Все страны"); countries.setAllCaps(false); countries.setTextColor(Color.WHITE); countries.setTextSize(tv?14:11); countries.setFocusable(true); countries.setBackground(round(0xCC0D5CA8,12)); countries.setOnClickListener(v->showCountryDialog());
        LinearLayout.LayoutParams cbp=new LinearLayout.LayoutParams(tv?dp(185):dp(132),tv?dp(50):dp(46)); cbp.leftMargin=dp(8); searchRow.addView(countries,cbp);
        main.addView(searchRow,new LinearLayout.LayoutParams(-1,tv?dp(60):dp(54)));

        catalogStatus=text("Загрузка мирового каталога…",tv?14:11,false); catalogStatus.setTextColor(0xFFB7CAD5);
        main.addView(catalogStatus,new LinearLayout.LayoutParams(-1,tv?dp(32):dp(28)));

        HorizontalScrollView catScroll=new HorizontalScrollView(this); catScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout catRow=new LinearLayout(this); catRow.setOrientation(LinearLayout.HORIZONTAL); catRow.setPadding(0,dp(4),0,dp(6));
        for(String cat:categories){
            Button b=new Button(this); b.setText(cat); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(tv?14:11); b.setFocusable(true); b.setTag(cat);
            styleCategoryButton(b,cat.equals(activeCategory)); b.setOnClickListener(v->{activeCategory=(String)v.getTag(); visibleLimit=120; refreshGrid(); refreshCategoryButtons(catRow);});
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,tv?dp(50):dp(42)); bp.rightMargin=dp(7); catRow.addView(b,bp);
        }
        catScroll.addView(catRow); main.addView(catScroll,new LinearLayout.LayoutParams(-1,tv?dp(64):dp(54)));

        channelTitle=text("Каналы",tv?23:19,true); main.addView(channelTitle,new LinearLayout.LayoutParams(-1,tv?dp(46):dp(40)));

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        channelGrid=new GridLayout(this); channelGrid.setColumnCount(tv?4:2); channelGrid.setUseDefaultMargins(false); channelGrid.setPadding(0,0,0,dp(80));
        scroll.addView(channelGrid,new ScrollView.LayoutParams(-1,-2));
        main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        refreshGrid();
        return main;
    }

    private void loadGlobalCatalog(boolean force) {
        if (catalogStatus != null) catalogStatus.setText(force ? "Обновляю мировой каталог…" : "Загрузка мирового каталога…");
        M3uCatalogLoader.load(this, force, new M3uCatalogLoader.Callback() {
            @Override public void onLoaded(List<Channel> channels, boolean fromCache, int streamEntries) {
                runOnUiThread(() -> {
                    mergeRemoteChannels(channels);
                    remoteLoaded = true;
                    if (catalogStatus != null) {
                        catalogStatus.setText("Каталог: " + allChannels.size() + " каналов • " + streamEntries + " потоков" + (fromCache ? " • кэш" : " • обновлено"));
                    }
                    visibleLimit = 120;
                    refreshGrid();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    if (catalogStatus != null) catalogStatus.setText("Мировой каталог недоступен. Показываю встроенные каналы.");
                    Toast.makeText(MainActivity.this, "Не удалось обновить каталог: " + message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void mergeRemoteChannels(List<Channel> remote) {
        List<Channel> merged = new ArrayList<>(ChannelRepository.all());
        Set<String> seen = new HashSet<>();
        for (Channel c : merged) seen.add(channelKey(c));
        for (Channel c : remote) {
            String key = channelKey(c);
            if (seen.add(key)) merged.add(c);
        }
        allChannels.clear();
        allChannels.addAll(merged);
    }

    private String channelKey(Channel c) {
        return normalizeName(c.name) + "|" + (c.country == null ? "" : c.country.toUpperCase(Locale.ROOT));
    }

    private String normalizeName(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", "").trim();
    }

    private void refreshCategoryButtons(LinearLayout row){
        for(int i=0;i<row.getChildCount();i++){
            View v=row.getChildAt(i); if(v instanceof Button) styleCategoryButton((Button)v, activeCategory.equals(v.getTag()));
        }
    }

    private void styleCategoryButton(Button b, boolean active){
        b.setBackground(round(active?0xEE157DE0:0xAA102632,12));
    }

    private boolean matches(Channel c){
        if(!activeCountry.isEmpty() && !activeCountry.equalsIgnoreCase(c.country)) return false;
        if("Казахстан".equals(activeCategory) && !"KZ".equals(c.country)) return false;
        else if("Россия".equals(activeCategory) && !"RU".equals(c.country)) return false;
        else if(!"Все".equals(activeCategory) && !"Казахстан".equals(activeCategory) && !"Россия".equals(activeCategory) && !activeCategory.equals(c.category)) return false;

        if(searchQuery.isEmpty()) return true;
        String hay = (c.name + " " + c.category + " " + c.country + " " + c.id).toLowerCase(Locale.ROOT);
        return hay.contains(searchQuery);
    }

    private void refreshGrid(){
        if(channelGrid==null)return;
        channelGrid.removeAllViews();
        int cols=tvMode?4:2; channelGrid.setColumnCount(cols);
        List<Channel> filtered = new ArrayList<>();
        for(Channel c:allChannels) if(matches(c)) filtered.add(c);
        int show = Math.min(visibleLimit, filtered.size());
        for(int i=0;i<show;i++) channelGrid.addView(channelCard(filtered.get(i), i));
        if(channelTitle!=null) channelTitle.setText("Каналы: " + filtered.size() + (activeCountry.isEmpty()?"":" • "+flagFor(activeCountry)+" "+activeCountry));
        if(show < filtered.size()) channelGrid.addView(showMoreCard(show, filtered.size()));
        if(filtered.isEmpty()){
            TextView empty=text(remoteLoaded?"Ничего не найдено":"Каталог загружается…",16,false);
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=-1; gp.height=dp(80); gp.setMargins(dp(4),dp(4),dp(4),dp(4)); empty.setLayoutParams(gp); channelGrid.addView(empty);
        }
    }

    private View showMoreCard(int shown, int total) {
        Button b=new Button(this); b.setAllCaps(false); b.setText("Показать ещё\n"+shown+" / "+total); b.setTextColor(Color.WHITE); b.setTextSize(tvMode?16:13); b.setFocusable(true); b.setBackground(round(0xDD0D5CA8,16));
        b.setOnClickListener(v->{visibleLimit += 120; refreshGrid();});
        int screen = getResources().getDisplayMetrics().widthPixels;
        int usable = tvMode ? screen-dp(320) : screen-dp(40);
        int w = Math.max(dp(150), usable/(tvMode?4:2)-dp(10));
        GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=w; gp.height=tvMode?dp(136):dp(112); gp.setMargins(dp(4),dp(4),dp(4),dp(4)); b.setLayoutParams(gp);
        return b;
    }

    private View channelCard(Channel c, int filteredIndex){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(dp(10),dp(9),dp(10),dp(9));
        card.setFocusable(true); card.setClickable(true); card.setBackground(round(0xD91A2D38,16));
        TextView badge=text(c.name,tvMode?20:15,true); badge.setGravity(Gravity.CENTER); badge.setTextColor(Color.WHITE); badge.setMaxLines(2); GradientDrawable bd=round(c.accent,12); badge.setBackground(bd);
        card.addView(badge,new LinearLayout.LayoutParams(-1,tvMode?dp(82):dp(62)));
        String metaText=(c.country.isEmpty()?"🌐":flagFor(c.country)+" "+c.country)+" • "+c.category;
        TextView meta=text(metaText,tvMode?12:10,false); meta.setTextColor(0xFFCAD7DF); meta.setGravity(Gravity.CENTER); card.addView(meta,new LinearLayout.LayoutParams(-1,dp(32)));
        card.setOnClickListener(v->openChannel(c));
        card.setOnFocusChangeListener((v,has)-> { v.setScaleX(has?1.035f:1f); v.setScaleY(has?1.035f:1f); v.setAlpha(has?1f:.94f); });
        int screen = getResources().getDisplayMetrics().widthPixels;
        int usable = tvMode ? screen-dp(320) : screen-dp(40);
        int w = Math.max(dp(150), usable/(tvMode?4:2)-dp(10));
        GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=w; gp.height=tvMode?dp(136):dp(112); gp.setMargins(dp(4),dp(4),dp(4),dp(4));
        card.setLayoutParams(gp); return card;
    }

    private String flagFor(String code) {
        if(code==null || code.length()!=2) return "🌐";
        String up=code.toUpperCase(Locale.ROOT);
        int first=0x1F1E6+(up.charAt(0)-'A');
        int second=0x1F1E6+(up.charAt(1)-'A');
        return new String(Character.toChars(first))+new String(Character.toChars(second));
    }

    private void openChannel(Channel c){
        Intent i=new Intent(this,PlayerActivity.class);
        i.putExtra("name",c.name);
        i.putExtra("url",c.url);
        i.putExtra("urls",c.urls);
        i.putExtra("user_agents",c.userAgents);
        i.putExtra("referrers",c.referrers);
        i.putExtra("ui_tv",tvMode);
        startActivity(i);
    }

    private void showCountryDialog(){
        TreeSet<String> codes=new TreeSet<>();
        for(Channel c:allChannels) if(c.country!=null && c.country.length()==2) codes.add(c.country.toUpperCase(Locale.ROOT));
        List<String> values=new ArrayList<>(); values.add(""); values.addAll(codes);
        String[] labels=new String[values.size()];
        labels[0]="🌍 Все страны";
        for(int i=1;i<values.size();i++) labels[i]=flagFor(values.get(i))+" "+values.get(i);
        new AlertDialog.Builder(this).setTitle("Выберите страну").setItems(labels,(d,which)->{
            activeCountry=values.get(which); visibleLimit=120; refreshGrid();
        }).setNegativeButton("Отмена",null).show();
    }

    private void showModeDialog(){
        String[] modes={"Авто — определить устройство","Телефон / планшет","Android TV"};
        new AlertDialog.Builder(this).setTitle("Режим интерфейса").setItems(modes,(d,which)->{
            String val=which==0?"auto":which==1?"phone":"tv";
            getSharedPreferences("nikita_tv",MODE_PRIVATE).edit().putString("ui_mode",val).apply(); recreate();
        }).setNegativeButton("Отмена",null).show();
    }
}
