package kz.nikita.tv;

import android.app.*;
import android.app.UiModeManager;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private final List<Channel> allChannels = new ArrayList<>();
    private GridLayout channelGrid;
    private TextView catalogStatus;
    private TextView channelTitle;
    private EditText searchBox;
    private TextView previewName;
    private TextView previewNow;
    private Button previewInfo;
    private Channel previewChannel;
    private String activeCategory = "Все";
    private String activeCountry = "";
    private String searchQuery = "";
    private int visibleLimit = 120;
    private boolean tvMode;
    private boolean remoteLoaded = false;
    private LinearLayout content;
    private final String[] categories = {
            "Все", "Казахстан", "Россия", "Новости", "Развлекательные", "Кино",
            "Сериалы", "Детские", "Спорт", "Музыка", "Документальные", "Культура"
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,14,22));
        getWindow().setNavigationBarColor(Color.rgb(5,14,22));
        tvMode = resolveTvMode();
        allChannels.addAll(ChannelRepository.all());
        buildUi();
        loadGlobalCatalog(false);
    }

    private boolean resolveTvMode() {
        String mode = getSharedPreferences("nikita_tv", MODE_PRIVATE).getString("ui_mode", "auto");
        if ("tv".equals(mode)) return true;
        if ("phone".equals(mode)) return false;
        UiModeManager um = (UiModeManager)getSystemService(UI_MODE_SERVICE);
        if (um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        return getResources().getConfiguration().smallestScreenWidthDp >= 720;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        ImageView bg = new ImageView(this); bg.setImageResource(R.drawable.bg_serebryansk); bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x66000000,0xB8061119,0xF2050E16}));
        root.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        if (tvMode) root.addView(buildTvLayout()); else root.addView(buildPhoneLayout());
        setContentView(root);
    }

    private View buildTvLayout() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(dp(22),dp(20),dp(22),dp(18));
        row.addView(buildSidebar(), new LinearLayout.LayoutParams(dp(250), -1));
        content = buildContent(true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,-1,1); cp.leftMargin=dp(18); row.addView(content, cp); return row;
    }

    private View buildPhoneLayout() { content = buildContent(false); return content; }

    private View buildSidebar() {
        LinearLayout side = new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(dp(14),dp(14),dp(14),dp(14)); side.setBackground(round(0xB8071621,18));
        TextView logo=text("Никита ТВ",29,true); side.addView(logo,new LinearLayout.LayoutParams(-1,dp(64)));
        String[] items={"⌂  Главная","▣  ТВ каналы","🌍  Выбрать страну","↻  Обновить каталог","★  Избранное","◷  История","ℹ  О программе","⚙  Режим интерфейса"};
        for(String s:items){
            TextView v=text(s,17,false); v.setFocusable(true); v.setClickable(true); v.setPadding(dp(14),0,dp(8),0); v.setBackground(round(0x221E88E5,12));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.bottomMargin=dp(8); side.addView(v,p);
            if(s.contains("Режим")) v.setOnClickListener(x->showModeDialog());
            else if(s.contains("О программе")) v.setOnClickListener(x->showAboutDialog());
            else if(s.contains("страну")) v.setOnClickListener(x->showCountryDialog());
            else if(s.contains("Обновить")) v.setOnClickListener(x->loadGlobalCatalog(true));
        }
        side.addView(new Space(this),new LinearLayout.LayoutParams(1,0,1));
        TextView city=text("●  Серебрянск, ВКО\n   Бесплатное ТВ",14,false); city.setTextColor(0xFFD7E6F2); side.addView(city,new LinearLayout.LayoutParams(-1,dp(70)));
        return side;
    }

    private LinearLayout buildContent(boolean tv) {
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL); main.setPadding(tv?dp(10):dp(16), tv?0:dp(12), tv?dp(10):dp(16), dp(10));

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("Никита ТВ", tv?34:27,true); top.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        Button about=new Button(this); about.setText("ℹ О программе"); about.setTextColor(Color.WHITE); about.setTextSize(tv?15:11); about.setAllCaps(false); about.setBackground(round(0xBB173B4E,12)); about.setFocusable(true); about.setOnClickListener(v->showAboutDialog());
        LinearLayout.LayoutParams abp=new LinearLayout.LayoutParams(tv?dp(175):dp(124),dp(46)); abp.rightMargin=dp(8); top.addView(about,abp);
        Button mode=new Button(this); mode.setText(tv?"📺 ТВ":"📱 Телефон"); mode.setTextColor(Color.WHITE); mode.setTextSize(tv?16:12); mode.setAllCaps(false); mode.setBackground(round(0xBB0D5CA8,12)); mode.setFocusable(true); mode.setOnClickListener(v->showModeDialog());
        top.addView(mode,new LinearLayout.LayoutParams(tv?dp(160):dp(112),dp(46))); main.addView(top);

        TextView hero=text(tv?"Серебрянск • бесплатные каналы • программа передач":"Серебрянск • ТВ со всего мира",tv?20:14,false); hero.setTextColor(0xFFE8F3FA);
        main.addView(hero,new LinearLayout.LayoutParams(-1,tv?dp(45):dp(32)));

        LinearLayout searchRow = new LinearLayout(this); searchRow.setOrientation(LinearLayout.HORIZONTAL); searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchBox = new EditText(this); searchBox.setSingleLine(true); searchBox.setHint("Поиск канала, страны или категории"); searchBox.setHintTextColor(0xFF92A9B8); searchBox.setTextColor(Color.WHITE); searchBox.setTextSize(tv?17:14); searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH); searchBox.setPadding(dp(14),0,dp(14),0); searchBox.setBackground(round(0xCC102632,12)); searchBox.setFocusable(true);
        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){searchQuery=s==null?"":s.toString().trim().toLowerCase(Locale.ROOT);visibleLimit=120;refreshGrid();}
            public void afterTextChanged(Editable s){}
        });
        searchRow.addView(searchBox,new LinearLayout.LayoutParams(0,tv?dp(50):dp(46),1));
        Button countries = new Button(this); countries.setText("🌍 Все страны"); countries.setAllCaps(false); countries.setTextColor(Color.WHITE); countries.setTextSize(tv?14:11); countries.setFocusable(true); countries.setBackground(round(0xCC0D5CA8,12)); countries.setOnClickListener(v->showCountryDialog());
        LinearLayout.LayoutParams cbp=new LinearLayout.LayoutParams(tv?dp(185):dp(132),tv?dp(50):dp(46)); cbp.leftMargin=dp(8); searchRow.addView(countries,cbp); main.addView(searchRow,new LinearLayout.LayoutParams(-1,tv?dp(60):dp(54)));

        catalogStatus=text("Загрузка мирового каталога…",tv?14:11,false); catalogStatus.setTextColor(0xFFB7CAD5); main.addView(catalogStatus,new LinearLayout.LayoutParams(-1,tv?dp(32):dp(28)));

        HorizontalScrollView catScroll=new HorizontalScrollView(this); catScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout catRow=new LinearLayout(this); catRow.setOrientation(LinearLayout.HORIZONTAL); catRow.setPadding(0,dp(4),0,dp(6));
        for(String cat:categories){
            Button b=new Button(this); b.setText(cat); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(tv?14:11); b.setFocusable(true); b.setTag(cat); styleCategoryButton(b,cat.equals(activeCategory));
            b.setOnClickListener(v->{activeCategory=(String)v.getTag();visibleLimit=120;refreshGrid();refreshCategoryButtons(catRow);});
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,tv?dp(50):dp(42));bp.rightMargin=dp(7);catRow.addView(b,bp);
        }
        catScroll.addView(catRow); main.addView(catScroll,new LinearLayout.LayoutParams(-1,tv?dp(64):dp(54)));

        channelTitle=text("Каналы",tv?23:19,true); main.addView(channelTitle,new LinearLayout.LayoutParams(-1,tv?dp(44):dp(38)));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        channelGrid=new GridLayout(this); channelGrid.setColumnCount(tv?4:2); channelGrid.setUseDefaultMargins(false); channelGrid.setPadding(0,0,0,dp(24));
        scroll.addView(channelGrid,new ScrollView.LayoutParams(-1,-2)); main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        main.addView(buildPreviewPanel(tv), new LinearLayout.LayoutParams(-1,tv?dp(92):dp(78)));
        refreshGrid(); return main;
    }

    private View buildPreviewPanel(boolean tv) {
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.HORIZONTAL); panel.setGravity(Gravity.CENTER_VERTICAL); panel.setPadding(dp(14),dp(8),dp(10),dp(8)); panel.setBackground(round(0xE30A1D29,16));
        LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
        previewName = text("Выберите канал", tv?18:14, true); previewNow = text("Внизу появится, что сейчас идёт в эфире", tv?15:12, false); previewNow.setTextColor(0xFFBBD0DC); previewNow.setSingleLine(true); previewNow.setEllipsize(android.text.TextUtils.TruncateAt.END);
        texts.addView(previewName,new LinearLayout.LayoutParams(-1,0,1)); texts.addView(previewNow,new LinearLayout.LayoutParams(-1,0,1)); panel.addView(texts,new LinearLayout.LayoutParams(0,-1,1));
        previewInfo = new Button(this); previewInfo.setText("ⓘ\nПрограмма"); previewInfo.setAllCaps(false); previewInfo.setTextColor(Color.WHITE); previewInfo.setTextSize(tv?13:10); previewInfo.setFocusable(true); previewInfo.setEnabled(false); previewInfo.setBackground(round(0xCC0D5CA8,12)); previewInfo.setOnClickListener(v->{if(previewChannel!=null)showSchedule(previewChannel);});
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(tv?dp(132):dp(94),-1); ip.leftMargin=dp(10); panel.addView(previewInfo,ip); return panel;
    }

    private void loadGlobalCatalog(boolean force) {
        if (catalogStatus != null) catalogStatus.setText(force ? "Обновляю мировой каталог…" : "Загрузка мирового каталога…");
        M3uCatalogLoader.load(this, force, new M3uCatalogLoader.Callback() {
            @Override public void onLoaded(List<Channel> channels, boolean fromCache, int streamEntries) {
                runOnUiThread(() -> {mergeRemoteChannels(channels);remoteLoaded=true;if(catalogStatus!=null)catalogStatus.setText("Каталог: "+allChannels.size()+" каналов • "+streamEntries+" потоков"+(fromCache?" • кэш":" • обновлено"));visibleLimit=120;refreshGrid();});
            }
            @Override public void onError(String message) {runOnUiThread(() -> {if(catalogStatus!=null)catalogStatus.setText("Мировой каталог недоступен. Показываю встроенные каналы.");Toast.makeText(MainActivity.this,"Не удалось обновить каталог: "+message,Toast.LENGTH_LONG).show();});}
        });
    }

    private void mergeRemoteChannels(List<Channel> remote) {
        List<Channel> merged = new ArrayList<>(ChannelRepository.all());
        Map<String,Integer> positions = new HashMap<>();
        for (int i=0;i<merged.size();i++) positions.put(channelKey(merged.get(i)), i);
        for (Channel r : remote) {
            String key = channelKey(r);
            Integer pos = positions.get(key);
            if (pos == null) {
                positions.put(key, merged.size());
                merged.add(r);
            } else {
                Channel local = merged.get(pos);
                String[] urls = concatUnique(local.urls, r.urls);
                String[] uas = concatParallel(local.urls, local.userAgents, r.urls, r.userAgents, urls);
                String[] refs = concatParallel(local.urls, local.referrers, r.urls, r.referrers, urls);
                Channel enriched = new Channel(local.id.isEmpty()?r.id:local.id, local.name, local.category, local.country,
                        local.logo.isEmpty()?r.logo:local.logo, urls, uas, refs, local.accent);
                merged.set(pos, enriched);
            }
        }
        allChannels.clear(); allChannels.addAll(merged);
    }

    private String[] concatUnique(String[] a, String[] b) {
        LinkedHashSet<String> set = new LinkedHashSet<>();
        if (a != null) for (String x : a) if (x != null && !x.isEmpty()) set.add(x);
        if (b != null) for (String x : b) if (x != null && !x.isEmpty()) set.add(x);
        return set.toArray(new String[0]);
    }

    private String[] concatParallel(String[] aUrls, String[] aValues, String[] bUrls, String[] bValues, String[] mergedUrls) {
        Map<String,String> byUrl = new HashMap<>();
        if (aUrls != null) for (int i=0;i<aUrls.length;i++) byUrl.put(aUrls[i], aValues!=null && i<aValues.length ? aValues[i] : "");
        if (bUrls != null) for (int i=0;i<bUrls.length;i++) if (!byUrl.containsKey(bUrls[i])) byUrl.put(bUrls[i], bValues!=null && i<bValues.length ? bValues[i] : "");
        String[] out = new String[mergedUrls.length];
        for (int i=0;i<mergedUrls.length;i++) out[i] = byUrl.containsKey(mergedUrls[i]) ? byUrl.get(mergedUrls[i]) : "";
        return out;
    }
    private String channelKey(Channel c){return normalizeName(c.name)+"|"+(c.country==null?"":c.country.toUpperCase(Locale.ROOT));}
    private String normalizeName(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+","").trim();}
    private void refreshCategoryButtons(LinearLayout row){for(int i=0;i<row.getChildCount();i++){View v=row.getChildAt(i);if(v instanceof Button)styleCategoryButton((Button)v,activeCategory.equals(v.getTag()));}}
    private void styleCategoryButton(Button b,boolean active){b.setBackground(round(active?0xEE157DE0:0xAA102632,12));}

    private boolean matches(Channel c) {
        if(!activeCountry.isEmpty()&&!activeCountry.equalsIgnoreCase(c.country))return false;
        if("Казахстан".equals(activeCategory)&&!"KZ".equals(c.country))return false;
        else if("Россия".equals(activeCategory)&&!"RU".equals(c.country))return false;
        else if(!"Все".equals(activeCategory)&&!"Казахстан".equals(activeCategory)&&!"Россия".equals(activeCategory)&&!activeCategory.equals(c.category))return false;
        if(searchQuery.isEmpty())return true;
        String hay=(c.name+" "+c.category+" "+c.country+" "+c.id).toLowerCase(Locale.ROOT);return hay.contains(searchQuery);
    }

    private List<Channel> filteredChannels() {List<Channel> out=new ArrayList<>();for(Channel c:allChannels)if(matches(c))out.add(c);return out;}

    private void refreshGrid() {
        if(channelGrid==null)return;channelGrid.removeAllViews();channelGrid.setColumnCount(tvMode?4:2);List<Channel> filtered=filteredChannels();int show=Math.min(visibleLimit,filtered.size());
        for(int i=0;i<show;i++)channelGrid.addView(channelCard(filtered.get(i)));
        if(channelTitle!=null)channelTitle.setText("Каналы: "+filtered.size()+(activeCountry.isEmpty()?"":" • "+flagFor(activeCountry)+" "+activeCountry));
        if(show<filtered.size())channelGrid.addView(showMoreCard(show,filtered.size()));
        if(filtered.isEmpty()){TextView empty=text(remoteLoaded?"Ничего не найдено":"Каталог загружается…",16,false);GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=-1;gp.height=dp(80);gp.setMargins(dp(4),dp(4),dp(4),dp(4));empty.setLayoutParams(gp);channelGrid.addView(empty);}
    }

    private View showMoreCard(int shown,int total) {
        Button b=new Button(this);b.setAllCaps(false);b.setText("Показать ещё\n"+shown+" / "+total);b.setTextColor(Color.WHITE);b.setTextSize(tvMode?16:13);b.setFocusable(true);b.setBackground(round(0xDD0D5CA8,16));b.setOnClickListener(v->{visibleLimit+=120;refreshGrid();});
        int screen=getResources().getDisplayMetrics().widthPixels;int usable=tvMode?screen-dp(320):screen-dp(40);int w=Math.max(dp(150),usable/(tvMode?4:2)-dp(10));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=w;gp.height=tvMode?dp(166):dp(144);gp.setMargins(dp(4),dp(4),dp(4),dp(4));b.setLayoutParams(gp);return b;
    }

    private View channelCard(Channel c) {
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);card.setPadding(dp(8),dp(8),dp(8),dp(7));card.setFocusable(true);card.setClickable(true);card.setBackground(round(0xD91A2D38,16));
        TextView badge=text(c.name,tvMode?19:14,true);badge.setGravity(Gravity.CENTER);badge.setTextColor(Color.WHITE);badge.setMaxLines(2);badge.setBackground(round(c.accent,12));card.addView(badge,new LinearLayout.LayoutParams(-1,tvMode?dp(76):dp(58)));
        LinearLayout metaRow=new LinearLayout(this);metaRow.setGravity(Gravity.CENTER_VERTICAL);
        String metaText=(c.country.isEmpty()?"🌐":flagFor(c.country)+" "+c.country)+" • "+c.category;TextView meta=text(metaText,tvMode?11:9,false);meta.setTextColor(0xFFCAD7DF);meta.setGravity(Gravity.CENTER);metaRow.addView(meta,new LinearLayout.LayoutParams(0,dp(28),1));
        Button info=new Button(this);info.setText("ⓘ");info.setTextColor(Color.WHITE);info.setTextSize(tvMode?15:12);info.setAllCaps(false);info.setFocusable(true);info.setBackground(round(0xAA0D5CA8,10));info.setOnClickListener(v->{showPreview(c,null);showSchedule(c);});metaRow.addView(info,new LinearLayout.LayoutParams(tvMode?dp(42):dp(34),dp(28)));card.addView(metaRow,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView now=text("Сейчас: наведите для программы",tvMode?11:9,false);now.setTextColor(0xFF8FC5EA);now.setSingleLine(true);now.setEllipsize(android.text.TextUtils.TruncateAt.END);now.setGravity(Gravity.CENTER);card.addView(now,new LinearLayout.LayoutParams(-1,tvMode?dp(28):dp(24)));
        card.setOnClickListener(v->openChannel(c));
        card.setOnFocusChangeListener((v,has)->{v.setScaleX(has?1.035f:1f);v.setScaleY(has?1.035f:1f);v.setAlpha(has?1f:.94f);if(has)showPreview(c,now);});
        card.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN)showPreview(c,now);return false;});
        int screen=getResources().getDisplayMetrics().widthPixels;int usable=tvMode?screen-dp(320):screen-dp(40);int w=Math.max(dp(150),usable/(tvMode?4:2)-dp(10));GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=w;gp.height=tvMode?dp(166):dp(144);gp.setMargins(dp(4),dp(4),dp(4),dp(4));card.setLayoutParams(gp);return card;
    }

    private void showPreview(Channel c,TextView cardNow) {
        previewChannel=c;if(previewName!=null)previewName.setText(c.name+(c.country.isEmpty()?"":" • "+flagFor(c.country)+" "+c.country));if(previewNow!=null)previewNow.setText("Сейчас: загружаю программу…");if(previewInfo!=null){previewInfo.setEnabled(true);previewInfo.setAlpha(1f);}if(cardNow!=null)cardNow.setText("Сейчас: загрузка…");
        final Channel requested=c;EpgRepository.loadSchedule(this,c,new EpgRepository.Callback(){
            @Override public void onLoaded(List<EpgRepository.ProgramInfo> programs){runOnUiThread(()->{EpgRepository.ProgramInfo p=EpgRepository.current(programs);String line=p==null?"Сейчас: программа не указана":"Сейчас • "+p.timeRange()+" • "+(p.title.isEmpty()?"Без названия":p.title);if(previewChannel==requested&&previewNow!=null)previewNow.setText(line);if(cardNow!=null)cardNow.setText(p==null?"Сейчас: нет данных":"Сейчас: "+p.title);});}
            @Override public void onUnavailable(String reason){runOnUiThread(()->{if(previewChannel==requested&&previewNow!=null)previewNow.setText("Программа: "+reason);if(cardNow!=null)cardNow.setText("Сейчас: EPG нет");});}
        });
    }

    private void showSchedule(Channel c) {
        ProgressDialog loading=new ProgressDialog(this);loading.setMessage("Загружаю программу…");loading.setCancelable(true);loading.show();
        EpgRepository.loadSchedule(this,c,new EpgRepository.Callback(){
            @Override public void onLoaded(List<EpgRepository.ProgramInfo> programs){runOnUiThread(()->{if(loading.isShowing())loading.dismiss();List<EpgRepository.ProgramInfo> items=EpgRepository.upcoming(programs,14);if(items.isEmpty()){showScheduleMessage(c,"На ближайшее время передач нет");return;}String[] rows=new String[items.size()];EpgRepository.ProgramInfo current=EpgRepository.current(programs);for(int i=0;i<items.size();i++){EpgRepository.ProgramInfo p=items.get(i);rows[i]=p.timeRange()+(p==current?"   ● СЕЙЧАС":"")+"\n"+(p.title.isEmpty()?"Без названия":p.title);}new AlertDialog.Builder(MainActivity.this).setTitle("ⓘ "+c.name+" — программа").setItems(rows,(d,which)->{EpgRepository.ProgramInfo p=items.get(which);if(!p.description.isEmpty())new AlertDialog.Builder(MainActivity.this).setTitle(p.title).setMessage(p.timeRange()+"\n\n"+p.description).setPositiveButton("Закрыть",null).show();}).setPositiveButton("Закрыть",null).show();});}
            @Override public void onUnavailable(String reason){runOnUiThread(()->{if(loading.isShowing())loading.dismiss();showScheduleMessage(c,reason);});}
        });
    }
    private void showScheduleMessage(Channel c,String msg){new AlertDialog.Builder(this).setTitle("ⓘ "+c.name).setMessage(msg).setPositiveButton("Закрыть",null).show();}

    private String flagFor(String code){if(code==null||code.length()!=2)return"🌐";String up=code.toUpperCase(Locale.ROOT);int first=0x1F1E6+(up.charAt(0)-'A');int second=0x1F1E6+(up.charAt(1)-'A');return new String(Character.toChars(first))+new String(Character.toChars(second));}

    private void openChannel(Channel c) {
        ChannelSession.setChannels(filteredChannels(),c);
        Intent i=new Intent(this,PlayerActivity.class);i.putExtra("id",c.id);i.putExtra("name",c.name);i.putExtra("category",c.category);i.putExtra("country",c.country);i.putExtra("logo",c.logo);i.putExtra("accent",c.accent);i.putExtra("url",c.url);i.putExtra("urls",c.urls);i.putExtra("user_agents",c.userAgents);i.putExtra("referrers",c.referrers);i.putExtra("ui_tv",tvMode);startActivity(i);
    }

    private void showCountryDialog(){TreeSet<String> codes=new TreeSet<>();for(Channel c:allChannels)if(c.country!=null&&c.country.length()==2)codes.add(c.country.toUpperCase(Locale.ROOT));List<String> values=new ArrayList<>();values.add("");values.addAll(codes);String[] labels=new String[values.size()];labels[0]="🌍 Все страны";for(int i=1;i<values.size();i++)labels[i]=flagFor(values.get(i))+" "+values.get(i);new AlertDialog.Builder(this).setTitle("Выберите страну").setItems(labels,(d,which)->{activeCountry=values.get(which);visibleLimit=120;refreshGrid();}).setNegativeButton("Отмена",null).show();}

    private void showAboutDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(8),dp(22),dp(4));TextView app=text("Никита ТВ",24,true);app.setTextColor(0xFF156FD1);box.addView(app,new LinearLayout.LayoutParams(-1,dp(52)));TextView developer=text("Разработчик\nАнтошкин Никита Викторович",17,true);box.addView(developer,new LinearLayout.LayoutParams(-1,dp(72)));TextView info=text("Приложение полностью бесплатное.\nПодписка и оплата за просмотр не требуются.\n\nЕсли приложение вам нравится, вы можете добровольно поддержать разработчика.\n\nKaspi: 4400 **** **** 3484\n\nВерсия 0.5.0",15,false);info.setTextColor(0xFFD7E6F2);info.setGravity(Gravity.TOP|Gravity.START);box.addView(info,new LinearLayout.LayoutParams(-1,-2));new AlertDialog.Builder(this).setTitle("О программе").setView(box).setPositiveButton("Закрыть",null).show();
    }

    private void showModeDialog(){String[] modes={"Авто — определить устройство","Телефон / планшет","Android TV"};new AlertDialog.Builder(this).setTitle("Режим интерфейса").setItems(modes,(d,which)->{String val=which==0?"auto":which==1?"phone":"tv";getSharedPreferences("nikita_tv",MODE_PRIVATE).edit().putString("ui_mode",val).apply();recreate();}).setNegativeButton("Отмена",null).show();}
}
