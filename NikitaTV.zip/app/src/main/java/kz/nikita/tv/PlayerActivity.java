package kz.nikita.tv;

import android.app.*;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.ui.PlayerView;

import java.text.SimpleDateFormat;
import java.util.*;

@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {
    private PlayerView playerView;
    private ExoPlayer player;
    private ProgressBar progress;
    private TextView status;
    private TextView titleView;
    private TextView nowProgramView;
    private LinearLayout topBar;
    private LinearLayout controlsPanel;
    private FrameLayout root;
    private Button playPauseButton;
    private Button muteButton;

    private Channel currentChannel;
    private String name;
    private String[] urls;
    private String[] userAgents;
    private String[] referrers;
    private boolean tvMode;
    private int sourceIndex = 0;
    private boolean exhausted = false;
    private boolean currentSourcePlayed = false;
    private int playAttempt = 0;
    private Runnable startupTimeout;
    private Runnable bufferingTimeout;
    private Runnable hideControlsRunnable;
    private static final long SOURCE_TIMEOUT_MS = 30000L;
    private static final long CONTROLS_HIDE_MS = 6500L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audioManager;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        hideSystemBars();
        tvMode = getIntent().getBooleanExtra("ui_tv", false);
        audioManager = (AudioManager)getSystemService(AUDIO_SERVICE);

        Channel fromSession = ChannelSession.current();
        if (fromSession != null) currentChannel = fromSession;
        else currentChannel = channelFromIntent();
        applyChannel(currentChannel);

        build();
        initPlayer();
        playCurrent();
        showControls(true);
    }

    private Channel channelFromIntent() {
        String n = getIntent().getStringExtra("name");
        String id = getIntent().getStringExtra("id");
        String category = getIntent().getStringExtra("category");
        String country = getIntent().getStringExtra("country");
        String logo = getIntent().getStringExtra("logo");
        int accent = getIntent().getIntExtra("accent", Color.rgb(35, 94, 140));
        String[] u = getIntent().getStringArrayExtra("urls");
        if (u == null || u.length == 0) {
            String single = getIntent().getStringExtra("url");
            u = single == null ? new String[0] : new String[]{single};
        }
        return new Channel(id, n == null ? "Канал" : n, category, country, logo, u,
                getIntent().getStringArrayExtra("user_agents"),
                getIntent().getStringArrayExtra("referrers"), accent);
    }

    private void applyChannel(Channel c) {
        if (c == null) return;
        currentChannel = c;
        ChannelSession.setCurrent(c);
        name = c.name;
        urls = c.urls == null ? new String[0] : c.urls;
        userAgents = normalize(c.userAgents, urls.length);
        referrers = normalize(c.referrers, urls.length);
        sourceIndex = 0;
        exhausted = false;
        currentSourcePlayed = false;
        if (titleView != null) titleView.setText(name);
        if (nowProgramView != null) nowProgramView.setText("Сейчас: загружаю программу…");
    }

    private String[] normalize(String[] src, int len) {
        String[] out = new String[len];
        if (src != null) System.arraycopy(src, 0, out, 0, Math.min(src.length, len));
        for (int i = 0; i < out.length; i++) if (out[i] == null) out[i] = "";
        return out;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable round(int c, int r) { GradientDrawable d = new GradientDrawable(); d.setColor(c); d.setCornerRadius(dp(r)); return d; }
    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    private Button controlButton(String label, int width) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(tvMode ? 15 : 12); b.setAllCaps(false);
        b.setFocusable(true); b.setBackground(round(0xDD102735, 14)); b.setPadding(dp(7), 0, dp(7), 0);
        b.setOnFocusChangeListener((v, has) -> {
            v.setScaleX(has ? 1.07f : 1f); v.setScaleY(has ? 1.07f : 1f);
            v.setBackground(round(has ? 0xEE0D6FCA : 0xDD102735, 14));
            if (has) scheduleControlsHide();
        });
        b.setLayoutParams(new LinearLayout.LayoutParams(dp(width), tvMode ? dp(58) : dp(50)));
        return b;
    }

    private void build() {
        root = new FrameLayout(this); root.setBackgroundColor(Color.BLACK); root.setFocusableInTouchMode(true);

        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setKeepScreenOn(true);
        playerView.setClickable(true);
        playerView.setFocusable(false);
        playerView.setOnClickListener(v -> toggleControls());
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this); topBar.setGravity(Gravity.CENTER_VERTICAL); topBar.setPadding(dp(18), dp(10), dp(18), dp(10)); topBar.setBackgroundColor(0xB0000000);
        Button back = controlButton("‹", 58); back.setTextSize(tvMode ? 28 : 23); back.setOnClickListener(v -> finish());
        topBar.addView(back);
        titleView = text(name == null ? "Канал" : name, tvMode ? 24 : 19, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(50), 1); tp.leftMargin = dp(14); topBar.addView(titleView, tp);
        TextView live = text("● LIVE", tvMode ? 15 : 12, true); live.setTextColor(0xFFFF4B55); live.setGravity(Gravity.CENTER);
        topBar.addView(live, new LinearLayout.LayoutParams(dp(82), dp(50)));
        FrameLayout.LayoutParams topP = new FrameLayout.LayoutParams(-1, dp(72), Gravity.TOP); root.addView(topBar, topP);

        progress = new ProgressBar(this); FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER); root.addView(progress, pp);
        status = text("Подключение…", tvMode ? 16 : 13, false); status.setGravity(Gravity.CENTER); status.setBackground(round(0xCC000000, 10)); status.setPadding(dp(14), dp(8), dp(14), dp(8));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER); sp.topMargin = dp(82); root.addView(status, sp);

        controlsPanel = new LinearLayout(this); controlsPanel.setOrientation(LinearLayout.VERTICAL); controlsPanel.setPadding(dp(16), dp(12), dp(16), dp(16)); controlsPanel.setBackground(round(0xE6081722, 20));
        nowProgramView = text("Сейчас: загружаю программу…", tvMode ? 16 : 13, false); nowProgramView.setTextColor(0xFFD6E8F4); nowProgramView.setSingleLine(true); nowProgramView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        controlsPanel.addView(nowProgramView, new LinearLayout.LayoutParams(-1, tvMode ? dp(40) : dp(34)));

        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); hsv.setFillViewport(true);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER); row.setPadding(dp(2), dp(2), dp(2), dp(2));

        Button prev = controlButton("⏮ Предыдущий", tvMode ? 150 : 125); prev.setOnClickListener(v -> switchRelative(-1)); row.addView(prev);
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(dp(8), 1);
        row.addView(new Space(this), gap);
        playPauseButton = controlButton("⏸ Пауза", tvMode ? 125 : 105); playPauseButton.setOnClickListener(v -> togglePlayPause()); row.addView(playPauseButton);
        row.addView(new Space(this), new LinearLayout.LayoutParams(dp(8), 1));
        Button next = controlButton("Следующий ⏭", tvMode ? 150 : 125); next.setOnClickListener(v -> switchRelative(1)); row.addView(next);
        row.addView(new Space(this), new LinearLayout.LayoutParams(dp(8), 1));
        Button search = controlButton("🔎 Поиск", tvMode ? 120 : 100); search.setOnClickListener(v -> showChannelSearch()); row.addView(search);
        row.addView(new Space(this), new LinearLayout.LayoutParams(dp(8), 1));
        Button volDown = controlButton("🔉 −", tvMode ? 90 : 72); volDown.setOnClickListener(v -> adjustVolume(-1)); row.addView(volDown);
        row.addView(new Space(this), new LinearLayout.LayoutParams(dp(6), 1));
        muteButton = controlButton("🔇", tvMode ? 82 : 66); muteButton.setOnClickListener(v -> toggleMute()); row.addView(muteButton);
        row.addView(new Space(this), new LinearLayout.LayoutParams(dp(6), 1));
        Button volUp = controlButton("🔊 +", tvMode ? 90 : 72); volUp.setOnClickListener(v -> adjustVolume(1)); row.addView(volUp);
        row.addView(new Space(this), new LinearLayout.LayoutParams(dp(8), 1));
        Button info = controlButton("ⓘ Программа", tvMode ? 135 : 112); info.setOnClickListener(v -> showSchedule()); row.addView(info);

        hsv.addView(row); controlsPanel.addView(hsv, new LinearLayout.LayoutParams(-1, tvMode ? dp(66) : dp(58)));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, tvMode ? dp(126) : dp(112), Gravity.BOTTOM); cp.leftMargin = dp(18); cp.rightMargin = dp(18); cp.bottomMargin = dp(18); root.addView(controlsPanel, cp);

        root.setOnClickListener(v -> toggleControls());
        setContentView(root);
    }

    private void initPlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                updatePlayButton();
                if (state == Player.STATE_BUFFERING) {
                    progress.setVisibility(View.VISIBLE);
                    status.setText(sourceText(currentSourcePlayed ? "Буферизация… 30 сек до смены потока" : "Подключение / буферизация…"));
                    status.setVisibility(View.VISIBLE);
                    if (currentSourcePlayed && player.getPlayWhenReady()) startBufferingTimeout();
                } else if (state == Player.STATE_READY) {
                    cancelBufferingTimeout();
                    if (player.getPlayWhenReady()) markPlaying();
                } else if (state == Player.STATE_ENDED) {
                    tryNextSource("Поток завершился");
                }
            }

            @Override public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
                updatePlayButton();
                if (!playWhenReady) cancelBufferingTimeout();
                else if (player.getPlaybackState() == Player.STATE_BUFFERING && currentSourcePlayed) startBufferingTimeout();
            }

            @Override public void onPlayerError(PlaybackException error) {
                tryNextSource("Ошибка воспроизведения");
            }
        });
    }

    private void markPlaying() {
        currentSourcePlayed = true;
        cancelStartupTimeout(); cancelBufferingTimeout();
        progress.setVisibility(View.GONE); status.setVisibility(View.GONE); exhausted = false;
        loadNowProgram();
        scheduleControlsHide();
    }

    private String sourceText(String prefix) {
        if (urls.length <= 1) return prefix;
        return prefix + " Источник " + (sourceIndex + 1) + "/" + urls.length;
    }

    private void playCurrent() {
        if (urls.length == 0) { showError("У канала нет ссылки"); return; }
        if (sourceIndex < 0 || sourceIndex >= urls.length) sourceIndex = 0;
        exhausted = false; currentSourcePlayed = false;
        final int thisAttempt = ++playAttempt;
        cancelAllTimeouts();
        progress.setVisibility(View.VISIBLE); status.setText(sourceText("Подключение… максимум 30 сек")); status.setVisibility(View.VISIBLE);
        player.stop(); player.clearMediaItems();

        String url = urls[sourceIndex];
        try {
            if (url.startsWith("http://") || url.startsWith("https://")) {
                DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                        .setAllowCrossProtocolRedirects(true)
                        .setConnectTimeoutMs(15000)
                        .setReadTimeoutMs(20000)
                        .setUserAgent(userAgents[sourceIndex].isEmpty() ? "NikitaTV/0.5 Android" : userAgents[sourceIndex]);
                Map<String, String> headers = new HashMap<>();
                if (!referrers[sourceIndex].isEmpty()) headers.put("Referer", referrers[sourceIndex]);
                if (!headers.isEmpty()) http.setDefaultRequestProperties(headers);
                MediaSource mediaSource = new DefaultMediaSourceFactory(http).createMediaSource(MediaItem.fromUri(url));
                player.setMediaSource(mediaSource);
            } else player.setMediaItem(MediaItem.fromUri(url));
            player.prepare(); player.setPlayWhenReady(true);
        } catch (Exception e) {
            tryNextSource("Источник не поддерживается"); return;
        }

        startupTimeout = () -> {
            if (player == null || exhausted || currentSourcePlayed || thisAttempt != playAttempt) return;
            tryNextSource("Не запустился за 30 секунд");
        };
        handler.postDelayed(startupTimeout, SOURCE_TIMEOUT_MS);
    }

    private void startBufferingTimeout() {
        if (bufferingTimeout != null) return;
        final int thisAttempt = playAttempt;
        bufferingTimeout = () -> {
            bufferingTimeout = null;
            if (player == null || exhausted || thisAttempt != playAttempt) return;
            if (player.getPlaybackState() == Player.STATE_BUFFERING && player.getPlayWhenReady()) tryNextSource("Буферизация более 30 секунд");
        };
        handler.postDelayed(bufferingTimeout, SOURCE_TIMEOUT_MS);
    }

    private void cancelStartupTimeout() { if (startupTimeout != null) { handler.removeCallbacks(startupTimeout); startupTimeout = null; } }
    private void cancelBufferingTimeout() { if (bufferingTimeout != null) { handler.removeCallbacks(bufferingTimeout); bufferingTimeout = null; } }
    private void cancelAllTimeouts() { cancelStartupTimeout(); cancelBufferingTimeout(); }

    private void tryNextSource(String reason) {
        if (exhausted) return;
        cancelAllTimeouts();
        if (sourceIndex + 1 < urls.length) {
            sourceIndex++;
            progress.setVisibility(View.VISIBLE); status.setText(sourceText(reason + ". Переключаю…")); status.setVisibility(View.VISIBLE);
            handler.postDelayed(this::playCurrent, 350);
        } else {
            exhausted = true;
            showError("Не удалось запустить доступные потоки этого канала. Возможна временная недоступность, региональное ограничение или изменение ссылки.");
        }
    }

    private void switchRelative(int delta) {
        Channel next = ChannelSession.move(delta);
        if (next == null) { Toast.makeText(this, "Список каналов недоступен", Toast.LENGTH_SHORT).show(); return; }
        switchToChannel(next);
    }

    private void switchToChannel(Channel c) {
        cancelAllTimeouts();
        applyChannel(c);
        playCurrent();
        showControls(true);
    }

    private void togglePlayPause() {
        if (player == null) return;
        if (player.getPlayWhenReady()) player.pause(); else player.play();
        updatePlayButton(); scheduleControlsHide();
    }

    private void updatePlayButton() {
        if (playPauseButton == null || player == null) return;
        playPauseButton.setText(player.getPlayWhenReady() ? "⏸ Пауза" : "▶ Плей");
    }

    private void adjustVolume(int direction) {
        if (audioManager == null) return;
        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                direction > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI);
        scheduleControlsHide();
    }

    private void toggleMute() {
        if (audioManager == null) return;
        boolean muted = Build.VERSION.SDK_INT >= 23 && audioManager.isStreamMute(AudioManager.STREAM_MUSIC);
        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, muted ? AudioManager.ADJUST_UNMUTE : AudioManager.ADJUST_MUTE, 0);
        muteButton.setText(muted ? "🔇" : "🔊");
        scheduleControlsHide();
    }

    private void loadNowProgram() {
        if (currentChannel == null || nowProgramView == null) return;
        final Channel requested = currentChannel;
        nowProgramView.setText("Сейчас: загружаю программу…");
        EpgRepository.loadSchedule(this, requested, new EpgRepository.Callback() {
            @Override public void onLoaded(List<EpgRepository.ProgramInfo> programs) {
                runOnUiThread(() -> {
                    if (currentChannel != requested) return;
                    EpgRepository.ProgramInfo p = EpgRepository.current(programs);
                    if (p == null) nowProgramView.setText("Сейчас: программа не указана");
                    else nowProgramView.setText("Сейчас • " + p.timeRange() + " • " + p.title);
                });
            }
            @Override public void onUnavailable(String reason) {
                runOnUiThread(() -> { if (currentChannel == requested) nowProgramView.setText("Сейчас: программа недоступна"); });
            }
        });
    }

    private void showSchedule() {
        if (currentChannel == null) return;
        final ProgressDialog loading = new ProgressDialog(this);
        loading.setMessage("Загружаю программу…"); loading.setCancelable(true); loading.show();
        final Channel requested = currentChannel;
        EpgRepository.loadSchedule(this, requested, new EpgRepository.Callback() {
            @Override public void onLoaded(List<EpgRepository.ProgramInfo> programs) {
                runOnUiThread(() -> {
                    if (loading.isShowing()) loading.dismiss();
                    List<EpgRepository.ProgramInfo> items = EpgRepository.upcoming(programs, 12);
                    if (items.isEmpty()) { showScheduleUnavailable("На ближайшее время передач нет"); return; }
                    String[] rows = new String[items.size()];
                    EpgRepository.ProgramInfo current = EpgRepository.current(programs);
                    for (int i = 0; i < items.size(); i++) {
                        EpgRepository.ProgramInfo p = items.get(i);
                        rows[i] = p.timeRange() + (p == current ? "   ● СЕЙЧАС" : "") + "\n" + (p.title.isEmpty() ? "Без названия" : p.title);
                    }
                    new AlertDialog.Builder(PlayerActivity.this)
                            .setTitle("ⓘ " + requested.name + " — программа")
                            .setItems(rows, (d, which) -> {
                                EpgRepository.ProgramInfo p = items.get(which);
                                if (!p.description.isEmpty()) new AlertDialog.Builder(PlayerActivity.this).setTitle(p.title).setMessage(p.timeRange() + "\n\n" + p.description).setPositiveButton("Закрыть", null).show();
                            })
                            .setPositiveButton("Закрыть", null).show();
                });
            }
            @Override public void onUnavailable(String reason) {
                runOnUiThread(() -> { if (loading.isShowing()) loading.dismiss(); showScheduleUnavailable(reason); });
            }
        });
        scheduleControlsHide();
    }

    private void showScheduleUnavailable(String reason) {
        new AlertDialog.Builder(this).setTitle("Программа канала").setMessage(reason).setPositiveButton("Закрыть", null).show();
    }

    private void showChannelSearch() {
        List<Channel> all = ChannelSession.snapshot();
        if (all.isEmpty()) { Toast.makeText(this, "Список каналов ещё не загружен", Toast.LENGTH_SHORT).show(); return; }
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12), dp(6), dp(12), dp(6));
        EditText input = new EditText(this); input.setHint("Название канала"); input.setSingleLine(true); input.setTextColor(Color.WHITE); input.setHintTextColor(0xFF98A9B8);
        ListView list = new ListView(this); list.setDividerHeight(1);
        box.addView(input, new LinearLayout.LayoutParams(-1, dp(54))); box.addView(list, new LinearLayout.LayoutParams(-1, tvMode ? dp(420) : dp(360)));
        final List<Channel> filtered = new ArrayList<>();
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        list.setAdapter(adapter);
        Runnable refill = () -> {
            String q = input.getText().toString().trim().toLowerCase(Locale.ROOT);
            filtered.clear(); adapter.clear();
            for (Channel c : all) {
                if (q.isEmpty() || c.name.toLowerCase(Locale.ROOT).contains(q)) {
                    filtered.add(c); adapter.add(c.name + (c.country.isEmpty() ? "" : "  •  " + c.country));
                    if (filtered.size() >= 60) break;
                }
            }
            adapter.notifyDataSetChanged();
        };
        input.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { refill.run(); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        refill.run();
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("🔎 Поиск канала").setView(box).setNegativeButton("Закрыть", null).create();
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < filtered.size()) { Channel c = filtered.get(position); dialog.dismiss(); switchToChannel(c); }
        });
        dialog.setOnShowListener(d -> { input.requestFocus(); if (!tvMode) ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT); });
        dialog.show();
        scheduleControlsHide();
    }

    private void showControls(boolean resetTimer) {
        topBar.setVisibility(View.VISIBLE); controlsPanel.setVisibility(View.VISIBLE);
        loadNowProgram();
        if (tvMode && playPauseButton != null) playPauseButton.requestFocus();
        if (resetTimer) scheduleControlsHide();
    }

    private void hideControls() {
        topBar.setVisibility(View.GONE); controlsPanel.setVisibility(View.GONE); hideSystemBars();
    }

    private void toggleControls() {
        if (controlsPanel.getVisibility() == View.VISIBLE) hideControls(); else showControls(true);
    }

    private void scheduleControlsHide() {
        if (hideControlsRunnable != null) handler.removeCallbacks(hideControlsRunnable);
        hideControlsRunnable = () -> { if (!isFinishing()) hideControls(); };
        handler.postDelayed(hideControlsRunnable, CONTROLS_HIDE_MS);
    }

    private void showError(String msg) {
        cancelAllTimeouts(); progress.setVisibility(View.GONE); status.setText(msg); status.setVisibility(View.VISIBLE); showControls(false);
        new AlertDialog.Builder(this).setTitle(name).setMessage(msg)
                .setPositiveButton("Повторить", (d, w) -> { sourceIndex = 0; exhausted = false; playCurrent(); })
                .setNegativeButton("Назад", (d, w) -> finish()).show();
    }

    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            int code = event.getKeyCode();
            if (controlsPanel != null && controlsPanel.getVisibility() == View.VISIBLE) scheduleControlsHide();
            if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if (controlsPanel.getVisibility() != View.VISIBLE) { showControls(true); return true; }
                scheduleControlsHide();
            } else if (code == KeyEvent.KEYCODE_CHANNEL_UP) { switchRelative(1); return true; }
            else if (code == KeyEvent.KEYCODE_CHANNEL_DOWN) { switchRelative(-1); return true; }
            else if (code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) { togglePlayPause(); return true; }
            else if (code == KeyEvent.KEYCODE_INFO) { showSchedule(); return true; }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override public void onBackPressed() {
        if (controlsPanel != null && controlsPanel.getVisibility() == View.VISIBLE) hideControls(); else super.onBackPressed();
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideSystemBars(); }
    @Override protected void onPause() { super.onPause(); if (player != null) player.pause(); }
    @Override protected void onResume() { super.onResume(); hideSystemBars(); if (player != null && player.getPlaybackState() == Player.STATE_READY) player.play(); }
    @Override protected void onDestroy() {
        cancelAllTimeouts(); handler.removeCallbacksAndMessages(null); if (player != null) { player.release(); player = null; } super.onDestroy();
    }
}
