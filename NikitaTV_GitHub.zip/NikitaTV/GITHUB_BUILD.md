# Сборка Nikita TV через GitHub Actions

1. Создай пустой репозиторий на GitHub.
2. Распакуй содержимое ZIP в корень репозитория.
3. Убедись, что файл `.github/workflows/build-apk.yml` присутствует.
4. Загрузи файлы в ветку `main` или `master`.
5. Открой вкладку **Actions** → **Build Nikita TV APK** → **Run workflow**.
6. После завершения сборки открой запуск workflow и скачай артефакт **NikitaTV-debug-apk**.
7. Внутри артефакта будет `app-debug.apk`.

Workflow также запускается автоматически после каждого push в `main` или `master`.
