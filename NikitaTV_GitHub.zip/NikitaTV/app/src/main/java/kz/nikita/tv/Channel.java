package kz.nikita.tv;

public class Channel {
    public final String name;
    public final String category;
    public final String country;
    public final String url;
    public final int accent;

    public Channel(String name, String category, String country, String url, int accent) {
        this.name = name;
        this.category = category;
        this.country = country;
        this.url = url;
        this.accent = accent;
    }
}
