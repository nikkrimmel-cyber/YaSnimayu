package kz.nikita.tv;

import android.app.*;
import android.app.UiModeManager;
import android.content.*;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final List<Channel> allChannels = ChannelRepository.all();
    private GridLayout channelGrid;
    private String activeCategory = "Все";
    private boolean tvMode;
    private LinearLayout content;
    private final String[] categories = {"Все", "Казахстан", "Россия", "Новости", "Развлекательные", "Культура", "Детские", "Спорт"};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,14,22));
        getWindow().setNavigationBarColor(Color.rgb(5,14,22));
        tvMode = resolveTvMode();
        buildUi();
    }

    private boolean resolveTvMode() {
        String mode = getSharedPreferences("nikita_tv", MODE_PRIVATE).getString("ui_mode", "auto");
        if ("tv".equals(mode)) return true;
        if ("phone".equals(mode)) return false;
        UiModeManager um = (UiModeManager)getSystemService(UI_MODE_SERVICE);
        if (um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return true;
        return getResources().getConfiguration().smallestScreenWidthDp >= 720;
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setImageResource(kz.nikita.tv.R.drawable.bg_serebryansk);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1,-1));

        View shade = new View(this);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x66000000,0xB8061119,0xF2050E16});
        shade.setBackground(gd); root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        if (tvMode) root.addView(buildTvLayout()); else root.addView(buildPhoneLayout());
        setContentView(root);
    }

    private View buildTvLayout() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(22),dp(20),dp(22),dp(18));
        row.addView(buildSidebar(), new LinearLayout.LayoutParams(dp(235), -1));
        content = buildContent(true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0,-1,1); cp.leftMargin=dp(18);
        row.addView(content, cp); return row;
    }

    private View buildPhoneLayout() {
        content = buildContent(false);
        return content;
    }

    private View buildSidebar() {
        LinearLayout side = new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(dp(14),dp(14),dp(14),dp(14));
        side.setBackground(round(0xB8071621,18));
        TextView logo=text("Никита ТВ",29,true); side.addView(logo,new LinearLayout.LayoutParams(-1,dp(64)));
        String[] items={"⌂  Главная","▣  ТВ каналы","★  Избранное","◷  История","⚙  Режим интерфейса"};
        for(String s:items){
            TextView v=text(s,18,false); v.setFocusable(true); v.setPadding(dp(16),0,dp(8),0); v.setBackground(round(0x221E88E5,12));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(58)); p.bottomMargin=dp(9); side.addView(v,p);
            if(s.contains("Режим")) v.setOnClickListener(x->showModeDialog());
        }
        Space space=new Space(this); side.addView(space,new LinearLayout.LayoutParams(1,0,1));
        TextView city=text("●  Серебрянск, ВКО\n   Бесплатное ТВ",14,false); city.setTextColor(0xFFD7E6F2); side.addView(city,new LinearLayout.LayoutParams(-1,dp(70)));
        return side;
    }

    private LinearLayout buildContent(boolean tv) {
        LinearLayout main = new LinearLayout(this); main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(tv?dp(10):dp(16), tv?0:dp(12), tv?dp(10):dp(16), dp(14));

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=text("Никита ТВ", tv?34:27,true); top.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        Button mode=new Button(this); mode.setText(tv?"📺 ТВ":"📱 Телефон"); mode.setTextColor(Color.WHITE); mode.setTextSize(tv?16:12); mode.setAllCaps(false); mode.setBackground(round(0xBB0D5CA8,12)); mode.setFocusable(true); mode.setOnClickListener(v->showModeDialog());
        top.addView(mode,new LinearLayout.LayoutParams(tv?dp(160):dp(120),dp(46))); main.addView(top);

        TextView hero=text(tv?"Серебрянск • любимые каналы всегда рядом":"Серебрянск • ТВ всегда рядом",tv?22:15,false);
        hero.setTextColor(0xFFE8F3FA); main.addView(hero,new LinearLayout.LayoutParams(-1,tv?dp(55):dp(36)));

        HorizontalScrollView catScroll=new HorizontalScrollView(this); catScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout catRow=new LinearLayout(this); catRow.setOrientation(LinearLayout.HORIZONTAL); catRow.setPadding(0,dp(4),0,dp(6));
        for(String cat:categories){
            Button b=new Button(this); b.setText(cat); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(tv?15:12); b.setFocusable(true); b.setTag(cat);
            styleCategoryButton(b,cat.equals(activeCategory)); b.setOnClickListener(v->{activeCategory=(String)v.getTag(); refreshGrid(); refreshCategoryButtons(catRow);});
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,tv?dp(52):dp(44)); bp.rightMargin=dp(8); catRow.addView(b,bp);
        }
        catScroll.addView(catRow); main.addView(catScroll,new LinearLayout.LayoutParams(-1,tv?dp(68):dp(58)));

        TextView popular=text("Каналы",tv?24:20,true); main.addView(popular,new LinearLayout.LayoutParams(-1,tv?dp(50):dp(42)));

        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        channelGrid=new GridLayout(this); channelGrid.setColumnCount(tv?4:2); channelGrid.setUseDefaultMargins(false); channelGrid.setPadding(0,0,0,dp(80));
        scroll.addView(channelGrid,new ScrollView.LayoutParams(-1,-2));
        main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        refreshGrid();
        return main;
    }

    private void refreshCategoryButtons(LinearLayout row){
        for(int i=0;i<row.getChildCount();i++){
            View v=row.getChildAt(i); if(v instanceof Button) styleCategoryButton((Button)v, activeCategory.equals(v.getTag()));
        }
    }

    private void styleCategoryButton(Button b, boolean active){
        b.setBackground(round(active?0xEE157DE0:0xAA102632,12));
    }

    private boolean matches(Channel c){
        if("Все".equals(activeCategory)) return true;
        if("Казахстан".equals(activeCategory)) return "KZ".equals(c.country);
        if("Россия".equals(activeCategory)) return "RU".equals(c.country);
        return activeCategory.equals(c.category);
    }

    private void refreshGrid(){
        if(channelGrid==null)return; channelGrid.removeAllViews();
        int cols=tvMode?4:2; channelGrid.setColumnCount(cols); int index=0;
        for(Channel c:allChannels){ if(!matches(c)) continue; channelGrid.addView(channelCard(c,index++)); }
        if(index==0){ TextView empty=text("В этой категории пока нет каналов",16,false); channelGrid.addView(empty); }
    }

    private View channelCard(Channel c, int filteredIndex){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER); card.setPadding(dp(10),dp(9),dp(10),dp(9));
        card.setFocusable(true); card.setClickable(true); card.setBackground(round(0xD91A2D38,16));
        TextView badge=text(c.name,tvMode?22:16,true); badge.setGravity(Gravity.CENTER); badge.setTextColor(Color.WHITE); GradientDrawable bd=round(c.accent,12); badge.setBackground(bd);
        card.addView(badge,new LinearLayout.LayoutParams(-1,tvMode?dp(82):dp(62)));
        TextView meta=text(("KZ".equals(c.country)?"🇰🇿 ":"🇷🇺 ")+c.category,tvMode?13:11,false); meta.setTextColor(0xFFCAD7DF); meta.setGravity(Gravity.CENTER); card.addView(meta,new LinearLayout.LayoutParams(-1,dp(32)));
        card.setOnClickListener(v->openChannel(c));
        card.setOnFocusChangeListener((v,has)-> { v.setScaleX(has?1.035f:1f); v.setScaleY(has?1.035f:1f); v.setAlpha(has?1f:.94f); });
        int screen = getResources().getDisplayMetrics().widthPixels;
        int usable = tvMode ? screen-dp(305) : screen-dp(40);
        int w = Math.max(dp(150), usable/(tvMode?4:2)-dp(10));
        GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=w; gp.height=tvMode?dp(136):dp(112); gp.setMargins(dp(4),dp(4),dp(4),dp(4));
        return attachParams(card,gp);
    }

    private View attachParams(View v, ViewGroup.LayoutParams p){ v.setLayoutParams(p); return v; }

    private void openChannel(Channel c){
        Intent i=new Intent(this,PlayerActivity.class); i.putExtra("name",c.name); i.putExtra("url",c.url); i.putExtra("ui_tv",tvMode); startActivity(i);
    }

    private void showModeDialog(){
        String[] modes={"Авто — определить устройство","Телефон / планшет","Android TV"};
        new AlertDialog.Builder(this).setTitle("Режим интерфейса").setItems(modes,(d,which)->{
            String val=which==0?"auto":which==1?"phone":"tv";
            getSharedPreferences("nikita_tv",MODE_PRIVATE).edit().putString("ui_mode",val).apply(); recreate();
        }).setNegativeButton("Отмена",null).show();
    }
}
