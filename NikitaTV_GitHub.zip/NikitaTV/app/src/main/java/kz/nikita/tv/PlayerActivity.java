package kz.nikita.tv;

import android.app.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class PlayerActivity extends Activity {
    private VideoView video;
    private ProgressBar progress;
    private TextView status;
    private String name, url;
    private boolean tvMode;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        name=getIntent().getStringExtra("name"); url=getIntent().getStringExtra("url"); tvMode=getIntent().getBooleanExtra("ui_tv",false);
        build(); play();
    }

    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView text(String s,int sp,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}

    private void build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        video=new VideoView(this); root.addView(video,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(18),dp(10),dp(18),dp(10));top.setBackgroundColor(0x99000000);
        Button back=new Button(this);back.setText("‹");back.setTextSize(tvMode?26:22);back.setTextColor(Color.WHITE);back.setBackground(round(0xAA173448,12));back.setOnClickListener(v->finish());back.setFocusable(true);
        top.addView(back,new LinearLayout.LayoutParams(dp(58),dp(50)));
        TextView title=text(name==null?"Канал":name,tvMode?24:19,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(50),1);tp.leftMargin=dp(14);top.addView(title,tp);
        TextView live=text("● LIVE",tvMode?15:12,true);live.setTextColor(0xFFFF4B55);top.addView(live,new LinearLayout.LayoutParams(dp(80),dp(50)));
        FrameLayout.LayoutParams topP=new FrameLayout.LayoutParams(-1,dp(72),Gravity.TOP);root.addView(top,topP);

        progress=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(56),dp(56),Gravity.CENTER);root.addView(progress,pp);
        status=text("Подключение…",tvMode?16:13,false);status.setGravity(Gravity.CENTER);status.setBackground(round(0xAA000000,10));status.setPadding(dp(14),dp(8),dp(14),dp(8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);sp.topMargin=dp(82);root.addView(status,sp);

        MediaController mc=new MediaController(this);mc.setAnchorView(video);video.setMediaController(mc);
        setContentView(root);
    }

    private void play(){
        if(url==null||url.isEmpty()){showError("У канала нет ссылки");return;}
        progress.setVisibility(View.VISIBLE);status.setText("Подключение…");status.setVisibility(View.VISIBLE);
        video.setVideoURI(Uri.parse(url));
        video.setOnPreparedListener(mp->{ progress.setVisibility(View.GONE);status.setVisibility(View.GONE); mp.setOnInfoListener((m,what,extra)->{if(what==MediaPlayer.MEDIA_INFO_BUFFERING_START){progress.setVisibility(View.VISIBLE);} if(what==MediaPlayer.MEDIA_INFO_BUFFERING_END){progress.setVisibility(View.GONE);} return false;}); video.start(); });
        video.setOnErrorListener((mp,what,extra)->{showError("Поток временно недоступен. Попробуйте позже или выберите другой канал.");return true;});
        video.start();
    }

    private void showError(String msg){
        progress.setVisibility(View.GONE);status.setText(msg);status.setVisibility(View.VISIBLE);
        new AlertDialog.Builder(this).setTitle(name).setMessage(msg).setPositiveButton("Повторить",(d,w)->play()).setNegativeButton("Назад",(d,w)->finish()).show();
    }

    @Override protected void onPause(){super.onPause();if(video!=null)video.pause();}
}
