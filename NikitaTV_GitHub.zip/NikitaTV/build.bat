@echo off
setlocal
if exist gradlew.bat (
  call gradlew.bat assembleDebug
) else (
  echo Gradle Wrapper is not included in this source archive.
  echo Open this folder in Android Studio and select Build ^> Build APK(s).
  echo Android Studio will download the required Gradle/SDK components.
  pause
)
