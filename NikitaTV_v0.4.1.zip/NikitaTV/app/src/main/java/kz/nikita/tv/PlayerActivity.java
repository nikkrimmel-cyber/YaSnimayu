package kz.nikita.tv;

import android.app.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.ui.PlayerView;

import java.util.HashMap;
import java.util.Map;

@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {
    private PlayerView playerView;
    private ExoPlayer player;
    private ProgressBar progress;
    private TextView status;
    private String name;
    private String[] urls;
    private String[] userAgents;
    private String[] referrers;
    private boolean tvMode;
    private int sourceIndex = 0;
    private boolean exhausted = false;
    private boolean currentSourcePlayed = false;
    private int playAttempt = 0;
    private Runnable startupTimeout;
    private Runnable bufferingTimeout;
    private static final long SOURCE_TIMEOUT_MS = 30000L;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        name=getIntent().getStringExtra("name");
        urls=getIntent().getStringArrayExtra("urls");
        if(urls==null || urls.length==0){
            String single=getIntent().getStringExtra("url");
            urls=single==null?new String[0]:new String[]{single};
        }
        userAgents=normalize(getIntent().getStringArrayExtra("user_agents"), urls.length);
        referrers=normalize(getIntent().getStringArrayExtra("referrers"), urls.length);
        tvMode=getIntent().getBooleanExtra("ui_tv",false);
        build();
        initPlayer();
        playCurrent();
    }

    private String[] normalize(String[] src,int len){
        String[] out=new String[len];
        if(src!=null) System.arraycopy(src,0,out,0,Math.min(src.length,len));
        for(int i=0;i<out.length;i++) if(out[i]==null) out[i]="";
        return out;
    }

    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable round(int c,int r){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(r));return d;}
    private TextView text(String s,int sp,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(sp);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}

    private void build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);

        playerView=new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setKeepScreenOn(true);
        root.addView(playerView,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(18),dp(10),dp(18),dp(10));top.setBackgroundColor(0x99000000);
        Button back=new Button(this);back.setText("‹");back.setTextSize(tvMode?26:22);back.setTextColor(Color.WHITE);back.setBackground(round(0xAA173448,12));back.setOnClickListener(v->finish());back.setFocusable(true);
        top.addView(back,new LinearLayout.LayoutParams(dp(58),dp(50)));
        TextView title=text(name==null?"Канал":name,tvMode?24:19,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(50),1);tp.leftMargin=dp(14);top.addView(title,tp);
        TextView live=text("● LIVE",tvMode?15:12,true);live.setTextColor(0xFFFF4B55);top.addView(live,new LinearLayout.LayoutParams(dp(80),dp(50)));
        FrameLayout.LayoutParams topP=new FrameLayout.LayoutParams(-1,dp(72),Gravity.TOP);root.addView(top,topP);

        progress=new ProgressBar(this);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(56),dp(56),Gravity.CENTER);root.addView(progress,pp);
        status=text("Подключение…",tvMode?16:13,false);status.setGravity(Gravity.CENTER);status.setBackground(round(0xCC000000,10));status.setPadding(dp(14),dp(8),dp(14),dp(8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER);sp.topMargin=dp(82);root.addView(status,sp);

        setContentView(root);
    }

    private void initPlayer(){
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int state) {
                if(state==Player.STATE_BUFFERING){
                    progress.setVisibility(View.VISIBLE);
                    status.setText(sourceText(currentSourcePlayed?"Буферизация… 30 сек до смены потока":"Подключение / буферизация…"));
                    status.setVisibility(View.VISIBLE);
                    if(currentSourcePlayed && player.getPlayWhenReady()) startBufferingTimeout();
                } else if(state==Player.STATE_READY){
                    cancelBufferingTimeout();
                    if(player.isPlaying()) markPlaying();
                } else if(state==Player.STATE_ENDED){
                    tryNextSource("Поток завершился");
                }
            }

            @Override public void onIsPlayingChanged(boolean isPlaying) {
                if(isPlaying) markPlaying();
                else if(player!=null && player.getPlaybackState()==Player.STATE_BUFFERING && currentSourcePlayed && player.getPlayWhenReady()) startBufferingTimeout();
            }

            @Override public void onPlayerError(PlaybackException error) {
                tryNextSource("Ошибка воспроизведения");
            }
        });
    }

    private void markPlaying(){
        currentSourcePlayed=true;
        cancelStartupTimeout();
        cancelBufferingTimeout();
        progress.setVisibility(View.GONE);
        status.setVisibility(View.GONE);
        exhausted=false;
    }

    private String sourceText(String prefix){
        if(urls.length<=1) return prefix;
        return prefix+" Источник "+(sourceIndex+1)+"/"+urls.length;
    }

    private void playCurrent(){
        if(urls.length==0){ showError("У канала нет ссылки"); return; }
        if(sourceIndex<0 || sourceIndex>=urls.length) sourceIndex=0;
        exhausted=false;
        currentSourcePlayed=false;
        final int thisAttempt=++playAttempt;
        cancelAllTimeouts();
        progress.setVisibility(View.VISIBLE);
        status.setText(sourceText("Подключение… максимум 30 сек"));
        status.setVisibility(View.VISIBLE);
        player.stop();
        player.clearMediaItems();

        String url=urls[sourceIndex];
        try {
            if(url.startsWith("http://") || url.startsWith("https://")) {
                DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                        .setAllowCrossProtocolRedirects(true)
                        .setConnectTimeoutMs(15000)
                        .setReadTimeoutMs(20000)
                        .setUserAgent(userAgents[sourceIndex].isEmpty()?"NikitaTV/0.4 Android":userAgents[sourceIndex]);
                Map<String,String> headers=new HashMap<>();
                if(!referrers[sourceIndex].isEmpty()) headers.put("Referer",referrers[sourceIndex]);
                if(!headers.isEmpty()) http.setDefaultRequestProperties(headers);
                MediaSource mediaSource = new DefaultMediaSourceFactory(http).createMediaSource(MediaItem.fromUri(url));
                player.setMediaSource(mediaSource);
            } else {
                player.setMediaItem(MediaItem.fromUri(url));
            }
            player.prepare();
            player.setPlayWhenReady(true);
        } catch (Exception e) {
            tryNextSource("Источник не поддерживается");
            return;
        }

        // Источник должен реально начать воспроизводиться в течение 30 секунд.
        // STATE_READY недостаточно: некоторые серверы остаются в READY/BUFFERING,
        // но кадры так и не начинают идти. Успех фиксируем только по isPlaying=true.
        startupTimeout = () -> {
            if(player==null || exhausted || currentSourcePlayed || thisAttempt!=playAttempt) return;
            tryNextSource("Не запустился за 30 секунд");
        };
        handler.postDelayed(startupTimeout, SOURCE_TIMEOUT_MS);
    }

    private void startBufferingTimeout(){
        if(bufferingTimeout!=null) return;
        final int thisAttempt=playAttempt;
        bufferingTimeout=()->{
            bufferingTimeout=null;
            if(player==null || exhausted || thisAttempt!=playAttempt) return;
            if(player.getPlaybackState()==Player.STATE_BUFFERING && player.getPlayWhenReady()) {
                tryNextSource("Буферизация более 30 секунд");
            }
        };
        handler.postDelayed(bufferingTimeout,SOURCE_TIMEOUT_MS);
    }

    private void cancelStartupTimeout(){
        if(startupTimeout!=null){handler.removeCallbacks(startupTimeout);startupTimeout=null;}
    }

    private void cancelBufferingTimeout(){
        if(bufferingTimeout!=null){handler.removeCallbacks(bufferingTimeout);bufferingTimeout=null;}
    }

    private void cancelAllTimeouts(){cancelStartupTimeout();cancelBufferingTimeout();}

    private void tryNextSource(String reason){
        if(exhausted) return;
        cancelAllTimeouts();
        if(sourceIndex+1 < urls.length){
            sourceIndex++;
            progress.setVisibility(View.VISIBLE);
            status.setText(sourceText(reason+". Переключаю…"));
            status.setVisibility(View.VISIBLE);
            handler.postDelayed(this::playCurrent, 350);
        }else{
            exhausted=true;
            showError("Не удалось запустить доступные потоки этого канала. Возможна временная недоступность, региональное ограничение или изменение ссылки.");
        }
    }

    private void showError(String msg){
        cancelAllTimeouts();
        progress.setVisibility(View.GONE);status.setText(msg);status.setVisibility(View.VISIBLE);
        new AlertDialog.Builder(this)
                .setTitle(name)
                .setMessage(msg)
                .setPositiveButton("Повторить",(d,w)->{sourceIndex=0; exhausted=false; playCurrent();})
                .setNegativeButton("Назад",(d,w)->finish())
                .show();
    }

    @Override protected void onPause(){super.onPause();if(player!=null)player.pause();}
    @Override protected void onResume(){super.onResume();if(player!=null && player.getPlaybackState()==Player.STATE_READY)player.play();}
    @Override protected void onDestroy(){
        cancelAllTimeouts();
        handler.removeCallbacksAndMessages(null);
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
